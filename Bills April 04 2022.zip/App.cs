﻿class App : Application
{
    public static OpenCvSharp.Text.OCRTesseract OCR;
    public static BillProcessor BP;
    public static LoadGroupSummaryConverter LGSC;
    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        new AppData();
        LGSC = new LoadGroupSummaryConverter();
        
        SetStyle();
        Current.MainWindow = new RootWindow() {
            TaskbarItemInfo = new TaskbarItemInfo(),
            Content = new RootPanel() {
                Children = {
                    new ProcessView(),
                    new SearchView(),
                    new PeriodicView(),
                    new AccountsView()
                }
            }
        };
        Current.MainWindow.Show();
        Current.DispatcherUnhandledException += unhandledHandler;
        OCR = OpenCvSharp.Text.OCRTesseract.Create("tessData", "eng",
                "01234567890.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ -:'\"`~@#$%^&*()-=+_/<>?\\;,:[]{}|");
        BP = new BillProcessor();
        
    }
    void SetStyle() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Control.BackgroundProperty, Constants.Background),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray),
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0))
                }
            }
        });

        ScrollBar.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { 
                    new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()),
                    new Setter(ContextMenuService.IsEnabledProperty, false)
                },
                Triggers = {
                        new Trigger() {
                            Property = ScrollBar.OrientationProperty,
                            Value = Orientation.Horizontal,
                            Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                        }
                    }
            }
        });
    }
    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        ExceptionDialog.Activate("Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }
}