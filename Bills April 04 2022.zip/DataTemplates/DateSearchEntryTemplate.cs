﻿class DateSearchEntryTemplate : DataTemplate
{
    public DateSearchEntryTemplate(DateSearchVM vm) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var account = new FrameworkElementFactory(typeof(HiBlock));
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        bill.SetValue(Grid.ColumnProperty, 1);
        payment.SetValue(Grid.ColumnProperty, 2);
        bill.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        bill.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        account.SetBinding(HiBlock.TextProperty, new Binding(nameof(ReportEntry.AccountNo)));
        account.SetBinding(HiBlock.QueryProperty, new Binding(nameof(vm.Query)) { Source = vm });
        bill.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Bill)) { StringFormat = "N2" });
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Payment)) { StringFormat = "N2" });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(account);
        grid.AppendChild(bill);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}
