﻿class HeadwiseSummaryGroupTemplate : ControlTemplate
{
    public HeadwiseSummaryGroupTemplate() {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var row3 = new FrameworkElementFactory(typeof(RowDefinition));
        var header = new FrameworkElementFactory(typeof(TextBlock)) { Name = "header" };
        var items = new FrameworkElementFactory(typeof(ItemsPresenter)) { Name = "presenter" };
        var footer = new FrameworkElementFactory(typeof(ContentControl)) { Name = "footer" };

        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
        footer.SetValue(Grid.RowProperty, 2);
        footer.SetValue(ContentControl.ContentTemplateProperty, new SummaryFooterTemplate());

        header.SetBinding(TextBlock.TextProperty, new Binding(nameof(GroupItem.Name)) { Mode = BindingMode.OneWay });
        footer.SetBinding(ContentControl.ContentProperty, new Binding() { Converter = new SummaryGroupSummaryConverter() });

        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(row3);
        grid.AppendChild(header);
        grid.AppendChild(items);
        grid.AppendChild(footer);
        VisualTree = grid;

        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                    new Condition(new Binding(nameof(CollectionViewGroup.IsBottomLevel)), true),
                    new Condition(new Binding(nameof(CollectionViewGroup.ItemCount)), 1),
                },
            Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Collapsed, "header"),
                    new Setter(ItemsPresenter.MarginProperty, new Thickness(-5,0,0,0), "presenter"),
                    new Setter(ContentControl.VisibilityProperty, Visibility.Collapsed, "footer")
                }
        });
        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                    new Condition(new Binding(nameof(CollectionViewGroup.IsBottomLevel)), false),
                    new Condition(new Binding(nameof(CollectionViewGroup.ItemCount)), 1),
                },
            Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Collapsed, "header"),
                    new Setter(ItemsPresenter.VisibilityProperty, Visibility.Collapsed, "presenter")
                }
        });
    }
}
