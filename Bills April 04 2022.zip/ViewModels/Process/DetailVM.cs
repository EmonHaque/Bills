﻿class DetailVM : Notifiable
{
    public RawInfo Info { get; set; }   
    public DetailVM() {
        LoadVM.SelectionChanged += onSelectionChanged;
    }

    void onSelectionChanged(RawInfo info) {
        Info = info;
        OnPropertyChanged(nameof(Info));
    }
}
