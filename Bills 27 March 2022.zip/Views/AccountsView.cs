﻿class AccountsView : CardView
{
    public override string Header => "Accounts";
    public override string Icon => Icons.Accounts;

    EditText search;
    TextBlock numAccounts;
    ListBoxEx list;
    AccountsVM vm;
    public AccountsView() {
        vm = new AccountsVM();
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search
        };
        numAccounts = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        list = new ListBoxEx() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new AccountTemplate(vm),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)){
                            Setters = { new Setter(GroupItem.TemplateProperty, new AccountGroupTemplate())}
                    }
                }
            }
        };
        Grid.SetColumn(numAccounts, 1);
        Grid.SetRow(list, 1);
        Grid.SetColumnSpan(list, 2);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { search, numAccounts, list }
        };
        setContent(grid);
    }

    void bind() {
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        list.SetBinding(ListBoxEx.ItemsSourceProperty, new Binding(nameof(vm.Accounts)));
        numAccounts.SetBinding(TextBlock.TextProperty, new Binding() {
            Path = new PropertyPath($"{nameof(ListBox.Items)}.{nameof(ListBox.Items.Count)}"),
            StringFormat = "N0",
            Source = list,
            Mode = BindingMode.OneWay
        });
    }
}
