﻿class UpdatedEntry
{
    public string Table { get; set; }
    public int Id { get; set; }
    public double Amount { get; set; }
}
