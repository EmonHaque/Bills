﻿class AccountTemplate : DataTemplate
{
    public AccountTemplate(AccountsVM vm) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var account = new FrameworkElementFactory(typeof(HiBlock));
        var name = new FrameworkElementFactory(typeof(HiBlock));
        var address = new FrameworkElementFactory(typeof(HiBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(2, GridUnitType.Star));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(3, GridUnitType.Star));
        name.SetValue(Grid.ColumnProperty, 1);
        address.SetValue(Grid.ColumnProperty, 2);

        account.SetBinding(HiBlock.TextProperty, new Binding(nameof(Account.AccountNo)));
        name.SetBinding(HiBlock.TextProperty, new Binding(nameof(Account.Name)));
        address.SetBinding(HiBlock.TextProperty, new Binding(nameof(Account.Address)));
        account.SetBinding(HiBlock.QueryProperty, new Binding(nameof(vm.Query)){ Source = vm});
        name.SetBinding(HiBlock.QueryProperty, new Binding(nameof(vm.Query)) { Source = vm });
        address.SetBinding(HiBlock.QueryProperty, new Binding(nameof(vm.Query)) { Source = vm });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(account);
        grid.AppendChild(name);
        grid.AppendChild(address);

        VisualTree = grid;
    }
}
