﻿abstract class SearchBaseVM : Notifiable
{
    string imagePath;
    ColorState state;
    List<ReportEntry> reserved;
    CollectionViewSource accounts;
    int? accountId;
    public int? AccountId {
        get { return accountId; }
        set {
            if (accountId != value) {
                accountId = value;
                updateReportables();
            }
        }
    }
    string queryAccount;
    public string QueryAccount {
        get { return queryAccount; }
        set {
            if (queryAccount != value) {
                queryAccount = value?.Trim().ToLower();
                SelectionView.Refresh();
            }
        }
    }
    string queryParticulars;
    public string QueryParticulars {
        get { return queryParticulars; }
        set { queryParticulars = value; Reportables.Refresh(); }
    }
    bool isAccountOnEdit;
    public bool IsAccountOnEdit {
        get { return isAccountOnEdit; }
        set {
            isAccountOnEdit = value;
            if (value) cloneAccount();
            else updateAccount();
        }
    }
    bool isBillOnEdit;
    public bool IsBillOnEdit {
        get { return isBillOnEdit; }
        set {
            isBillOnEdit = value;
            if (value) cloneBill();
            else updateBill();
        }
    }
    bool areEntriesOnEdit;
    public bool AreEntriesOnEdit {
        get { return areEntriesOnEdit; }
        set {
            areEntriesOnEdit = value;
            if (value) cloneBillEntries();
            else updateBillEntries();
        }
    }
    ReportEntry selectedBill;
    public ReportEntry SelectedBill {
        get { return selectedBill; }
        set {
            selectedBill = value;
            updateEntryInfo();
            OnPropertyChanged(nameof(SelectedBill));
        }
    }
    public bool HasAccount { get; set; }
    public ReportEntry EditedBill { get; set; }
    public Account SelectedAccount { get; set; }
    public Account EditedAccount { get; set; }
    public BitmapImage Bitmap { get; set; }
    public bool HasSelectedItem { get; set; }
    public ICollectionView SelectionView { get; }
    public List<Breakup> Breakups { get; set; }
    public List<KeyValueSeries> PieValues { get; set; }
    public List<PinSeries> PinLineValues { get; set; }
    public List<Breakup> EditedBreakups { get; set; }
    public ICollectionView Reportables { get; set; }
    public abstract int DeptId { get; }
    public event Action BillAdjusted;
    public SearchBaseVM() {
        Reportables = CollectionViewSource.GetDefaultView(new List<int>());
        accounts = new CollectionViewSource() {
            Source = AppData.accounts,
            IsLiveFilteringRequested = true
        };
        SelectionView = accounts.View;
        SelectionView.Filter = filter;
    }
    bool filter(object o) {
        var acc = (Account)o;
        if (string.IsNullOrWhiteSpace(QueryAccount)) return acc.DeptId == DeptId;
        return acc.DeptId == DeptId && acc.AccountNo.Contains(QueryAccount);
    }
    bool filterParticulars(object o) {
        if (string.IsNullOrWhiteSpace(QueryParticulars)) return true;
        return ((ReportEntry)o).Period.Contains(QueryParticulars);
    }
    void updateReportables() {
        PieValues = null;
        OnPropertyChanged(nameof(PieValues));
        if (AccountId == null) {
            Reportables = null;
            SelectedAccount = null;
            HasAccount = false;
            OnPropertyChanged(nameof(Reportables));
            OnPropertyChanged(nameof(SelectedAccount));
            OnPropertyChanged(nameof(HasAccount));
            return;
        }
        SelectedAccount = AppData.accounts.First(x => x.Id == AccountId);
        OnPropertyChanged(nameof(SelectedAccount));

        reserved = new List<ReportEntry>();
        lock (SQL.key) {
            SQL.command.CommandText = $@"SELECT b.Id, DeptId, BillNo, Period, TransactionId, m.Name, PaymentDate, FileName,
                                   (SELECT sum(Amount) FROM BillEntries WHERE BillId = b.Id),
                                   (SELECT sum(Amount) FROM PaymentEntries WHERE BillId = b.Id)
                                   FROM Bills b
                                   LEFT JOIN Mobile m ON m.Id = b.MobileId
                                   WHERE AccountId = {AccountId}
                                   ORDER BY PaymentDate";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                reserved.Add(new ReportEntry() {
                    BillId = reader.GetInt32(0),
                    DeptId = reader.GetInt32(1),
                    BillNo = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Period = reader.GetString(3),
                    TransactionId = reader.GetString(4),
                    Mobile = reader.IsDBNull(5) ? null : reader.GetString(5),
                    PaymentDate = reader.GetDateTime(6),
                    FileName = reader.GetString(7),
                    Bill = reader.GetDouble(8),
                    Payment = reader.GetDouble(9)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        if (reserved.Count > 0) {
            Reportables = new CollectionViewSource() {
                Source = reserved,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { nameof(ReportEntry.PaymentDate) }
            }.View;
            Reportables.SortDescriptions.Add(new SortDescription(nameof(ReportEntry.PaymentDate), ListSortDirection.Descending));
            Reportables.Filter = filterParticulars;
        }
        else Reportables = null;
            
        if (!HasAccount) {
            HasAccount = true;
            OnPropertyChanged(nameof(HasAccount));
        }
        OnPropertyChanged(nameof(Reportables));
        BillAdjusted?.Invoke();
        updatePinLine();
    }
    void updateEntryInfo() {
        Breakups = new List<Breakup>();
        PieValues = new List<KeyValueSeries>();
        HasSelectedItem = true;
        if (SelectedBill is null) {
            Bitmap = null;
            HasSelectedItem = false;
            OnPropertyChanged(nameof(Bitmap));
            OnPropertyChanged(nameof(Breakups));
            OnPropertyChanged(nameof(HasSelectedItem));
            OnPropertyChanged(nameof(PieValues));
            return;
        }
        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH T1(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, Amount , null, Id, null FROM BillEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ), 
                                        T2(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, null, Amount, null, Id FROM PaymentEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ),
                                        --T3 FULL OUTER JOIN
                                        T3 (Head, Bill, Payment, BillId, PaymentId) AS (
                                            SELECT t1.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T1 t1 LEFT JOIN T2 t2 ON t1.Head = t2.Head	
                                            UNION  ALL
                                            SELECT t2.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T2 t2 LEFT JOIN T1 t1 ON t2.Head = t1.Head
                                            WHERE t1.Head IS NULL
                                        )
                                        SELECT h.Name, coalesce(Bill, 0), coalesce(Payment, 0), coalesce(BillId, 0), coalesce(PaymentId, 0) 
                                        FROM T3 LEFT JOIN Heads h ON h.Id = Head
                                        ORDER BY h.Id";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Breakups.Add(new Breakup() {
                    Head = reader.GetString(0),
                    Bill = reader.GetDouble(1),
                    Payment = reader.GetDouble(2),
                    BillId = reader.GetInt32(3),
                    PaymentId = reader.GetInt32(4)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        OnPropertyChanged(nameof(Breakups));
        OnPropertyChanged(nameof(HasSelectedItem));
        upDatePie();
        imagePath = Constants.ImageFolder + "/" + SelectedBill.FileName;
        if (!System.IO.File.Exists(imagePath)) {
            Bitmap = null;
            OnPropertyChanged(nameof(Bitmap));
            return;
        }
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
    }
    void cloneAccount() {
        EditedAccount = new Account() {
            Id = SelectedAccount.Id,
            DeptId = SelectedAccount.DeptId,
            AccountNo = SelectedAccount.AccountNo,
            Name = SelectedAccount.Name,
            Address = SelectedAccount.Address
        };
        OnPropertyChanged(nameof(EditedAccount));
    }
    void updateAccount() {
        if (EditedAccount.Name.Equals(SelectedAccount.Name) &&
            EditedAccount.Address.Equals(SelectedAccount.Address) &&
            EditedAccount.AccountNo.Equals(SelectedAccount.AccountNo)) return;

        AppData.UpdateAccount(EditedAccount);
        SelectedAccount.AccountNo = EditedAccount.AccountNo;
        SelectedAccount.Name = EditedAccount.Name;
        SelectedAccount.Address = EditedAccount.Address;
        SelectedAccount.OnPropertyChanged(null);
    }
    void cloneBill() {
        EditedBill = new ReportEntry() {
            BillId = SelectedBill.BillId,
            DeptId = SelectedBill.DeptId,
            BillNo = SelectedBill.BillNo,
            FileName = SelectedBill.FileName,
            PaymentDate = SelectedBill.PaymentDate,
            Period = SelectedBill.Period,
            TransactionId = SelectedBill.TransactionId,
            Mobile = SelectedBill.Mobile
        };
        OnPropertyChanged(nameof(EditedBill));
    }
    void updateBill() {
        bool isDateEqual = SelectedBill.PaymentDate.Equals(EditedBill.PaymentDate);
        bool isTransactionEqual = SelectedBill.TransactionId.Equals(EditedBill.TransactionId);
        if (SelectedBill.Period.Equals(EditedBill.Period) &&
            isDateEqual && isTransactionEqual &&
            SelectedBill.BillNo.Equals(EditedBill.BillNo) &&
            SelectedBill.Mobile.Equals(EditedBill.Mobile)) return;

        if (isDateEqual && isTransactionEqual) AppData.UpdateBill(EditedBill);
        else {
            var date = EditedBill.PaymentDate.ToString("yyyy-MM-dd");
            var dept = AppData.departments.First(x => x.Id == EditedBill.DeptId).Name;
            var newFileName = $"{date}-{dept}-{EditedBill.TransactionId}.png";
            AppData.UpdateBill(EditedBill, newFileName);
            EditedBill.FileName = newFileName;
        }
        SelectedBill.BillNo = EditedBill.BillNo;
        SelectedBill.FileName = EditedBill.FileName;
        SelectedBill.PaymentDate = EditedBill.PaymentDate;
        SelectedBill.Period = EditedBill.Period;
        SelectedBill.TransactionId = EditedBill.TransactionId;
        SelectedBill.Mobile = EditedBill.Mobile;
        SelectedBill.OnPropertyChanged(null);
        if (!isDateEqual) updatePinLine();
    }
    void cloneBillEntries() {
        EditedBreakups = new List<Breakup>();
        foreach (var item in Breakups) {
            EditedBreakups.Add(new Breakup() {
                Head = item.Head,
                Bill = item.Bill,
                Payment = item.Payment,
                BillId = item.BillId,
                PaymentId = item.PaymentId
            });
        }
        OnPropertyChanged(nameof(EditedBreakups));
    }
    void updateBillEntries() {
        List<UpdatedEntry> entries = new();
        double billAdjustment = 0;
        double paymentAdjustment = 0;
        for (int i = 0; i < Breakups.Count; i++) {
            if (Breakups[i].Bill != EditedBreakups[i].Bill) {
                entries.Add(new UpdatedEntry() {
                    Table = "BillEntries",
                    Id = Breakups[i].BillId,
                    Amount = EditedBreakups[i].Bill
                });
                billAdjustment += (EditedBreakups[i].Bill - Breakups[i].Bill);
            }
            if (Breakups[i].Payment != EditedBreakups[i].Payment) {
                entries.Add(new UpdatedEntry() {
                    Table = "PaymentEntries",
                    Id = Breakups[i].PaymentId,
                    Amount = EditedBreakups[i].Payment
                });
                paymentAdjustment += (EditedBreakups[i].Payment - Breakups[i].Payment);
            }
        }
        if (entries.Count == 0) return;
        AppData.UpdateEntries(entries);
        Breakups = EditedBreakups;
        SelectedBill.Bill += billAdjustment;
        SelectedBill.Payment += paymentAdjustment;

        OnPropertyChanged(nameof(Breakups));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Bill));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Payment));
        BillAdjusted?.Invoke();

        PieValues = new List<KeyValueSeries>();
        upDatePie();
        foreach (var pin in PinLineValues) {
            if (pin.Date.Equals(SelectedBill.PaymentDate)) {
                updatePinLine();
                break;
            }
        }
    }
    void updatePinLine() {
        if (reserved.Count > 15) {
            PinLineValues = reserved
                .Skip(reserved.Count - 15)
                .Select(x => new PinSeries() {
                    Date = x.PaymentDate,
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                })
                .OrderBy(x => x.Date).ToList();
        }
        else PinLineValues = reserved.
                Select(x => new PinSeries() {
                    Date = x.PaymentDate,
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                })
                .OrderBy(x => x.Date).ToList();
        OnPropertyChanged(nameof(PinLineValues));
    }
    void upDatePie() {
        foreach (var breakup in Breakups) {
            PieValues.Add(new KeyValueSeries() {
                Name = breakup.Head,
                Total = breakup.Head.Equals("Amount") ? breakup.Bill : breakup.Payment + breakup.Bill
            });
        }
        OnPropertyChanged(nameof(PieValues));
    }
    public void MakeBlackWhite() {
        state = ColorState.BlackWhite;
        Bitmap = ImageProcessor.GetBlackAndWhite(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeGray() {
        state = ColorState.Gray;
        Bitmap = ImageProcessor.GetGrayScale(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeNormal() {
        state = ColorState.Color;
        Bitmap = ImageProcessor.GetNormal(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void Refresh() => updateReportables();
    public void Sort() {
        if (Reportables is null) return;
        var oldSort = Reportables.SortDescriptions.First();
        var newSort = new SortDescription() { PropertyName = nameof(ReportEntry.PaymentDate) };
        if (oldSort.Direction == ListSortDirection.Descending) {
            newSort.Direction = ListSortDirection.Ascending;
        }
        else newSort.Direction = ListSortDirection.Descending;
        Reportables.SortDescriptions.Clear();
        Reportables.SortDescriptions.Add(newSort);
    }
}
