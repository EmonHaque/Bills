﻿class ReportEntry : Notifiable
{
    public int BillId { get; set; }
    public int DeptId { get; set; }
    public int AccountId { get; set; }
    public string AccountNo { get; set; }
    public string BillNo { get; set; }
    public string Period { get; set; }
    public string TransactionId { get; set; }
    public string Mobile { get; set; }
    public string FileName { get; set; }
    public DateTime PaymentDate { get; set; }
    public double Bill { get; set; }
    public double Payment { get; set; }
}
