﻿class RawInfo : Notifiable
{
    public string FileName { get; set; }
    public string OutputFileName { get; set; }
    public string FilePath { get; set; }
    public string RawText { get; set; }
    public double TotalPayment { get; set; }
    public double TotalBill { get; set; }
    public int DeptId { get; set; }
    public int CustomerId { get; set; }
    public int MobileId { get; set; }
    public bool IsOk { get; set; }
    public bool IsDuplicate { get; set; }
    public bool HasImageWithSameName { get; set; }
    public ObservableCollection<AmountInfo> PaymentInfo { get; set; }
    public ObservableCollection<AmountInfo> BillInfo { get; set; }
    string department;
    public string Department {
        get { return department; }
        set { department = value; resetOk(); }
    }
    string customerNo;
    public string CustomerNo {
        get { return customerNo; }
        set { customerNo = value; resetOk(); }
    }
    string paymentDate;
    public string PaymentDate {
        get { return paymentDate; }
        set { paymentDate = value; resetOk(); }
    }
    string paidFrom;
    public string PaidFrom {
        get { return paidFrom; }
        set { paidFrom = value; resetOk(); }
    }
    string transactionNo;
    public string TransactionNo {
        get { return transactionNo; }
        set { transactionNo = value; resetOk(); }
    }
    string billNo;
    public string BillNo {
        get { return billNo; }
        set { billNo = value; resetOk(); }
    }
    string period;
    public string Period {
        get { return period; }
        set { period = value; resetOk(); }
    }
    public event Action AdjustOk;
    public RawInfo() {
        PaymentInfo = new ObservableCollection<AmountInfo>();
        BillInfo = new ObservableCollection<AmountInfo>();
    }
    void resetOk() {
        if (HasImageWithSameName) {
            HasImageWithSameName = false;
            OnPropertyChanged(nameof(HasImageWithSameName));
        }
        if (IsOk) AdjustOk?.Invoke();
    }
}
