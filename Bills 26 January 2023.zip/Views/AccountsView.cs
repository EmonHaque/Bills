﻿class AccountsView : View
{
    public override string Icon => Icons.Accounts;
    public override FrameworkElement container => grid;
    Grid grid;
    public AccountsView() {
        var accounts = new DeptAccountsView();
        var mobiles = new MobileView();
        var deptHeads = new ViewContainer(NavPosition.Bottom) {
            Children = { 
                new DeptView(),
                new HeadView()
            }
        };
        Grid.SetRowSpan(accounts, 2);
        Grid.SetColumn(mobiles, 1);
        Grid.SetColumn(deptHeads, 1);
        Grid.SetRow(deptHeads, 1);
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star) },
                new ColumnDefinition()
            },
            Children = {accounts, mobiles, deptHeads}
        };
        AddVisualChild(grid);
    }
}
