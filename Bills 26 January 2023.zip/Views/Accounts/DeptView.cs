﻿class DeptView : CardView
{
    public override string Header => "Departments";
    public override string Icon => Icons.Description;

    ListBox list;
    DeptVM vm;
    public DeptView() {
        vm = new DeptVM();
        DataContext = vm;
        list = new ListBox() { DisplayMemberPath = nameof(Department.Name) };
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Departments)));
        setContent(list);
    }
}
