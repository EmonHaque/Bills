﻿class DateSearch : CardView
{
    public override string Header => "Payment";
    public override string Icon => Icons.Calendar;

    DayPicker date;
    ActionButton refresh;
    EditText search;
    ListBox entries;
    TextBlock totalBill, totalPayment;
    Run totalText;
    Image image;
    Grid left, right;
    Border middle;
    AccountControl account;
    BillControl bill;
    BillEntryControl billEntries;
    PieChart deptPie, billPie;
    DateSearchVM vm;
    public DateSearch() {
        vm = new DateSearchVM();
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        initializeLeftGrid();
        initializeMiddleBorder();
        initializeRightGrid();
        Grid.SetColumn(middle, 1);
        Grid.SetColumn(right, 2);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = { left, middle, right }
        };
        setContent(grid);
    }
    void bind() {
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.SelectedDate)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        entries.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedBill)));
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        image.SetBinding(Image.SourceProperty, new Binding(nameof(vm.Bitmap)));
        totalBill.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalBill)) { StringFormat = "N2" });
        totalPayment.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPayment)) { StringFormat = "N2" });
        totalText.SetBinding(Run.TextProperty, new Binding(nameof(vm.TotalItem)));

        account.SetBinding(AccountControl.NameProperty, new Binding($"{nameof(vm.SelectedAccount)}.{nameof(Account.Name)}"));
        account.SetBinding(AccountControl.AddressProperty, new Binding($"{nameof(vm.SelectedAccount)}.{nameof(Account.Address)}"));
        account.SetBinding(AccountControl.IsOnEditProperty, new Binding(nameof(vm.IsAccountOnEdit)));
        account.SetBinding(AccountControl.EditedNameProperty, new Binding($"{nameof(vm.EditedAccount)}.{nameof(Account.Name)}"));
        account.SetBinding(AccountControl.EditedAddressProperty, new Binding($"{nameof(vm.EditedAccount)}.{nameof(Account.Address)}"));
        account.SetBinding(AccountControl.EditedAccountNoProperty, new Binding($"{nameof(vm.EditedAccount)}.{nameof(Account.AccountNo)}"));

        bill.SetBinding(BillControl.DeptIdProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.DeptId)}"));
        bill.SetBinding(BillControl.DateProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.PaymentDate)}") { StringFormat = "yyyy-MM-dd" });
        bill.SetBinding(BillControl.BillNoProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.BillNo)}"));
        bill.SetBinding(BillControl.TransactionProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.TransactionId)}"));
        bill.SetBinding(BillControl.PeriodProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.Period)}"));
        bill.SetBinding(BillControl.MobileNoProperty, new Binding($"{nameof(vm.SelectedBill)}.{nameof(ReportEntry.Mobile)}"));
        bill.SetBinding(BillControl.IsOnEditProperty, new Binding(nameof(vm.IsBillOnEdit)));
        bill.SetBinding(BillControl.EditedDateProperty, new Binding($"{nameof(vm.EditedBill)}.{nameof(ReportEntry.PaymentDate)}") { StringFormat = "yyyy-MM-dd" });
        bill.SetBinding(BillControl.EditedBillNoProperty, new Binding($"{nameof(vm.EditedBill)}.{nameof(ReportEntry.BillNo)}"));
        bill.SetBinding(BillControl.EditedTransactionProperty, new Binding($"{nameof(vm.EditedBill)}.{nameof(ReportEntry.TransactionId)}"));
        bill.SetBinding(BillControl.EditedPeriodProperty, new Binding($"{nameof(vm.EditedBill)}.{nameof(ReportEntry.Period)}"));
        bill.SetBinding(BillControl.EditedMobileNoProperty, new Binding($"{nameof(vm.EditedBill)}.{nameof(ReportEntry.Mobile)}"));

        billEntries.SetBinding(BillEntryControl.SourceProperty, new Binding(nameof(vm.Breakups)));
        billEntries.SetBinding(BillEntryControl.IsOnEditProperty, new Binding(nameof(vm.AreEntriesOnEdit)));
        billEntries.SetBinding(BillEntryControl.EditedSourceProperty, new Binding(nameof(vm.EditedBreakups)));
        deptPie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.DeptPieValues)));
        billPie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.PieValues)));

    }
    void initializeLeftGrid() {
        refresh = new ActionButton() {
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 5, 0, 0),
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = vm.Refresh
        };
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy"
        };
        Grid.SetColumn(refresh, 1);
        var topGrid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() {Width = GridLength.Auto}
            },
            Children = { date, refresh }
        };
        search = new EditText() {
            Icon = Icons.Magnify,
            Hint = "Account"
        };

        #region header
        TextBlock particulardBlock, billBlock, paymentBlock;
        particulardBlock = new TextBlock() { Text = "Particulars" };
        billBlock = new TextBlock() { Text = "Bill", HorizontalAlignment = HorizontalAlignment.Right };
        paymentBlock = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billBlock, 1);
        Grid.SetColumn(paymentBlock, 2);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { particulardBlock, billBlock, paymentBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion
        entries = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new DateSearchEntryTemplate(vm),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)){
                            Setters = { new Setter(GroupItem.TemplateProperty, new AccountGroupTemplate())}
                    }
                }
            },
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                            }
                        }
                    }
                }
        };
        entries.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        entries.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        #region footer
        
        totalText = new Run();
        var totalTextBlock = new TextBlock() {
            Inlines = { new Run("Total "), totalText }
        };
        totalBill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBill, 1);
        Grid.SetColumn(totalPayment, 2);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalTextBlock, totalBill, totalPayment }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion
        Grid.SetRow(search, 1);
        Grid.SetRow(header, 2);
        Grid.SetRow(entries, 3);
        Grid.SetRow(footer, 4);
        left = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto }
            },
            Children = { topGrid, search, header, entries, footer }
        };
    }
    void initializeMiddleBorder() {
        var blackWhite = new ActionButton() {
            Icon = Icons.ImageBW,
            ToolTip = "Black & White",
            Command = vm.MakeBlackWhite
        };
        var gray = new ActionButton() {
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.ImageGray,
            ToolTip = "GrayScale",
            Command = vm.MakeGray
        };
        var normal = new ActionButton() {
            Icon = Icons.ImageColor,
            ToolTip = "Camera",
            Command = vm.MakeNormal
        };
        var stack = new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 0, 5),
            Children = { blackWhite, gray, normal }
        };
        image = new Image();
        var scroll = new ScrollViewerEx() { Content = image };
        Grid.SetRow(scroll, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { stack, scroll }
        };
        middle = new Border() {
            Margin = new Thickness(10, 0, 10, 0),
            Padding = new Thickness(5, 0, 5, 0),
            BorderThickness = new Thickness(1, 0, 1, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }
    void initializeRightGrid() {
        account = new AccountControl();
        bill = new BillControl();
        billEntries = new BillEntryControl();
        billPie = new PieChart();
        deptPie = new PieChart();
        Grid.SetRow(bill, 1);
        Grid.SetRow(billEntries, 2);
        Grid.SetRow(billPie, 3);
        var bottmGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { account, bill, billEntries, billPie }
        };
        Grid.SetRow(bottmGrid, 1);

        right = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(1.75, GridUnitType.Star) }
            },
            Children = { deptPie, bottmGrid }
        };
    }
}
