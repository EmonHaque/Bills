﻿class Wasa : AccountSearchBase
{
    public override string Icon => Icons.Water;
    public override string Header => "WASA";
    WasaVM viewModel = new();
    protected override AccountSearchBaseVM vm => viewModel;
    //protected override string display => "Name";
    public Wasa() : base() { }
   
}
