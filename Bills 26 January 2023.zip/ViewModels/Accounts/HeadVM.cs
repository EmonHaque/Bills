﻿class HeadVM
{
    public ICollectionView Heads { get; set; }
    public HeadVM() {
        Heads = new CollectionViewSource() {
            Source = AppData.heads,
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Head.Name) },
        }.View;
        Heads.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Head.Name)));
    }
}
