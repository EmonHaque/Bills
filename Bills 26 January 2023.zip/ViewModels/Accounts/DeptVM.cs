﻿class DeptVM
{
    public ICollectionView Departments { get; set; }
    public DeptVM() {
        Departments = new CollectionViewSource() {
            Source = AppData.departments,
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Department.Name) },
        }.View;
        Departments.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Department.Name)));
    }
}
