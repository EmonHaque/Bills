﻿class Constants
{
    public const string ImageFolder = "images";
    public const string TempFolder = "temp";
    public const string DBName = "bills.db";
    public const string ConnectionString = "data source = " + DBName;
    public const double ScrollBarThickness = 12;
    public const double DateColumnWidth = 70;
    public const double AmountColumnWidth = 80;
    public const string NumberFormat = "#,##0.00;(#,##0.00);-    ";
    public static Thickness CardMargin = new Thickness(7);
    public static Brush Background = new SolidColorBrush(Color.FromRgb(50, 50, 50));
    public static Brush BackgroundDark = new SolidColorBrush(Color.FromRgb(60, 60, 60));
}
