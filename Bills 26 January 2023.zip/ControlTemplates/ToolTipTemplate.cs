﻿class ToolTipTemplate : ControlTemplate
{
    public ToolTipTemplate() {
        TargetType = typeof(ToolTip);
        var border = new FrameworkElementFactory(typeof(Border));
        var content = new FrameworkElementFactory(typeof(ContentPresenter));

        border.SetValue(Border.BorderThicknessProperty, new Thickness(0.5));
        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        border.SetValue(Border.BackgroundProperty, Constants.Background);
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(3));
        border.SetValue(Border.PaddingProperty, new Thickness(4, 2, 4, 2));
        border.SetValue(TextElement.ForegroundProperty, Brushes.LightGray);

        border.AppendChild(content);
        VisualTree = border;
    }
}
