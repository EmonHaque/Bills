﻿class AccountErrorDialog : Window
{
    Account account;
    EditText department, accountNo, name, address;
    ActionButton ok, cancel;
    public AccountErrorDialog(double left, double top, double width, double height, Account account) {
        this.account = account;
        Left = left;
        Top = top;
        Width = width;
        Height = height;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });
        initializeContent();
    }

    void initializeContent() {
        var header = new TextBlock() {
            Margin = new Thickness(0, 0, 0, 10),
            FontSize = 18,
            Text = "Wrong Account"
        };
        department = new EditText() {
            Hint = "Department",
            Icon = Icons.Business,
            Text = AppData.departments.First(x => x.Id == account.DeptId).Name,
            IsEnabled = false,
        };
        accountNo = new EditText() {
            Hint = "Account",
            Icon = Icons.ID,
            Text = account.AccountNo,
            IsEnabled = false
        };
        name = new EditText() { Hint = "Name", Icon = Icons.Tenant, Text = account.Name };
        address = new EditText() { Hint = "Address", Icon = Icons.Address, Text = account.Address };

        ok = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Left,
            ToolTip = "Ok",
            Width = 24,
            Height = 24,
            Margin = new Thickness(5, 10, 0, 0),
            Icon = Icons.Ok,
            Command = () => {
                DialogResult = true;
                Close();
            }
        };
        cancel = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            ToolTip = "Cancel",
            Width = 24,
            Height = 24,
            Margin = new Thickness(0, 10, 5, 0),
            Icon = Icons.Cancel,
            Command = () => {
                DialogResult = false;
                Close();
            }
        };
        var buttons = new Grid() {
            Margin = new Thickness(5, 10, 5, 5),
            Children = { ok, cancel }
        };
        Content = new Border() {
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(10),
            Background = Constants.Background,
            Width = this.Width * 0.8,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Child = new StackPanel() {
                Children = { header, department, accountNo, name, address, buttons }
            }
        };
    }
    protected override void OnPreviewMouseWheel(MouseWheelEventArgs e) {
        base.OnPreviewMouseWheel(e);
        double size = (double)GetValue(TextElement.FontSizeProperty);
        if (e.Delta > 0) SetValue(TextElement.FontSizeProperty, ++size);
        else if (size > 12) SetValue(TextElement.FontSizeProperty, --size);
    }
}
