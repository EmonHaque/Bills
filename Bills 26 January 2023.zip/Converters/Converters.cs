﻿class Converters
{
    public static AccountSummaryConverter ASC = new();
    public static DeptIdToNameConverter D2N = new();
    public static DetailReportGroupSummaryConverter DRGSC = new();
    public static FooterFontStyleConverter FFSC = new();
    public static LoadGroupSummaryConverter LGSC = new();
    public static MobileGroupSummaryConverter MGSC = new();
    public static ReportGroupSummaryConverter RGSC = new();
    public static BooleanToVisibilityConverter B2V = new();
    public static DistinctItemCountConverter DCC = new();
    public static DetailReportSingleItemConverter DRSIC = new();
    public static DetailGroupLevel2Thickness DGL2T = new();
    public static DetailGroupState2ToolTip DG2TT = new();
}
