﻿class DetailReportSingleItemConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        byte state = (byte)values[0];
        var entry = (SummaryEntry)((ReadOnlyObservableCollection<object>)values[1])[0];
        var text = state == 0 ? entry.Head + " - " + entry.AccountNo : entry.AccountNo + " - " + entry.Head;
        return new SummaryEntry() {
            AccountName = entry.AccountName,
            AccountAddress = entry.AccountAddress,
            AccountNo = text,
            Bill = entry.Bill,
            Payment = entry.Payment
        };
    }

    public object[] ConvertBack(object value, Type[] targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}