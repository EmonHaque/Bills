﻿class AccountSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        double sum = 0;
        if (group.IsBottomLevel) {
            var items = group.Items.OfType<SummaryAccount>();
            sum = items.Sum(x => x.Amount);
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                sum += (double)Convert(subGroup, null, null, null);
            }
        }
        return sum;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
