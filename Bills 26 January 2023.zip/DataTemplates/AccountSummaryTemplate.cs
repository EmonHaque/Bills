﻿class AccountSummaryTemplate : DataTemplate
{
    public AccountSummaryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var accountBlock = new FrameworkElementFactory(typeof(TextBlock));
        var account = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var amount = new FrameworkElementFactory(typeof(TextBlock));
        
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        amount.SetValue(Grid.ColumnProperty, 1);

        account.SetBinding(Run.TextProperty, new Binding(nameof(SummaryAccount.Account)));
        count.SetBinding(Run.TextProperty, new Binding(nameof(SummaryAccount.Count)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryAccount.Amount)) { StringFormat = Constants.NumberFormat });
        grid.SetValue(Grid.ToolTipProperty, new AccountSummaryTemplateToolTip());

        accountBlock.AppendChild(account);
        accountBlock.AppendChild(openParen);
        accountBlock.AppendChild(count);
        accountBlock.AppendChild(closeParen);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(accountBlock);
        grid.AppendChild(amount);
        VisualTree = grid;
    }
}
