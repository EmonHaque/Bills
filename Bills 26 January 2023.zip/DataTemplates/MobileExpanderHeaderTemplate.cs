﻿class MobileExpanderHeaderTemplate : DataTemplate
{
    public MobileExpanderHeaderTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var header = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var headerBlock = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));

        header.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        total.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        total.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        header.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(GroupItem.Name)) {
            Mode = BindingMode.OneWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1)
        });
        count.SetBinding(Run.TextProperty, new Binding("DataContext." + nameof(CollectionViewGroup.ItemCount)) {
            Mode = BindingMode.OneWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1)
        });
        total.SetBinding(TextBlock.TextProperty, new Binding("DataContext") {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(Expander), 1),
            Mode = BindingMode.OneWay,
            StringFormat = Constants.NumberFormat,
            Converter = Converters.MGSC
        });

        headerBlock.AppendChild(header);
        headerBlock.AppendChild(openParen);
        headerBlock.AppendChild(count);
        headerBlock.AppendChild(closeParen);

        grid.AppendChild(headerBlock);
        grid.AppendChild(total);

        VisualTree = grid;
    }
}
