﻿class MobileEntryTemplate : DataTemplate
{
    public MobileEntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var dateAndAccount = new FrameworkElementFactory(typeof(TextBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));
        var date = new FrameworkElementFactory(typeof(Run));
        var space = new FrameworkElementFactory(typeof(Run));
        var account = new FrameworkElementFactory(typeof(Run));

        amount.SetValue(Grid.ColumnProperty, 1);
        space.SetValue(Run.TextProperty, " | ");
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        date.SetBinding(Run.TextProperty, new Binding(nameof(MobileEntry.Date)) { StringFormat = "dd" });
        account.SetBinding(Run.TextProperty, new Binding(nameof(MobileEntry.Account)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(MobileEntry.Amount)) { StringFormat = "N2" });
        grid.SetValue(Grid.ToolTipProperty, new DetailSummaryEntryTemplateToolTip());

        dateAndAccount.AppendChild(date);
        dateAndAccount.AppendChild(space);
        dateAndAccount.AppendChild(account);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(dateAndAccount);
        grid.AppendChild(amount);

        VisualTree = grid;
    }
}