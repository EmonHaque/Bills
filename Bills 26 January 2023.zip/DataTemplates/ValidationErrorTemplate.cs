﻿class ValidationErrorTemplate : DataTemplate
{
    public ValidationErrorTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var headBlock = new FrameworkElementFactory(typeof(TextBlock));
        var errorBlock = new FrameworkElementFactory(typeof(TextBlock));

        grid.SetValue(Grid.MarginProperty, new Thickness(5));
        col1.SetValue(ColumnDefinition.SharedSizeGroupProperty, "col1");
        headBlock.SetValue(TextBlock.ForegroundProperty, Brushes.CornflowerBlue);
        headBlock.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        errorBlock.SetValue(Grid.ColumnProperty, 1);
        errorBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        errorBlock.SetValue(TextBlock.MarginProperty, new Thickness(10, 0, 0, 0));
        headBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(ValidationError.Head)));
        errorBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(ValidationError.Error)));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(headBlock);
        grid.AppendChild(errorBlock);
        VisualTree = grid;
    }
}
