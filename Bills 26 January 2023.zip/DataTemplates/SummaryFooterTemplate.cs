﻿class SummaryFooterTemplate : DataTemplate
{
    public SummaryFooterTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var separator = new FrameworkElementFactory(typeof(Separator)) { Name = "separator" };
        var text = new FrameworkElementFactory(typeof(TextBlock)) { Name = "total" };
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));
        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                    new Setter(Grid.RowProperty, 1)
                }
        });

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        
        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        separator.SetValue(Grid.ColumnProperty, 1);
        separator.SetValue(Grid.ColumnSpanProperty, 3);
        separator.SetValue(Separator.BackgroundProperty, Brushes.LightGray);
        bill.SetValue(Grid.ColumnProperty, 1);
        payment.SetValue(Grid.ColumnProperty, 2);

        text.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);

        text.SetBinding(TextBlock.TextProperty, new Binding("Item1"));
        text.SetBinding(TextBlock.FontStyleProperty, new Binding("Item4") { Converter = Converters.FFSC });
        bill.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });
        payment.SetBinding(TextBlock.TextProperty, new Binding("Item3") { StringFormat = Constants.NumberFormat });
        separator.SetBinding(Separator.VisibilityProperty, new Binding("Item4") { Converter = Converters.B2V});

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(separator);
        grid.AppendChild(text);
        grid.AppendChild(bill);
        grid.AppendChild(payment);

        VisualTree = grid;
    }
}
