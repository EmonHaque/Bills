﻿class LoadTemplate : DataTemplate
{
    public LoadTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid" };
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var block = new FrameworkElementFactory(typeof(TextBlock));
        var okIcon = new FrameworkElementFactory(typeof(Path)) { Name = "okIcon" };
        var hasImageIcon = new FrameworkElementFactory(typeof(Path)) { Name = "hasImageIcon" };

        grid.SetValue(Grid.BackgroundProperty, Brushes.Transparent);
        col2.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col3.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);

        hasImageIcon.SetValue(Grid.ColumnProperty, 1);
        hasImageIcon.SetValue(Path.VisibilityProperty, Visibility.Collapsed);
        hasImageIcon.SetValue(Path.DataProperty, Geometry.Parse(Icons.QuestionMap));
        hasImageIcon.SetValue(Path.WidthProperty, 12d);
        hasImageIcon.SetValue(Path.HeightProperty, 12d);
        hasImageIcon.SetValue(Path.StretchProperty, Stretch.Uniform);
        hasImageIcon.SetValue(Path.FillProperty, Brushes.Coral);
        hasImageIcon.SetValue(Path.VerticalAlignmentProperty, VerticalAlignment.Center);
        hasImageIcon.SetValue(Path.MarginProperty, new Thickness(5, 0, 5, 0));
        hasImageIcon.SetValue(Path.ToolTipProperty, $"Check {Constants.ImageFolder} for image with same Transaction No");

        okIcon.SetValue(Grid.ColumnProperty, 2);
        okIcon.SetValue(Path.VisibilityProperty, Visibility.Collapsed);
        okIcon.SetValue(Path.DataProperty, Geometry.Parse(Icons.Checked));
        okIcon.SetValue(Path.WidthProperty, 12d);
        okIcon.SetValue(Path.HeightProperty, 12d);
        okIcon.SetValue(Path.StretchProperty, Stretch.Uniform);
        okIcon.SetValue(Path.FillProperty, Brushes.Gray);
        okIcon.SetValue(Path.VerticalAlignmentProperty, VerticalAlignment.Center);

        block.SetBinding(TextBlock.TextProperty, new Binding(nameof(RawInfo.FileName)));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(block);
        grid.AppendChild(hasImageIcon);
        grid.AppendChild(okIcon);
        VisualTree = grid;

        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(RawInfo.IsOk)),
            Value = true,
            Setters = {
                new Setter(Path.VisibilityProperty, Visibility.Visible, "okIcon")
            }
        });
        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(RawInfo.HasImageWithSameName)),
            Value = true,
            Setters = {
                new Setter(Path.VisibilityProperty, Visibility.Visible, "hasImageIcon")
            }
        });
        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(RawInfo.IsDuplicate)),
            Value = true,
            Setters = {
                new Setter(TextElement.ForegroundProperty, Brushes.CornflowerBlue, "grid")
            }
        });
    }
}
