﻿class CommandButton : ActionButton
{
    public CommandButton() : base() {
        Focusable = true;
        Width = 14;
        Height = 14;
    }
    protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(highlightColor);
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(normalColor);
    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        Command.Invoke();
    }
    protected override void OnKeyDown(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        animateBrush(downColor);
    }
}
