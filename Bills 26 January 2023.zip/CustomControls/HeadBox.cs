﻿class HeadBox : TextBox
{
    bool userMode;
    Popup popup;
    ListBox list;
    CollectionViewSource source;
    ICollectionView view;

    public HeadBox() {
        BorderThickness = new Thickness(0);
        Padding = new Thickness(2, 0, 0, 0);
        source = new CollectionViewSource() { Source = AppData.heads };
        view = source.View;
        view.Filter = filter;
        list = new ListBox() {
            Padding = new Thickness(5),
            BorderThickness = new Thickness(1),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemsSource = view,
            DisplayMemberPath = nameof(Head.Name)
        };
        popup = new Popup() {
            AllowsTransparency = true,
            HorizontalOffset = 2,
            MaxHeight = 300,
            StaysOpen = false,
            PlacementTarget = this,
            Child = list
        };
        Loaded += subscribe;
        Unloaded += unSubscribe;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Text)) return true;
        return ((Head)o).Name.ToLower().Contains(Text.ToLower());
    }

    void subscribe(object sender, RoutedEventArgs e) {
        list.KeyUp += setTextOnEnter;
        list.MouseLeftButtonUp += setTextOnClick;
        userMode = true;
    }

    void unSubscribe(object sender, RoutedEventArgs e) {
        list.KeyUp -= setTextOnEnter;
        list.MouseLeftButtonUp -= setTextOnClick;
    }

    void setTextOnClick(object sender, MouseButtonEventArgs e) {
        setText();
        CaretIndex = Text.Length;
        popup.IsOpen = false;
        Keyboard.Focus(this);
    }

    void setTextOnEnter(object sender, KeyEventArgs e) {
        if (e.Key == Key.Escape) {
            popup.IsOpen = false;
            return;
        }
        if (e.Key == Key.Tab || e.Key == Key.Enter) {
            setText();
            CaretIndex = Text.Length;
            popup.IsOpen = false;
            Keyboard.Focus(this);
        }

    }
    void setText() => Text = ((Head)list.SelectedItem).Name;

    protected override void OnKeyDown(KeyEventArgs e) {
        if (e.Key == Key.Tab) {
            e.Handled = true;
            if (popup.IsOpen) {
                if (list.SelectedIndex == -1)
                    list.SelectedIndex = 0;

                setText();
                popup.IsOpen = false;
            }
            MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            //var next = new TraversalRequest(FocusNavigationDirection.Next);
            //var current = Keyboard.FocusedElement as UIElement;
            //if (current != null) {
            //    current.MoveFocus(next);
            //}
        }
    }
    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key == Key.Escape) {
            popup.IsOpen = false;
            return;
        }
        if (e.Key != Key.Down) return;

        if (popup.IsOpen) {
            if (list.SelectedIndex == -1) list.SelectedIndex = 0;
            Keyboard.Focus((ListBoxItem)list.ItemContainerGenerator.ContainerFromItem(list.SelectedItem));
        }
    }
    protected override void OnTextChanged(TextChangedEventArgs e) {
        if (!userMode) return;
        view.Refresh();
        Dispatcher.InvokeAsync(() => {
            if (view.IsEmpty) popup.IsOpen = false;
            else {
                popup.PlacementRectangle = GetRectFromCharacterIndex(CaretIndex);
                popup.IsOpen = true;
            }
        }, DispatcherPriority.Background);
    }
}

