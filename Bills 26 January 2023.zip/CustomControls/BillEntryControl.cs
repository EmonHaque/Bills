﻿class BillEntryControl : Grid
{
    TextBlock totalBill, totalPayment;
    ListBox breakup, breakupEdit;
    ActionButton edit, cancel, save, add, remove;
    StackPanel buttonStack, addRemoveButtonStack;
    List<Breakup> originalBreakups, editedBreakups;
    int billId;
    double editedBill, editedPayment;

    #region DependencyProperties
    public static readonly DependencyProperty IsOnEditProperty;
    public static readonly DependencyProperty SourceProperty;
    public static readonly DependencyProperty EditedSourceProperty;
    static BillEntryControl() {
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(BillEntryControl), new FrameworkPropertyMetadata() {
            DefaultValue = false,
            BindsTwoWayByDefault = true
        });
        SourceProperty =
        DependencyProperty.Register("Source", typeof(IEnumerable), typeof(BillEntryControl), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged
        });
        EditedSourceProperty =
        DependencyProperty.Register("EditedSource", typeof(IEnumerable), typeof(BillEntryControl), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onEditedSourceChanged
        });
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public IEnumerable Source {
        get { return (IEnumerable)GetValue(SourceProperty); }
        set { SetValue(SourceProperty, value); }
    }
    public IEnumerable EditedSource {
        get { return (IEnumerable)GetValue(EditedSourceProperty); }
        set { SetValue(EditedSourceProperty, value); }
    }
    static void onEditedSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (BillEntryControl)d;
        o.editedBreakups = (List<Breakup>)e.NewValue;
        o.breakupEdit.Items.Clear();
        o.editedBill = o.editedPayment = 0;
        foreach (var item in o.editedBreakups) {
            var ui = new BreakupEditControl(item);
            ui.SetTextChangedHandlers(o.onBillChanged, o.onPaymentChanged);
            o.breakupEdit.Items.Add(ui);
            o.editedBill += item.Bill;
            o.editedPayment += item.Payment;
        }
    }
    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (BillEntryControl)d;
        if (e.NewValue is null) {
            o.Visibility = Visibility.Hidden;
            return;
        }
        if (o.Visibility == Visibility.Hidden) o.Visibility = Visibility.Visible;

        o.originalBreakups = (List<Breakup>)e.NewValue;

        double billTotal = 0;
        double paymentTotal = 0;
        foreach (var item in o.originalBreakups) {
            billTotal += item.Bill;
            paymentTotal += item.Payment;
        }
        o.breakup.ItemsSource = o.originalBreakups;
        o.totalBill.Text = billTotal.ToString("N2");
        o.totalPayment.Text = paymentTotal.ToString("N2");
    }
    #endregion 

    public BillEntryControl() {
        Background = Brushes.Transparent;
        Margin = new Thickness(0, 10, 0, 0);
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        edit = new ActionButton() {
            Margin = new Thickness(0, 0, 10, 0),
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Margin = new Thickness(0, 0, 10, 5),
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { save, cancel }
        };
        add = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "add",
            Icon = Icons.Plus,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = addEntry
        };
        remove = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "remove",
            Icon = Icons.Minus,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = removeEntry
        };
        addRemoveButtonStack = new StackPanel() {
            Margin = new Thickness(2, 0, 0, 5),
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Left,
            Children = { add, remove }
        };
        Children.Add(edit);
        Children.Add(buttonStack);
        Children.Add(addRemoveButtonStack);

        initializeHeader();
        breakup = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = Helper.GetDataTemplate(typeof(BreakupTemplate)),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
        breakupEdit = new ListBox() {
            Visibility = Visibility.Collapsed,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Resources = {{
                        typeof(ListBoxItem),
                        new Style() {
                            Setters = {
                                new Setter(ListBoxItem.MarginProperty, new Thickness(0,0,Constants.ScrollBarThickness-2,0)),
                                new Setter(ListBoxItem.PaddingProperty, new Thickness(0)),
                                new Setter(ListBoxItem.BorderThicknessProperty, new Thickness(0)),
                                new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                                new EventSetter(ListBoxItem.PreviewGotKeyboardFocusEvent, new KeyboardFocusChangedEventHandler(selectItem))
                            }
                        }
                    }
                }
        };

        SetRow(breakup, 2);
        SetRow(breakupEdit, 2);
        Children.Add(breakup);
        Children.Add(breakupEdit);
        initializeFooter();
        Visibility = Visibility.Hidden;
    }

    void selectItem(object sender, KeyboardFocusChangedEventArgs e) => ((ListBoxItem)sender).IsSelected = true;
    void onBillChanged(object sender, TextChangedEventArgs e) {
        var text = ((TextBox)sender).Text;
        if (double.TryParse(text, out var amount)) {
            totalBill.Text = editedBreakups.Sum(x => x.Bill).ToString("N2");
        }
    }
    void onPaymentChanged(object sender, TextChangedEventArgs e) {
        var text = ((TextBox)sender).Text;
        if (double.TryParse(text, out var amount)) {
            totalPayment.Text = editedBreakups.Sum(x => x.Payment).ToString("N2");
        }
    }
    void initializeHeader() {
        TextBlock headBlock, billBlock, paymentBlock;
        headBlock = new TextBlock() { Text = "Head" };
        billBlock = new TextBlock() { Text = "Bill", HorizontalAlignment = HorizontalAlignment.Right };
        paymentBlock = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billBlock, 1);
        Grid.SetColumn(paymentBlock, 2);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { headBlock, billBlock, paymentBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        SetRow(header, 1);
        Children.Add(header);
    }
    void initializeFooter() {
        TextBlock totalBlock;
        totalBlock = new TextBlock() { Text = "Total" };
        totalBill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBill, 1);
        Grid.SetColumn(totalPayment, 2);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalBlock, totalBill, totalPayment }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        Grid.SetRow(footer, 3);
        Children.Add(footer);
    }
    void setEdit() {
        billId = originalBreakups.First().BillId;
        IsOnEdit = true;
        breakup.Visibility = Visibility.Collapsed;
        edit.Visibility = Visibility.Collapsed;
        breakupEdit.Visibility = Visibility.Visible;
        buttonStack.Visibility = Visibility.Visible;
        addRemoveButtonStack.Visibility = Visibility.Visible;
    }
    void addEntry() {
        var entry = new Breakup() { BillId = billId };
        var ui = new BreakupEditControl(entry);
        ui.SetTextChangedHandlers(onBillChanged, onPaymentChanged);
        breakupEdit.Items.Add(ui);
        editedBreakups.Add(entry);
    }
    void removeEntry() {
        if (breakupEdit.SelectedItem is null) return;
        var o = (BreakupEditControl)breakupEdit.SelectedItem;
        breakupEdit.Items.Remove(o);
        var item = o.GetItem();
        editedBreakups.Remove(item);

        editedBill -= item.Bill;
        editedPayment -= item.Payment;

        totalBill.Text = editedBill.ToString("N2");
        totalPayment.Text = editedPayment.ToString("N2");
    }
    void cancelEdit() {
        editedBill = 0;
        editedPayment = 0;
        editedBreakups.Clear();
        foreach (var item in originalBreakups) {
            editedBill += item.Bill;
            editedPayment += item.Payment;
            editedBreakups.Add(item);
        }
        totalBill.Text = editedBill.ToString("N2");
        totalPayment.Text = editedPayment.ToString("N2");
        resetVisibility();
    }
    void saveEdit() {
        List<ValidationError> errors = new();
        double totalBill = 0;
        double totalPayment = 0;
        foreach (var item in editedBreakups) {
            totalBill += item.Bill;
            totalPayment += item.Payment;
            if (item.Bill < 0) {
                errors.Add(new ValidationError() {
                    Head = "Bill " + item.Head,
                    Error = "cannot be negative"
                });
            }
            if (item.Payment < 0) {
                errors.Add(new ValidationError() {
                    Head = "Payment " + item.Head,
                    Error = "cannot be negative"
                });
            }
            if (string.IsNullOrWhiteSpace(item.Head)) {
                errors.Add(new ValidationError() {
                    Head = "Head",
                    Error = "cannot be empty"
                });
            }
        }
        if (totalPayment < totalBill) {
            errors.Add(new ValidationError() {
                Head = "Excess",
                Error = "payment should be greater or equal to bill"
            });
        }
        if (editedBreakups.Count == 0) {
            errors.Add(new ValidationError() {
                Head = "Item",
                Error = "no item to save"
            });
        }
        if (errors.Count > 0) {
            var errorDialog = new BillErrorDialog(AccountSearchBase.Left, AccountSearchBase.Top, AccountSearchBase.Width, AccountSearchBase.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        resetVisibility();
    }
    void resetVisibility() {
        IsOnEdit = false;
        breakup.Visibility = Visibility.Visible;
        edit.Visibility = Visibility.Visible;
        breakupEdit.Visibility = Visibility.Collapsed;
        buttonStack.Visibility = Visibility.Collapsed;
        addRemoveButtonStack.Visibility = Visibility.Collapsed;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }
    protected override void OnPreviewKeyUp(KeyEventArgs e) {
        base.OnPreviewKeyUp(e);
        if (!IsOnEdit) return;
        if (!breakupEdit.IsKeyboardFocusWithin) return;
        var index = breakupEdit.SelectedIndex;
        if (e.Key == Key.Up && index > 0) {
            var grid = (Grid)breakupEdit.Items[index];
            int focusIndex = -1;
            for (int i = 0; i < grid.Children.Count; i++) {
                if (grid.Children[i].IsFocused) {
                    focusIndex = i;
                    break;
                }
            }
            if (focusIndex == -1) focusIndex = 0;
            breakupEdit.SelectedIndex--;
            grid = (Grid)breakupEdit.Items[breakupEdit.SelectedIndex];
            grid.Children[focusIndex].Focus();
        }
        else if (e.Key == Key.Down && index < (breakupEdit.Items.Count - 1)) {
            var grid = (Grid)breakupEdit.Items[index];
            int focusIndex = -1;
            for (int i = 0; i < grid.Children.Count; i++) {
                if (grid.Children[i].IsFocused) {
                    focusIndex = i;
                    break;
                }
            }
            if (focusIndex == -1) focusIndex = 0;
            breakupEdit.SelectedIndex++;
            grid = (Grid)breakupEdit.Items[breakupEdit.SelectedIndex];
            grid.Children[focusIndex].Focus();
        }
    }
}
