﻿class BreakupEditControl : Grid
{
    HeadBox head;
    TextBox bill, payment;
    TextChangedEventHandler billHandler, paymentHandler;
    Breakup item;

    public BreakupEditControl(Breakup item) {
        this.item = item;
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth)});
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) });
        head = new HeadBox();
        bill = new TextBox() { TextAlignment = TextAlignment.Right };
        payment = new TextBox() { TextAlignment = TextAlignment.Right };
        SetColumn(bill, 1);
        SetColumn(payment, 2);
        Children.Add(head);
        Children.Add(bill);
        Children.Add(payment);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
        DataContext = item;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        bill.TextChanged -= billHandler;
        payment.TextChanged -= paymentHandler;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        head.SetBinding(HeadBox.TextProperty, new Binding(nameof(item.Head)) {
            StringFormat = "N2",
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        bill.SetBinding(TextBox.TextProperty, new Binding(nameof(item.Bill)) {
            StringFormat = "N2",
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        payment.SetBinding(TextBox.TextProperty, new Binding(nameof(item.Payment)) {
            StringFormat = "N2",
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        bill.TextChanged += billHandler;
        payment.TextChanged += paymentHandler;
    }
    public void SetTextChangedHandlers(TextChangedEventHandler billHandler, TextChangedEventHandler paymentHandler) {
        this.billHandler = billHandler;
        this.paymentHandler = paymentHandler;   
    }
    public Breakup GetItem() => item;
}