﻿class DetailSummaryEntryTemplate : DataTemplate
{
    public DetailSummaryEntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var account = new FrameworkElementFactory(typeof(TextBlock));
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));
        
        var tipName = new Run();
        var tipAddress = new Run();
        var tip = new TextBlock() { Inlines = {tipName, new Run("\n"), tipAddress }};

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        bill.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        account.SetValue(TextBlock.ToolTipProperty, tip);
        bill.SetValue(Grid.ColumnProperty, 1);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(Grid.ColumnProperty, 2);

        account.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.AccountNo)));
        tipName.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountName)));
        tipAddress.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountAddress)));
        bill.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.Bill)) { StringFormat = Constants.NumberFormat });
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.Payment)) { StringFormat = Constants.NumberFormat});

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(account);
        grid.AppendChild(bill);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}
