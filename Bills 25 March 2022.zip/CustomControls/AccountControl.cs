﻿class AccountControl : StackPanel
{
    TextBlock name, address;
    TextBox editedName, editedAddress, editedAccountNo;
    ActionButton edit, cancel, save;
    StackPanel buttonStack;
    string originalAccountNo;

    #region DependencyProperties
    public new static readonly DependencyProperty NameProperty;
    public static readonly DependencyProperty AddressProperty;
    public static readonly DependencyProperty IsOnEditProperty;
    public static readonly DependencyProperty EditedNameProperty;
    public static readonly DependencyProperty EditedAddressProperty;
    public static readonly DependencyProperty EditedAccountNoProperty;

    static AccountControl() {
        NameProperty = DependencyProperty.Register("Name", typeof(string), typeof(AccountControl));
        AddressProperty = DependencyProperty.Register("Address", typeof(string), typeof(AccountControl));
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(AccountControl), new FrameworkPropertyMetadata() {
            DefaultValue = false,
            BindsTwoWayByDefault = true
        });
        EditedNameProperty = DependencyProperty.Register("EditedName", typeof(string), typeof(AccountControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedAddressProperty = DependencyProperty.Register("EditedAddress", typeof(string), typeof(AccountControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedAccountNoProperty = DependencyProperty.Register("EditedAccountNo", typeof(string), typeof(AccountControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
    }

    public new string Name {
        get { return (string)GetValue(NameProperty); }
        set { SetValue(NameProperty, value); }
    }
    public string Address {
        get { return (string)GetValue(AddressProperty); }
        set { SetValue(AddressProperty, value); }
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public string EditedName {
        get { return (string)GetValue(EditedNameProperty); }
        set { SetValue(EditedNameProperty, value); }
    }
    public string EditedAddress {
        get { return (string)GetValue(EditedAddressProperty); }
        set { SetValue(EditedAddressProperty, value); }
    }
    public string EditedAccountNo {
        get { return (string)GetValue(EditedAccountNoProperty); }
        set { SetValue(EditedAccountNoProperty, value); }
    }
    #endregion
    public AccountControl() {
        Margin = new Thickness(0, 0, 10, 0);
        Background = Brushes.Transparent;
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { save, cancel }
        };
        name = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        address = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        editedName = new TextBox();
        editedAddress = new TextBox();
        editedAccountNo = new TextBox();
        Resources.Add(
            typeof(TextBox),
            new Style(typeof(TextBox)) {
                Setters = {
                    new Setter(TextBox.MarginProperty, new Thickness(0, 0, 0, 5)),
                    new Setter(TextBox.BorderThicknessProperty, new Thickness(0, 0, 0, 1)),
                    new Setter(TextBox.BorderBrushProperty, Brushes.LightGray),
                    new Setter(TextBox.ForegroundProperty, Brushes.LightGray),
                    new Setter(TextBox.TextAlignmentProperty, TextAlignment.Center),
                    new Setter(TextBox.VisibilityProperty, Visibility.Collapsed)
                }
            }
        );
        Children.Add(edit);
        Children.Add(buttonStack);
        Children.Add(name);
        Children.Add(address);
        Children.Add(editedName);
        Children.Add(editedAddress);
        Children.Add(editedAccountNo);

        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(Name)) { Source = this });
        address.SetBinding(TextBlock.TextProperty, new Binding(nameof(Address)) { Source = this });
        editedName.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedName)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
        editedAddress.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedAddress)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
        editedAccountNo.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedAccountNo)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
    }
    void setEdit() {
        IsOnEdit = true;
        name.Visibility = Visibility.Collapsed;
        address.Visibility = Visibility.Collapsed;
        edit.Visibility = Visibility.Collapsed;
        editedName.Visibility = Visibility.Visible;
        editedAddress.Visibility = Visibility.Visible;
        editedAccountNo.Visibility = Visibility.Visible;
        buttonStack.Visibility = Visibility.Visible;
        originalAccountNo = EditedAccountNo;
    }
    void cancelEdit() {
        if (!EditedAccountNo.Equals(originalAccountNo)) EditedAccountNo = originalAccountNo;
        if (!EditedName.Equals(Name)) EditedName = Name;
        if (!EditedAddress.Equals(Address)) EditedAddress = Address;
        resetVisibility();
    }
    void saveEdit() {
        List<ValidationError> errors = new();
        if (string.IsNullOrWhiteSpace(EditedName)) {
            errors.Add(new ValidationError() {
                Head = "Name",
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(EditedAddress)) {
            errors.Add(new ValidationError() {
                Head = "Address",
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(EditedAccountNo)) {
            errors.Add(new ValidationError() {
                Head = "Account No",
                Error = "cannot be empty"
            });
        }
        if (errors.Count > 0) {
            var errorDialog = new BillErrorDialog(SearchBase.Left, SearchBase.Top, SearchBase.Width, SearchBase.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        resetVisibility();
    }
    void resetVisibility() {
        IsOnEdit = false;
        editedName.Visibility = Visibility.Collapsed;
        editedAddress.Visibility = Visibility.Collapsed;
        editedAccountNo.Visibility = Visibility.Collapsed;
        buttonStack.Visibility = Visibility.Collapsed;
        name.Visibility = Visibility.Visible;
        address.Visibility = Visibility.Visible;
        edit.Visibility = Visibility.Hidden;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }
}