﻿class BillEntryControl : Grid
{
    TextBlock totalBill, totalPayment;
    ListBoxEx breakup, breakupEdit;
    ActionButton edit, cancel, save;
    StackPanel buttonStack;
    #region DependencyProperties
    public static readonly DependencyProperty IsOnEditProperty;
    public static readonly DependencyProperty SourceProperty;
    public static readonly DependencyProperty EditedSourceProperty;
    static BillEntryControl() {
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(BillEntryControl), new FrameworkPropertyMetadata() {
            DefaultValue = false,
            BindsTwoWayByDefault = true
        });
        SourceProperty =
        DependencyProperty.Register("Source", typeof(IEnumerable), typeof(BillEntryControl), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged
        });
        EditedSourceProperty =
        DependencyProperty.Register("EditedSource", typeof(IEnumerable), typeof(BillEntryControl), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onEditedSourceChanged
        });
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public IEnumerable Source {
        get { return (IEnumerable)GetValue(SourceProperty); }
        set { SetValue(SourceProperty, value); }
    }
    public IEnumerable EditedSource {
        get { return (IEnumerable)GetValue(EditedSourceProperty); }
        set { SetValue(EditedSourceProperty, value); }
    }
    static void onEditedSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (BillEntryControl)d;
        var collection = (List<Breakup>)e.NewValue;
        if(e.OldValue != null) {
            foreach (Grid item in o.breakupEdit.Items) {
                foreach (var child in item.Children) {
                    if (item.Tag is null) continue;
                    if (item.Tag.Equals("bill")) {
                        ((TextBox)child).TextChanged -= o.onBillChanged;
                    }
                    else if (item.Tag.Equals("payment")) {
                        ((TextBox)child).TextChanged -= o.onPaymentChanged;
                    }
                }
            }
            o.breakupEdit.Items.Clear();
        }
        foreach (var item in collection) {
            var head = new TextBlock() { Text = item.Head };
            var billBox = new TextBox() {
                Tag = "bill",
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0),
                TextAlignment = TextAlignment.Right
            };
            var paymentBox = new TextBox() {
                Tag = "payment",
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0),
                TextAlignment = TextAlignment.Right
            };
            if (item.Bill > 0) {
                billBox.SetBinding(TextBox.TextProperty, new Binding(nameof(Breakup.Bill)) { 
                    StringFormat = "N2",
                    Source = item, 
                    UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged 
                });
            }
            else {
                billBox.Text = "   - ";
                billBox.IsEnabled = false;
            }
            if (item.Payment > 0) {
                paymentBox.SetBinding(TextBox.TextProperty, new Binding(nameof(Breakup.Payment)) {
                    StringFormat = "N2",
                    Source = item, 
                    UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged 
                });
            }
            else {
                paymentBox.Text = "   - ";
                paymentBox.IsReadOnly = true;
            }
            billBox.TextChanged += o.onBillChanged;
            paymentBox.TextChanged += o.onPaymentChanged;
            Grid.SetColumn(billBox, 1);
            Grid.SetColumn(paymentBox, 2);
            var grid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                    new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
                },
                Children = { head, billBox, paymentBox }
            };
            o.breakupEdit.Items.Add(grid);
        }
    }
    void onBillChanged(object sender, TextChangedEventArgs e) {
        var text = ((TextBox)sender).Text;
        if (double.TryParse(text, out var amount)) {
            totalBill.Text = EditedSource.Cast<Breakup>().Sum(x => x.Bill).ToString("N2");
        }
    }
    void onPaymentChanged(object sender, TextChangedEventArgs e) {
        var text = ((TextBox)sender).Text;
        if (double.TryParse(text, out var amount)) {
            totalPayment.Text = EditedSource.Cast<Breakup>().Sum(x => x.Payment).ToString("N2");
        }
    }
    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (BillEntryControl)d;
        var collection = (List<Breakup>)e.NewValue;
        double billTotal = 0;
        double paymentTotal = 0;
        foreach (var item in collection) {
            billTotal += item.Bill;
            paymentTotal += item.Payment;
        }
        o.breakup.ItemsSource = collection;
        o.totalBill.Text = billTotal.ToString("N2");
        o.totalPayment.Text = paymentTotal.ToString("N2");
    }
    #endregion 
    public BillEntryControl() {
        Background = Brushes.Transparent;
        Margin = new Thickness(0, 10, 0, 0);
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        
        edit = new ActionButton() {
            Margin = new Thickness(0,0,10,0),
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Margin = new Thickness(0, 0, 10, 0),
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { save, cancel }
        };
        Children.Add(edit);
        Children.Add(buttonStack);

        
        initializeHeader();
        breakup = new ListBoxEx() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = Helper.GetDataTemplate(typeof(BreakupTemplate)),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
        breakupEdit = new ListBoxEx() {
            Visibility = Visibility.Collapsed,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Resources = {{
                        typeof(ListBoxItem),
                        new Style() {
                            Setters = {
                                new Setter(ListBoxItem.MarginProperty, new Thickness(0,0,Constants.ScrollBarThickness-2,0)),
                                new Setter(ListBoxItem.PaddingProperty, new Thickness(0)),
                                new Setter(ListBoxItem.BorderThicknessProperty, new Thickness(0)),
                                new EventSetter(ListBoxItem.PreviewGotKeyboardFocusEvent, new KeyboardFocusChangedEventHandler(selectItem))
                            }
                        }
                    }
                }
        };
        SetRow(breakup, 2);
        SetRow(breakupEdit, 2);
        Children.Add(breakup);
        Children.Add(breakupEdit);
        initializeFooter();
        
    }
    void selectItem(object sender, KeyboardFocusChangedEventArgs e) => ((ListBoxItem)sender).IsSelected = true;
    void initializeHeader() {
        TextBlock headBlock, billBlock, paymentBlock;
        headBlock = new TextBlock() { Text = "Head" };
        billBlock = new TextBlock() { Text = "Bill", HorizontalAlignment = HorizontalAlignment.Right };
        paymentBlock = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billBlock, 1);
        Grid.SetColumn(paymentBlock, 2);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { headBlock, billBlock, paymentBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        SetRow(header, 1);
        Children.Add(header);
    }
    void initializeFooter() {
        TextBlock totalBlock;
        totalBlock = new TextBlock() { Text = "Total" };
        totalBill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBill, 1);
        Grid.SetColumn(totalPayment, 2);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalBlock, totalBill, totalPayment }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        Grid.SetRow(footer, 3);
        Children.Add(footer);
    }
    void setEdit() {
        IsOnEdit = true;
        breakup.Visibility = Visibility.Collapsed;
        edit.Visibility = Visibility.Collapsed;
        breakupEdit.Visibility = Visibility.Visible;
        buttonStack.Visibility = Visibility.Visible;
    }
    void cancelEdit() {
        var original = (List<Breakup>)Source;
        var edited = (List<Breakup>)EditedSource;
        double billTotal = 0;
        double paymentTotal = 0;
        for (int i = 0; i < original.Count; i++) {
            billTotal += original[i].Bill;
            paymentTotal += original[i].Payment;
            if (edited[i].Bill != original[i].Bill) {
                edited[i].Bill = original[i].Bill;
            }
            if (edited[i].Payment != original[i].Payment) {
                edited[i].Payment = original[i].Payment;
            }
        }
        totalBill.Text = billTotal.ToString("N2");
        totalPayment.Text = paymentTotal.ToString("N2");
        resetVisibility();
    }
    void saveEdit() {
        List<ValidationError> errors = new();
        var edited = (List<Breakup>)EditedSource;
        double totalBill = 0; 
        double totalPayment = 0;
        foreach (var item in edited) {
            totalBill += item.Bill;
            totalPayment += item.Payment;
            if(item.Bill < 0) {
                errors.Add(new ValidationError() {
                    Head = "Bill " + item.Head,
                    Error = "cannot be negative"
                });
            }
            if (item.Payment < 0) {
                errors.Add(new ValidationError() {
                    Head = "Payment " + item.Head,
                    Error = "cannot be negative"
                });
            }
        }
        if(totalPayment < totalBill) {
            errors.Add(new ValidationError() {
                Head = "Excess",
                Error = "payment should be less or equal to bill"
            });
        }
        if(errors.Count > 0) {
            var errorDialog = new BillErrorDialog(SearchBase.Left, SearchBase.Top, SearchBase.Width, SearchBase.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        resetVisibility();
    }
    void resetVisibility() {
        IsOnEdit = false;
        breakup.Visibility = Visibility.Visible;
        edit.Visibility = Visibility.Visible;
        breakupEdit.Visibility = Visibility.Collapsed;
        buttonStack.Visibility = Visibility.Collapsed;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }
    protected override void OnPreviewKeyUp(KeyEventArgs e) {
        base.OnPreviewKeyUp(e);
        if (!IsOnEdit) return;
        if (!breakupEdit.IsKeyboardFocusWithin) return;
        var index = breakupEdit.SelectedIndex;
        if (e.Key == Key.Up && index > 0) {
            var grid = (Grid)breakupEdit.Items[index];
            int focusIndex = -1;
            for (int i = 0; i < grid.Children.Count; i++) {
                if (grid.Children[i].IsFocused) {
                    focusIndex = i;
                    break;
                }
            }
            if (focusIndex == -1) focusIndex = 0;
            breakupEdit.SelectedIndex--;
            grid = (Grid)breakupEdit.Items[breakupEdit.SelectedIndex];
            grid.Children[focusIndex].Focus();
        }
        else if (e.Key == Key.Down && index < (breakupEdit.Items.Count - 1)) {
            var grid = (Grid)breakupEdit.Items[index];
            int focusIndex = -1;
            for (int i = 0; i < grid.Children.Count; i++) {
                if (grid.Children[i].IsFocused) {
                    focusIndex = i;
                    break;
                }
            }
            if (focusIndex == -1) focusIndex = 0;
            breakupEdit.SelectedIndex++;
            grid = (Grid)breakupEdit.Items[breakupEdit.SelectedIndex];
            grid.Children[focusIndex].Focus();
        }
    }
}