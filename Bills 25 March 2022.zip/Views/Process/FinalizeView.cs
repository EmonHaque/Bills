﻿class FinalizeView : CardView
{
    public override string Header => "Finalize";
    EditText department, transaction, paidFrom, billNo, customerNo, paymentDate, period;
    ListBoxEx paymentList, billList;
    TextBlock paymentInfo, billInfo, paymentTotal, billTotal, paymentTotalAmount, billTotalAmount;
    ActionButton allRight, addBillRow, addPaymentRow, removeBillRow, removePaymentRow;
    Grid grid, paymentGrid, billGrid;
    FinalizeVM vm;
    ResourceDictionary listBoxResource;
    public FinalizeView() {
        vm = new FinalizeVM();
        DataContext = vm;
        populateResourceDictionary();
        initialize();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void populateResourceDictionary() {
        listBoxResource = new ResourceDictionary() {
            {
                typeof(ListBoxItem),
                new Style(typeof(ListBoxItem)) {
                    Setters = {
                        new Setter(ListBoxItem.BorderThicknessProperty, new Thickness(0)),
                        new Setter(ListBoxItem.PaddingProperty, new Thickness(0)),
                        new EventSetter(ListBoxItem.PreviewGotKeyboardFocusEvent, new KeyboardFocusChangedEventHandler(selectItem))
                    },
                    //Triggers = {
                    //    new Trigger(){
                    //        Property = ListBoxItem.IsKeyboardFocusWithinProperty,
                    //        Value = true,
                    //        Setters = {
                    //            new Setter(ListBoxItem.IsSelectedProperty, true)
                    //        }
                    //    }
                    //}
                }
            }
        };
    }
    void initialize() {
        allRight = new ActionButton() {
            Icon = Icons.Checked,
            Width = 14,
            Height = 14,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Mark all right",
            Command = vm.SetOk
        };
        addActions(allRight);

        department = new EditText() { Hint = "Department", IsRequired = false };
        transaction = new EditText() { Hint = "Transaction No", IsRequired = false };
        paidFrom = new EditText() { Hint = "Paid from", IsRequired = false };
        paymentDate = new EditText() { Hint = "Paid on", IsRequired = false };
        billNo = new EditText() { Hint = "Bill No", IsRequired = false };
        customerNo = new EditText() { Hint = "Customer No", IsRequired = false };
        period = new EditText() { Hint = "Period", IsRequired = false };
        initializePaymentGrid();
        initializeBillGrid();

        Grid.SetColumn(transaction, 2);
        Grid.SetRow(paidFrom, 1);
        Grid.SetRow(paymentDate, 1);
        Grid.SetColumn(paymentDate, 2);
        Grid.SetRow(customerNo, 2);
        Grid.SetRow(billNo, 2);
        Grid.SetColumn(billNo, 2);
        Grid.SetRow(period, 3);
        Grid.SetColumnSpan(period, 3);
        Grid.SetRow(paymentGrid, 4);
        Grid.SetRow(billGrid, 4);
        Grid.SetColumn(billGrid, 2);

        grid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(10)},
                new ColumnDefinition(),
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto }
            },
            Children = { department, transaction, paidFrom, paymentDate, customerNo, billNo, period, paymentGrid, billGrid }
        };
        var scroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = grid
        };
        setContent(scroll);
    }
    void initializePaymentGrid() {
        addPaymentRow = new ActionButton() {
            Margin = new Thickness(5, 0, 0, 0),
            Width = 10,
            Height = 10,
            Icon = Icons.Plus,
            ToolTip = "add row",
            Command = appendPaymentRow
        };
        removePaymentRow = new ActionButton() {
            Icon = Icons.Minus,
            Width = 10,
            Height = 10,
            ToolTip = "remove selected row",
            Command = vm.RemovePaymentRow
        };
        var paymentButtons = new StackPanel() {
            Margin = new Thickness(0, 0, 5, 0),
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { removePaymentRow, addPaymentRow }
        };
        paymentInfo = new TextBlock() { Text = "Payment", FontWeight = FontWeights.Bold };
        paymentList = new ListBoxEx() {
            FocusVisualStyle = null,
            BorderThickness = new Thickness(0, 1, 0, 1),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new AmountTemplate(vm, InfoType.Payment),
            Resources = listBoxResource
        };
        paymentTotal = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
        paymentTotalAmount = new TextBlock() { Margin = new Thickness(0, 0, 3, 0), HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(paymentButtons, 1);
        Grid.SetRow(paymentList, 1);
        Grid.SetColumnSpan(paymentList, 2);
        Grid.SetRow(paymentTotal, 2);
        Grid.SetRow(paymentTotalAmount, 2);
        Grid.SetColumn(paymentTotalAmount, 1);

        paymentGrid = new Grid() {
            Margin = new Thickness(5, 0, 8, 0),
            RowDefinitions = {
                new RowDefinition() {Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto }
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { paymentInfo, paymentButtons, paymentList, paymentTotal, paymentTotalAmount }
        };
    }
    void initializeBillGrid() {
        addBillRow = new ActionButton() {
            Margin = new Thickness(5, 0, 0, 0),
            Width = 10,
            Height = 10,
            Icon = Icons.Plus,
            ToolTip = "add row",
            Command = appendBillRow
        };
        removeBillRow = new ActionButton() {
            Icon = Icons.Minus,
            Width = 10,
            Height = 10,
            ToolTip = "remove selected row",
            Command = vm.RemoveBillRow
        };
        var billButtons = new StackPanel() {
            Margin = new Thickness(0, 0, 5, 0),
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { removeBillRow, addBillRow }
        };
        billInfo = new TextBlock() { Text = "Bill", FontWeight = FontWeights.Bold };
        billList = new ListBoxEx() {
            FocusVisualStyle = null,
            BorderThickness = new Thickness(0, 1, 0, 1),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new AmountTemplate(vm, InfoType.Bill),
            Resources = listBoxResource
        };
        billTotal = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
        billTotalAmount = new TextBlock() { Margin = new Thickness(0, 0, 3, 0), HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billButtons, 1);
        Grid.SetRow(billList, 1);
        Grid.SetColumnSpan(billList, 2);
        Grid.SetRow(billTotal, 2);
        Grid.SetRow(billTotalAmount, 2);
        Grid.SetColumn(billTotalAmount, 1);
        billGrid = new Grid() {
            Margin = new Thickness(5, 0, 8, 0),
            RowDefinitions = {
                new RowDefinition() {Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto }
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { billInfo, billButtons, billList, billTotal, billTotalAmount }
        };
    }
    void bind() {
        department.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.Department)}"));
        transaction.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.TransactionNo)}"));
        paidFrom.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.PaidFrom)}"));
        billNo.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.BillNo)}"));
        customerNo.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.CustomerNo)}"));
        paymentDate.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.PaymentDate)}"));
        period.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.Period)}"));
        paymentList.SetBinding(ListBox.ItemsSourceProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.PaymentInfo)}"));
        paymentList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedPayment)));
        billList.SetBinding(ListBox.ItemsSourceProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.BillInfo)}"));
        billList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedBill)));
        paymentTotalAmount.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.TotalPayment)}") { StringFormat = "N2" });
        billTotalAmount.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(vm.Info)}.{nameof(RawInfo.TotalBill)}") { StringFormat = "N2" });

        removeBillRow.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(ListBox.HasItems)) { Source = billList });
        removePaymentRow.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(ListBox.HasItems)) { Source = paymentList });

        var converter = new BooleanToVisibilityConverter();
        grid.SetBinding(Grid.VisibilityProperty, new Binding(nameof(vm.CanShowInfo)) { Converter = converter });
        allRight.SetBinding(ActionButton.VisibilityProperty, new Binding(nameof(vm.CanShowInfo)) { Converter = converter });
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        PreviewMouseWheel += onWheel;
        billList.PreviewKeyUp += onKeyup;
        paymentList.PreviewKeyUp += onKeyup;
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        PreviewMouseWheel -= onWheel;
        billList.PreviewKeyUp -= onKeyup;
        paymentList.PreviewKeyUp -= onKeyup;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void onWheel(object sender, MouseWheelEventArgs e) {
        if (!Keyboard.IsKeyDown(Key.LeftCtrl)) return;
        var size = (double)GetValue(TextElement.FontSizeProperty);
        if (e.Delta > 0) SetValue(TextElement.FontSizeProperty, ++size);
        else if (size > 12) SetValue(TextElement.FontSizeProperty, --size);
    }
    void onKeyup(object sender, KeyEventArgs e) {
        var box = (ListBox)sender;
        if (Keyboard.IsKeyDown(Key.LeftCtrl)) {
            if (e.Key == Key.OemPlus || e.Key == Key.Add) {
                if (box.Equals(billList)) appendBillRow();
                else if (box.Equals(paymentList)) appendPaymentRow();
            }
            else if (e.Key == Key.OemMinus || e.Key == Key.Subtract) {
                if (box.SelectedIndex == -1) return;
                if (box.Equals(billList)) vm.RemoveBillRow();
                else if (box.Equals(paymentList)) vm.RemovePaymentRow();
            }
        }
        else if (e.Key == Key.Up) {
            if (box.SelectedIndex > 0) {
                var item = (ListBoxItem)box.ItemContainerGenerator.ContainerFromIndex(box.SelectedIndex - 1);
                moveFocusToTextBox(item);
            }
        }
        else if (e.Key == Key.Down) {
            if (box.SelectedIndex < (box.Items.Count - 1)) {
                var item = (ListBoxItem)box.ItemContainerGenerator.ContainerFromIndex(box.SelectedIndex + 1);
                moveFocusToTextBox(item);
            }
        }
    }
    void selectItem(object sender, KeyboardFocusChangedEventArgs e) => ((ListBoxItem)sender).IsSelected = true;
    void appendPaymentRow() {
        var info = new AmountInfo();
        vm.Info.PaymentInfo.Add(info);
        paymentList.SelectedItem = info;
        Dispatcher.InvokeAsync(() => {
            var item = (ListBoxItem)paymentList.ItemContainerGenerator.ContainerFromItem(info);
            moveFocusToTextBox(item);
        }, DispatcherPriority.Background);      
    }
    void appendBillRow() {
        var info = new AmountInfo();
        vm.Info.BillInfo.Add(info);
        billList.SelectedItem = info;
        Dispatcher.InvokeAsync(() => {
            var item = (ListBoxItem)billList.ItemContainerGenerator.ContainerFromItem(info);
            moveFocusToTextBox(item);
        }, DispatcherPriority.Background);
    }   
    void moveFocusToTextBox(ListBoxItem item) {
        var presenter = Helper.FindVisualChild<ContentPresenter>(item);
        var firstBox = (TextBox)item.ContentTemplate.FindName("box", presenter);
        firstBox.CaretIndex = firstBox.Text.Length;
        firstBox.Focus();
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition(PointToScreen(new Point(0, 0)));
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition(PointToScreen(new Point(0, 0)));
    }
    void updatePosition(Point position) {
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin.Left;
        position.Y += Constants.CardMargin.Top;
        var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
        var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;
        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = width;
        vm.Height = height;
    }
}