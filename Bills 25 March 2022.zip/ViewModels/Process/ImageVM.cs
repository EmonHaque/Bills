﻿class ImageVM : Notifiable
{
    ColorState state;
    public RawInfo Info { get; set; }
    public BitmapImage Bitmap { get; set; }
    public bool IsActionsVisible { get; set; }
    public ImageVM() {       
        LoadVM.SelectionChanged += onSelectionChanged;
    }
    void onSelectionChanged(RawInfo info) {       
        Info = info;
        if (Info is null) {
            Bitmap = null;
            IsActionsVisible = false;
            OnPropertyChanged(nameof(Bitmap));
            OnPropertyChanged(nameof(IsActionsVisible));
            return;
        }
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
        IsActionsVisible = true;
        OnPropertyChanged(nameof(IsActionsVisible));
    }
    public void MakeBlackWhite() {     
        state = ColorState.BlackWhite;
        Bitmap = ImageProcessor.GetBlackAndWhite(Info.FilePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeGray() {
        state = ColorState.Gray;
        Bitmap = ImageProcessor.GetGrayScale(Info.FilePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeNormal() {
        state = ColorState.Color;
        Bitmap = ImageProcessor.GetNormal(Info.FilePath);
        OnPropertyChanged(nameof(Bitmap));
    }
}

