﻿class HeadBox : TextBox
{
    bool userMode;
    Popup popup;
    ListBox list;
    ICollectionView source;

    public HeadBox() {
        BorderThickness = new Thickness(0);
        Padding = new Thickness(2, 0, 0, 0);
        source = CollectionViewSource.GetDefaultView(AppData.heads);
        source.Filter = filter;
        list = new ListBox() {
            Padding = new Thickness(5),
            BorderThickness = new Thickness(1),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemsSource = source,
            DisplayMemberPath = nameof(Head.Name)
        };
        popup = new Popup() {
            AllowsTransparency = true,
            HorizontalOffset = 2,
            MaxHeight = 300,
            StaysOpen = false,
            PlacementTarget = this,
            Child = list
        };
        Loaded += subscribe;
        Unloaded += unSubscribe;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Text)) return true;
        return ((Head)o).Name.ToLower().Contains(Text.ToLower());
    }

    void subscribe(object sender, RoutedEventArgs e) {
        list.KeyUp += setTextOnEnter;
        list.MouseLeftButtonUp += setTextOnClick;
        userMode = true;
    }

    void unSubscribe(object sender, RoutedEventArgs e) {
        list.KeyUp -= setTextOnEnter;
        list.MouseLeftButtonUp -= setTextOnClick;
    }

    void setTextOnClick(object sender, MouseButtonEventArgs e) {
        setText();
        CaretIndex = Text.Length;
        popup.IsOpen = false;
        Keyboard.Focus(this);
    }

    void setTextOnEnter(object sender, KeyEventArgs e) {
        if (e.Key != Key.Escape) popup.IsOpen = false;
        if (e.Key != Key.Enter) return;
        setText();
        CaretIndex = Text.Length;
        popup.IsOpen = false;
        Keyboard.Focus(this);
    }
    void setText() => Text = ((Head)list.SelectedItem).Name;

    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key == Key.Escape) popup.IsOpen = false;
        if (e.Key != Key.Down) return;
        if (popup.IsOpen) {
            list.SelectedIndex = 0;
            Keyboard.Focus((ListBoxItem)list.ItemContainerGenerator.ContainerFromItem(list.SelectedItem));
        }
    }
    protected override void OnTextChanged(TextChangedEventArgs e) {
        if (!userMode) return;
        source.Refresh();
        popup.PlacementRectangle = GetRectFromCharacterIndex(CaretIndex);
        popup.IsOpen = true;
    }
}

