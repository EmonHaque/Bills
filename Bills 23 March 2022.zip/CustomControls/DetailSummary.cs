﻿class DetailSummary : Grid
{
    public DetailSummary() {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        initializeHeader();
        var list = new ListBoxEx() {
            BorderThickness = new Thickness(1, 0, 0, 0),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new DetailSummaryEntryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = { new Setter(GroupItem.TemplateProperty, new DetailSummaryGroupTemplate())}
                    }
                }
            },
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                                new Setter(ScrollViewer.IsDeferredScrollingEnabledProperty, false)
                            }
                        }
                    }
                }
        };
        SetRow(list, 1);
        Children.Add(list);
        list.SetBinding(ListBoxEx.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
    }
    void initializeHeader() {
        TextBlock dateBlock, billBlock, paymentBlock;
        dateBlock = new TextBlock() { Text = "Particulars" };
        billBlock = new TextBlock() { Text = "Bill", HorizontalAlignment = HorizontalAlignment.Right };
        paymentBlock = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billBlock, 1);
        Grid.SetColumn(paymentBlock, 2);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { dateBlock, billBlock, paymentBlock }
        };
        var header = new Border() {
            Margin = new Thickness(10, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        Children.Add(header);
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(DetailSummary), new PropertyMetadata(null));
}
