﻿class DatewiseSummary : Grid
{
    TextBlock totalBill, totalPayment;
    ListBoxEx box;
    public DatewiseSummary() {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        initializeHeader();
        box = new ListBoxEx() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = Helper.GetDataTemplate(typeof(DateEntryTemplate)),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
        SetRow(box, 1);
        Children.Add(box);
        initializeFooter();
        box.SetBinding(ListBoxEx.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this});
        box.SetBinding(ListBoxEx.SelectedItemProperty, new Binding(nameof(SelectedItem)) { Source = this });
    }
    void initializeHeader() {
        TextBlock dateBlock,  billBlock, paymentBlock;
        dateBlock = new TextBlock() { Text = "Date" };
        billBlock = new TextBlock() { Text = "Bill", HorizontalAlignment = HorizontalAlignment.Right };
        paymentBlock = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(billBlock, 1);
        Grid.SetColumn(paymentBlock, 2);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { dateBlock, billBlock, paymentBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        Children.Add(header);
    }
    void initializeFooter() {
        TextBlock totalBlock;
        totalBlock = new TextBlock() { Text = "Total" };
        totalBill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBill, 1);
        Grid.SetColumn(totalPayment, 2);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalBlock, totalBill, totalPayment }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        SetRow(footer, 2);
        Children.Add(footer);
    }

    public object SelectedItem {
        get { return (object)GetValue(SelectedItemProperty); }
        set { SetValue(SelectedItemProperty, value); }
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty SelectedItemProperty =
        DependencyProperty.Register("SelectedItem", typeof(object), typeof(DatewiseSummary), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(DatewiseSummary), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged
        });

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (DatewiseSummary)d;
        var list = (IEnumerable<DateEntry>)e.NewValue;
        double billTotal = 0;
        double paymentTotal = 0;
        foreach (var item in list) {
            billTotal += item.Bill;
            paymentTotal += item.Payment;
        };
        o.totalBill.Text = billTotal.ToString("N2");
        o.totalPayment.Text = paymentTotal.ToString("N2");
    }
}
