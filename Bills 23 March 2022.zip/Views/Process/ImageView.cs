﻿class ImageView : CardView
{
    public override string Header => "Image";
    ActionButton blackWhite, gray, normal;
    Image image;
    ImageVM vm;
    public ImageView() {
        vm = new ImageVM();
        DataContext = vm;
        initialize();
        bind();
    }
    void initialize() {
        blackWhite = new ActionButton() {
            Icon = Icons.ImageBW,
            ToolTip = "Black & White",
            Command = vm.MakeBlackWhite
        };
        gray = new ActionButton() {
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.ImageGray,
            ToolTip = "GrayScale",
            Command = vm.MakeGray
        };
        normal = new ActionButton() {
            Icon = Icons.ImageColor,
            ToolTip = "Camera",
            Command = vm.MakeNormal
        };
        addActions(blackWhite);
        addActions(gray);
        addActions(normal);

        image = new Image();
        var scroll = new ScrollViewerEx() { Content = image };
        setContent(scroll);
    }
    void bind() {
        image.SetBinding(Image.SourceProperty, new Binding( nameof(vm.Bitmap)));
        var converter = new BooleanToVisibilityConverter();
        blackWhite.SetBinding(ActionButton.VisibilityProperty, new Binding(nameof(vm.IsActionsVisible)) { Converter = converter });
        normal.SetBinding(ActionButton.VisibilityProperty, new Binding(nameof(vm.IsActionsVisible)) { Converter = converter });
        gray.SetBinding(ActionButton.VisibilityProperty, new Binding(nameof(vm.IsActionsVisible)) { Converter = converter });
    }
}
