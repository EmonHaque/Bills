﻿class Wasa : SearchBase
{
    public override string Icon => Icons.Water;
    public override string Header => "WASA";
    WasaVM viewModel = new();
    protected override SearchBaseVM vm => viewModel;
    //protected override string display => "Name";
    public Wasa() : base() { }
   
}
