﻿class SummaryGroupSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        double bill = 0; 
        double payment = 0;
        string text = "";
        bool isSeparatorVisible = true;
        if (group.IsBottomLevel) {
            var items = group.Items.OfType<SummaryEntry>();
            //text = "Total " + group.Name;
            bill = items.Sum(x => x.Bill);
            payment = items.Sum(x => x.Payment);
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                var sum = (Tuple<string, double, double, bool>)Convert(subGroup, null, null, null);
                //text = group.ItemCount > 1 ? "Total " + group.Name : group.Name.ToString();
                //isSeparatorVisible = group.ItemCount > 1 ? true : false;
                bill += sum.Item2;
                payment += sum.Item3;
                
            }
        }
        if(group.ItemCount > 1) text = "Total " + group.Name;
        else {
            text = group.Name.ToString();
            isSeparatorVisible = false;
        }
        return new Tuple<string, double, double, bool>(text, bill, payment, isSeparatorVisible);
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
