﻿class BtclVM : SearchBaseVM
{
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.BTCL)).Id;
}
