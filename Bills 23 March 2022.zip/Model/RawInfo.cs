﻿class RawInfo : Notifiable
{
    public string FileName { get; set; }
    public string OutputFileName { get; set; }
    public string FilePath { get; set; }
    public string RawText { get; set; }
    public string Department { get; set; }
    public string CustomerNo { get; set; }
    public string PaidFrom { get; set; }
    public string PaymentDate { get; set; }
    public string TransactionNo { get; set; }
    public string BillNo { get; set; }
    public string Period { get; set; }
    public int DeptId { get; set; }
    public int CustomerId { get; set; }
    public int MobileId { get; set; }
    public double TotalPayment { get; set; }
    public double TotalBill { get; set; }
    public bool IsOk { get; set; }
    public bool IsDuplicate { get; set; }
    public bool HasImageWithSameName { get; set; }
    public ObservableCollection<AmountInfo> PaymentInfo { get; set; }
    public ObservableCollection<AmountInfo> BillInfo { get; set; }
    public RawInfo() {
        PaymentInfo = new ObservableCollection<AmountInfo>();
        BillInfo = new ObservableCollection<AmountInfo>();
    }
}
