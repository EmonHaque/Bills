﻿class HeadwiseSummaryEntryTemplate : DataTemplate
{
    public HeadwiseSummaryEntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var account = new FrameworkElementFactory(typeof(TextBlock));
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        bill.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        bill.SetValue(Grid.ColumnProperty, 1);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(Grid.ColumnProperty, 2);

        account.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.DeptName)));

        bill.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.Bill)) { StringFormat = Constants.NumberFormat });
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryEntry.Payment)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(account);
        grid.AppendChild(bill);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}
