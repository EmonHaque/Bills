﻿class SQL
{
    public static object key;
    public static SqliteConnection connection;
    public static SqliteCommand command;
    public static void Initialize() {
        key = new();
        connection = new(Constants.ConnectionString);
        connection.Open();
        command = connection.CreateCommand();
    }
    public static bool Transaction(IEnumerable<SqliteCommand> commands) {
        bool result = true;
        using var transaction = connection.BeginTransaction();
        try {
            foreach (var command in commands) {
                command.Connection = connection;
                command.Transaction = transaction;
                command.ExecuteNonQuery();
            }
            transaction.Commit();
        }
        catch (Exception e) {
            transaction.Rollback();
            result = false;
        }
        return result;
    }
    public static bool Transaction(List<KeyValuePair<string, List<SqliteParameter>>> commands) {
        bool result = true;
        command.CommandText = "BEGIN TRANSACTION;";
        command.ExecuteNonQuery();      
        foreach (var item in commands) {
            command.CommandText = item.Key;
            command.Parameters.AddRange(item.Value);
            try { command.ExecuteNonQuery(); }
            catch(Exception e) {
                command.CommandText = "ROLLBACK;";
                command.ExecuteNonQuery();
                result = false;
            }
            command.Parameters.Clear();
            if (!result) break;
        }
        if (result) {
            command.CommandText = "COMMIT;";
            command.ExecuteNonQuery();
        }
        return result;
    }
}
