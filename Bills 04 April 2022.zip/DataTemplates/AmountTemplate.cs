﻿class AmountTemplate : DataTemplate
{
    FinalizeVM vm;
    InfoType type;

    public AmountTemplate(FinalizeVM vm, InfoType type) {
        this.vm = vm;
        this.type = type;
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var headBox = new FrameworkElementFactory(typeof(HeadBox)) { Name = "box" };
        var amountBox = new FrameworkElementFactory(typeof(TextBox));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        amountBox.SetValue(TextBox.BorderThicknessProperty, new Thickness(0));
        amountBox.SetValue(Grid.ColumnProperty, 1);
        amountBox.SetValue(TextBox.TextAlignmentProperty, TextAlignment.Right);

        headBox.SetBinding(TextBox.TextProperty, new Binding(nameof(AmountInfo.Head)));
        amountBox.SetBinding(TextBox.TextProperty, new Binding(nameof(AmountInfo.Amount)) { StringFormat = "N2" });
        amountBox.AddHandler(TextBox.TextChangedEvent, new TextChangedEventHandler(onTextChanged));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(headBox);
        grid.AppendChild(amountBox);
        VisualTree = grid;
    }
    void onTextChanged(object sender, TextChangedEventArgs e) {
        if (vm.Info is null) return;
        var box = (TextBox)sender;

        var info = (AmountInfo)box.DataContext;
        if (double.TryParse(box.Text, out var number)) {
            if (info.Amount == number) return;
            info.Amount = number;
            if(type == InfoType.Bill) {
                vm.Info.TotalBill = vm.Info.BillInfo.Sum(x => x.Amount);
                vm.Info.OnPropertyChanged(nameof(RawInfo.TotalBill));
            }
            else {
                vm.Info.TotalPayment = vm.Info.PaymentInfo.Sum(x => x.Amount);
                vm.Info.OnPropertyChanged(nameof(RawInfo.TotalPayment));
                vm.RaiseBillChanged();
            }
        }
    }
}