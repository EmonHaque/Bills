﻿BEGIN;
CREATE TABLE Department(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	Name 			TEXT
);
CREATE TABLE Account(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	DeptId			INTEGER,
	AccountNo 		TEXT,
	Name			TEXT,
	Address			TEXT
);
CREATE TABLE Mobile(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	Name 			TEXT
);
CREATE TABLE Heads(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	Name 			TEXT
);
CREATE TABLE Bills(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	DeptId			INTEGER,
	AccountId		INTEGER,
	BillNo 			TEXT,
	FileName		TEXT,
	Period			TEXT,
	PaymentDate		TEXT,
	MobileId		INTEGER,
	TransactionId	TEXT
);
CREATE TABLE BillEntries(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	BillId			INTEGER,
	HeadId			INTEGER,
	Amount			REAL
);
CREATE TABLE PaymentEntries(
	Id 				INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	BillId			INTEGER,
	HeadId			INTEGER,
	Amount			REAL
);

INSERT INTO Department(Name) VALUES
("WASA"),
("DESCO"),
("BTCL"),
("TGCL");

INSERT INTO Heads(Name) VALUES
("Amount"),
("Surcharge"),
("VAT"),
("Fee");

END;