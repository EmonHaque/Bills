﻿class ImageProcessor
{
    public static BitmapImage GetGrayScale(string filePath) {
        var mat = new OpenCvSharp.Mat(filePath, OpenCvSharp.ImreadModes.Grayscale);
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.StreamSource = mat.ToMemoryStream();
        bmp.EndInit();
        mat.Dispose();
        return bmp;
    }
    public static BitmapImage GetBlackAndWhite(string filePath) {
        var mat = new OpenCvSharp.Mat(filePath, OpenCvSharp.ImreadModes.Grayscale);
        var outMat = new OpenCvSharp.Mat();
        OpenCvSharp.Cv2.Threshold(mat, outMat, 200, 255, OpenCvSharp.ThresholdTypes.BinaryInv);
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.StreamSource = outMat.ToMemoryStream();
        bmp.EndInit();
        mat.Dispose();
        outMat.Dispose();
        return bmp;
    }
    public static BitmapImage GetNormal(string filePath) {
        var mat = new OpenCvSharp.Mat(filePath);
        var bmp = new BitmapImage();
        bmp.BeginInit();
        bmp.StreamSource = mat.ToMemoryStream();
        bmp.EndInit();
        mat.Dispose();
        return bmp;
    }
}
