﻿class KeyValueSeries
{
    public string Name { get; set; }
    public double Total { get; set; }
}
