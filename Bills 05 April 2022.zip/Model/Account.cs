﻿class Account : Notifiable
{
    public int Id { get; set; }
    public int DeptId { get; set; }
    public string AccountNo { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
}
