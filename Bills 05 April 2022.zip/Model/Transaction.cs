﻿class Transaction
{
    public Bill Bill { get; set; }
    public List<BillEntry> BillEntries { get; set; }
    public List<PaymentEntry> PaymentEntries { get; set; }
    public Transaction() {
        BillEntries = new List<BillEntry>();
        PaymentEntries = new List<PaymentEntry>();
    }
}
