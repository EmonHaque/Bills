﻿class DateEntry
{
    public DateTime Date { get; set; }
    public double Bill { get; set; }
    public double Payment { get; set; }
}
