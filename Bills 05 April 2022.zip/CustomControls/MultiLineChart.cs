﻿class MultiLineChart : Panel
{
    double x1Max;
    int numSteps = 5;
    Size bottomLabelDesired;

    public MultiLineChart() {
        LayoutTransform = new ScaleTransform() { ScaleY = -1 };
    }
    void addLabel(string date) {
        var label = new TextBlock() {
            Tag = "Label",
            Text = date,
            IsHitTestVisible = false,
            TextAlignment = TextAlignment.Right,
            Padding = new Thickness(0, 0, 5, 0),
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
            }
        };
        Children.Add(label);
        label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        if (label.DesiredSize.Width > bottomLabelDesired.Width)
            bottomLabelDesired = label.DesiredSize;
        //label.Loaded += animateLabels;
    }
    void addLine() {
        var line = new Line() {
            StrokeThickness = 0.25,
            Stroke = Brushes.LightGray,
            StrokeDashCap = PenLineCap.Flat,
            StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
            IsHitTestVisible = false
        };
        Children.Add(line);
        SetZIndex(line, 1);
        //line.Loaded += animateLines;
    }
    void addX1Tick(double value) {
        var tick = new TextBlock() {
            Tag = "x1Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Left,
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void generateChart(List<PinSeries> list) {
        bottomLabelDesired = new Size(0, 0);
        x1Max = 0;
        var payments = new List<double>();
        foreach (var entry in list) {
            Pin pin = new(entry);
            Children.Add(pin);
            SetZIndex(pin, 3);
            addLabel(entry.Date.ToString("yyyy-MM-dd"));
            payments.Add(entry.LineAmount);
            if (entry.LineAmount > x1Max) x1Max = entry.LineAmount;
        }
        var path = new LineStream(payments);
        Children.Add(path);
        SetZIndex(path, 2);

        x1Max = Math.Ceiling(x1Max);
        double step = x1Max / (numSteps -1);
        var current = 0d;
        for (int i = 0; i < numSteps; i++) {
            addLine();
            addX1Tick(current);
            current += step;
        }
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if (finalSize.Width < 20 || finalSize.Height == 0) return finalSize;
   
        var x1Tick = new TextBlock() { Text = x1Max.ToString("N0") };
        x1Tick.Measure(finalSize);
        var labelHeight = bottomLabelDesired.Width;

        var bars = Children.OfType<Pin>().Count();
        var x1TickSpace = x1Tick.DesiredSize.Width;
        var pinWidth = (finalSize.Width - x1TickSpace) / bars;

        var remainingHeight = finalSize.Height - labelHeight;
        var lineSpace = remainingHeight / numSteps;
        var availableHeight = remainingHeight / numSteps * (numSteps - 1);
        var barSpace = x1TickSpace;
        var labelSpace = x1TickSpace + pinWidth / 2 - bottomLabelDesired.Height / 2;
        var y = labelHeight;
        var pinTickY = labelHeight;
        var availableWidth = finalSize.Width - x1Tick.DesiredSize.Width - pinWidth;

        if (availableWidth < 5 || availableHeight < 5) return finalSize;
        foreach (UIElement item in Children) {
            if (item is Pin) {
                var rect = (Pin)item;
                rect.upperBound = x1Max;
                rect.Measure(new Size(pinWidth, availableHeight));
                rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                barSpace += pinWidth;
            }
            else if (item is LineStream) {
                var path = (LineStream)item;
                path.SetParameters(availableWidth, availableHeight, 0d, x1Max, pinWidth);
                path.Arrange(new Rect(new Point(x1Tick.DesiredSize.Width + pinWidth / 2, labelHeight), path.DesiredSize));
            }
            else if (item is Line) {
                var line = (Line)item;
                //line.X1 = sideLabelDesired.Height;
                line.X2 = finalSize.Width;
                line.Y1 = line.Y2 = y;
                item.Measure(finalSize);
                item.Arrange(new Rect(item.DesiredSize));
                y += lineSpace;
            }
            else if (item is TextBlock) {
                var block = (TextBlock)item;
                if (string.Equals(block.Tag.ToString(), "x1Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(0, pinTickY + block.DesiredSize.Height), block.DesiredSize));
                    pinTickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "Label")) {
                    block.Width = bottomLabelDesired.Width;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                    labelSpace += pinWidth;
                }
                else if (string.Equals(block.Tag.ToString(), "x1Label")) {
                    block.Width = remainingHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(block.DesiredSize.Height, labelHeight), block.DesiredSize));
                }
            }
        }

        return finalSize;
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(MultiLineChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged,
            AffectsArrange = true
        });

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as MultiLineChart;
        o.Children.Clear();
        var list = ((IEnumerable<PinSeries>)e.NewValue).ToList();
        if(list.Count > 0) o.generateChart(list);
    }
}
