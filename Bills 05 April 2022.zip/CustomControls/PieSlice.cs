﻿public class PieSlice : FrameworkElement
{
    PathGeometry geometry, arcPointAnimGeo;
    PathFigure figure;
    LineSegment startLine;
    ArcSegment arc;
    SolidColorBrush original, background;
    DoubleAnimation translateX, translateY;
    ColorAnimation colorAnim;
    PointAnimationUsingPath arcPointAnim;
    TranslateTransform transform;
    double dx, dy, rotation;
    
    Point center, start, end;
    public object value;
    bool isSelected;
    public bool IsSelected {
        get { return isSelected; }
        set {
            if (isSelected != value) {
                isSelected = value;
                if (!isSelected) OnMouseLeave(null);
            }
        }
    }

    public PieSlice(SolidColorBrush brush, object value) {
        this.value = value;
        original = brush;
        background = new SolidColorBrush(original.Color);
        startLine = new LineSegment();
        arc = new ArcSegment() { SweepDirection = SweepDirection.Clockwise };
        figure = new PathFigure() { Segments = { startLine, arc } };
        geometry = new PathGeometry() { Figures = { figure } };
        initAnimations();
        transform = new TranslateTransform(0, 0);
        RenderTransform = new TransformGroup() {
            Children = {
                    new ScaleTransform(1, 1),
                    new RotateTransform(360)
                }
        };
        Loaded += animateSlice;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        arcPointAnimGeo = null;
        Loaded -= animateSlice;
        Unloaded -= onUnloaded;
    }
    void initAnimations() {
        var ease = new CubicEase() { EasingMode = EasingMode.EaseOut };
        var duration = TimeSpan.FromSeconds(1);
        translateX = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        translateY = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        colorAnim = new ColorAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        arcPointAnim = new PointAnimationUsingPath() {
            Duration = duration,
            AccelerationRatio = 0.6,
            DecelerationRatio = 0.4,
            PathGeometry = arcPointAnimGeo
        };
    }
    void animateSlice(object sender, RoutedEventArgs e) {
        var scale = (ScaleTransform)((TransformGroup)RenderTransform).Children[0];
        var rotate = (RotateTransform)((TransformGroup)RenderTransform).Children[1];
        var scaleAndRotate = new DoubleAnimation() {
            From = 0,
            Duration = TimeSpan.FromSeconds(2),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };

        scale.CenterX = rotate.CenterX = center.X;
        scale.CenterY = rotate.CenterY = center.Y;
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAndRotate);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAndRotate);
        rotate.BeginAnimation(RotateTransform.AngleProperty, scaleAndRotate);
        rotate.Changed += updateAngle;
        arc.BeginAnimation(ArcSegment.PointProperty, arcPointAnim);
    }
    void updateAngle(object sender, EventArgs e) {
        rotation = ((RotateTransform)sender).Angle;
        if (rotation == 360) {
            ((RotateTransform)sender).Changed -= updateAngle;
            RenderTransform = transform;
            if (IsSelected) OnMouseEnter(null);

        }
    }
    public void SetParameters(Point center, double radius, double startAngle, double sweepAngle, bool isLargeArc) {
        this.center = center;
        start = new Point(center.X + radius * Math.Cos(startAngle), center.Y + radius * Math.Sin(startAngle));
        end = new Point(center.X + radius * Math.Cos(startAngle + sweepAngle), center.Y + radius * Math.Sin(startAngle + sweepAngle));
        var size = new Size(radius, radius);
        dx = 10 * Math.Cos(startAngle + sweepAngle / 2);
        dy = 10 * Math.Sin(startAngle + sweepAngle / 2);
        arcPointAnimGeo = new PathGeometry() {
            Figures = {
                    new PathFigure() {
                        StartPoint = start,
                        Segments = {
                            new ArcSegment() {
                                SweepDirection = SweepDirection.Clockwise,
                                Point = end,
                                Size = size,
                                IsLargeArc = isLargeArc
                            }
                        }
                    }
                }
        };
        arcPointAnimGeo.Freeze();
        figure.StartPoint = center;
        startLine.Point = start;
        arc.Point = end;
        arc.Size = size;
        arc.IsLargeArc = isLargeArc;
        InvalidateVisual();
    }
    protected override void OnRender(DrawingContext dc) => dc.DrawGeometry(background, null, geometry);
    protected override void OnMouseEnter(MouseEventArgs e) {
        if (rotation < 360) return;
        translateX.By = dx - transform.X;
        translateY.By = dy - transform.Y;
        translateX.BeginTime = translateY.BeginTime = TimeSpan.FromSeconds(0);
        RenderTransform.BeginAnimation(TranslateTransform.XProperty, translateX);
        RenderTransform.BeginAnimation(TranslateTransform.YProperty, translateY);
        colorAnim.To = Colors.Gray;
        background.BeginAnimation(SolidColorBrush.ColorProperty, colorAnim);
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (rotation < 360) return;
        if (IsSelected) return;
        translateX.By = -transform.X;
        translateY.By = -transform.Y;
        translateX.BeginTime = translateY.BeginTime = TimeSpan.FromSeconds(0.5);
        RenderTransform.BeginAnimation(TranslateTransform.XProperty, translateX);
        RenderTransform.BeginAnimation(TranslateTransform.YProperty, translateY);
        colorAnim.To = original.Color;
        background.BeginAnimation(SolidColorBrush.ColorProperty, colorAnim);
    }
}
