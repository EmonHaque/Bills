﻿class ListBoxEx : ListBox
{
    public override void EndInit() {
        base.EndInit();
        var border = (Border)VisualTreeHelper.GetChild(this, 0);
        var scroll = (ScrollViewer)VisualTreeHelper.GetChild(border, 0);
        ((Rectangle)scroll.Template.FindName("Corner", scroll)).Fill = Constants.Background;
    }
}
