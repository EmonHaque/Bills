﻿class DeptSummaryTemplate : DataTemplate
{
    public DeptSummaryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var head = new FrameworkElementFactory(typeof(TextBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        amount.SetValue(Grid.ColumnProperty, 1);
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        head.SetBinding(TextBlock.TextProperty, new Binding(nameof(KeyValueSeries.Name)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(KeyValueSeries.Total)) { StringFormat = "N2" });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(head);
        grid.AppendChild(amount);
        VisualTree = grid;
    }
}
