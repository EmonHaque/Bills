﻿class AppData
{
    public static int MaxBillId;
    public static ObservableCollection<Department> departments = new();
    public static ObservableCollection<Account> accounts = new();
    public static ObservableCollection<Mobile> mobiles = new();
    public static ObservableCollection<Head> heads = new();
    public AppData() {
        checkDatabase();
    }
    void checkDatabase() {
        bool isInitialized = false;
        if (!System.IO.File.Exists(Constants.DBName)) {
            createDatabase();
            isInitialized = true;
        }
        if (!System.IO.Directory.Exists(Constants.ImageFolder)) {
            System.IO.Directory.CreateDirectory(Constants.ImageFolder);
        }
        if (!System.IO.Directory.Exists(Constants.TempFolder)) {
            System.IO.Directory.CreateDirectory(Constants.TempFolder);
        }
        if (!isInitialized) SQL.Initialize();
        populateCollections();
    }
    void createDatabase() {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Bills.Resources.dBase.sql");
        using var sReader = new System.IO.StreamReader(stream);
        SQL.Initialize();
        SQL.command.CommandText = sReader.ReadToEnd();
        SQL.command.ExecuteNonQuery();
    }
    void populateCollections() {
        SQL.command.CommandText = @"SELECT * FROM Department;
                                    SELECT * FROM Account;
                                    SELECT * FROM Mobile;
                                    SELECT * FROM Heads;
                                    SELECT MAX(Id) FROM Bills;";
        var reader = SQL.command.ExecuteReader();

        while (reader.Read()) {
            departments.Add(new Department() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            accounts.Add(new Account() {
                Id = reader.GetInt32(0),
                DeptId = reader.GetInt32(1),
                AccountNo = reader.GetString(2),
                Name = reader.GetString(3),
                Address = reader.GetString(4)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            mobiles.Add(new Mobile() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            heads.Add(new Head() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        reader.Read();
        MaxBillId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
        reader.Close();
        reader.DisposeAsync();
    }
    public static bool HasAccount(string deptName, string account) {
        var dept = GetDepartment(deptName);
        var acc = accounts.FirstOrDefault(x => x.DeptId == dept.Id && x.AccountNo.Equals(account));
        return acc is not null;
    }
    public static Department GetDepartment(string name) {
        var dept = departments.FirstOrDefault(x => x.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase));
        if (dept is null) {
            insertDepartment(name);
            dept = departments.Last();
        }
        return dept;
    }   
    public static Account GetAccount(string deptName, string account, string name, string address) {
        var dept = GetDepartment(deptName);
        var acc = new Account() {
            Id = accounts.Count == 0 ? 1 : accounts.Max(x => x.Id) + 1,
            DeptId = dept.Id,
            AccountNo = account,
            Name = name,
            Address = address
        };
        insertAccount(acc);
        return acc;
    }
    public static Head GetHead(string name) {
        var head = heads.FirstOrDefault(x => x.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase));
        if (head is null) {
            var info = new CultureInfo("en-US", false).TextInfo;
            insertHead(info.ToTitleCase(name));
            head = heads.Last();
        }
        return head;
    }
    public static Mobile GetMobile(string cell) {
        var no = mobiles.FirstOrDefault(x => x.Name.Equals(cell));
        if (no is null) {
            insertMobile(cell);
            no = mobiles.Last();
        }
        return no;
    }
    public static void UpdateAccount(Account a) {
        lock (SQL.key) {
            SQL.command.CommandText = @"UPDATE Account SET AccountNo = @No, Name = @Name, Address = @Address WHERE Id = @Id";
            SQL.command.Parameters.AddWithValue("@No", a.AccountNo);
            SQL.command.Parameters.AddWithValue("@Name", a.Name);
            SQL.command.Parameters.AddWithValue("@Address", a.Address);
            SQL.command.Parameters.AddWithValue("@Id", a.Id);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
    }
    public static void UpdateEntries(List<UpdatedEntry> entries) {
        List<KeyValuePair<string, List<SqliteParameter>>> commands = new();
        foreach (var entry in entries) {
            var command = $"UPDATE {entry.Table} SET Amount = @Amount WHERE Id = @Id";
            var paras = new List<SqliteParameter>() {
                new SqliteParameter("@Amount", entry.Amount),
                new SqliteParameter("@Id", entry.Id)
            };
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, paras));
        }
        lock (SQL.key) SQL.Transaction(commands);
    }
    public static void UpdateBill(ReportEntry entry, string newFile = null) {
        object mobile = string.IsNullOrWhiteSpace(entry.Mobile) ? DBNull.Value : GetMobile(entry.Mobile).Id;
        object billNo = string.IsNullOrWhiteSpace(entry.BillNo) ? DBNull.Value : entry.BillNo;
        lock (SQL.key) {
            if (newFile is not null) {
                SQL.command.CommandText = @"UPDATE Bills SET BillNo = @BillNo, FileName = @FileName, Period = @Period, 
                         PaymentDate = @Date, MobileId = @Mobile, TransactionId = @Transaction WHERE Id = @Id";
                SQL.command.Parameters.AddWithValue("@FileName", newFile);
                System.IO.File.Move($"{Constants.ImageFolder}/{entry.FileName}", $"{Constants.ImageFolder}/{newFile}");
            }
            else {
                SQL.command.CommandText = @"UPDATE Bills SET BillNo = @BillNo, Period = @Period, 
                         PaymentDate = @Date, MobileId = @Mobile, TransactionId = @Transaction WHERE Id = @Id";
            }
            SQL.command.Parameters.AddWithValue("@BillNo", billNo);
            SQL.command.Parameters.AddWithValue("@Period", entry.Period);
            SQL.command.Parameters.AddWithValue("@Date", entry.PaymentDate.ToString("yyyy-MM-dd"));
            SQL.command.Parameters.AddWithValue("@Mobile", mobile);
            SQL.command.Parameters.AddWithValue("@Transaction", entry.TransactionId);
            SQL.command.Parameters.AddWithValue("@Id", entry.BillId);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
    }
    static void insertDepartment(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Department(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        departments.Add(new Department() {
            Id = departments.Max(x => x.Id) + 1,
            Name = name
        });
    }
    static void insertAccount(Account a) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Account(DeptId, AccountNo, Name, Address) VALUES(@DeptId, @AccountNo, @Name, @Address)";
            SQL.command.Parameters.AddWithValue("@DeptId", a.DeptId);
            SQL.command.Parameters.AddWithValue("@AccountNo", a.AccountNo);
            SQL.command.Parameters.AddWithValue("@Name", a.Name);
            SQL.command.Parameters.AddWithValue("@Address", a.Address);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        accounts.Add(a);
    }
    static void insertHead(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Heads(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        App.Current.Dispatcher.Invoke(() => {
            heads.Add(new Head() {
                Id = heads.Max(x => x.Id) + 1,
                Name = name
            });
        });
    }
    static void insertMobile(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Mobile(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        mobiles.Add(new Mobile() {
            Id = mobiles.Count == 0 ? 1 : mobiles.Max(x => x.Id) + 1,
            Name = name
        });
    }
}
