﻿class Desco : SearchBase
{
    public override string Icon => Icons.Electricity;
    public override string Header => "DESCO";
    DescoVM viewModel = new();
    protected override SearchBaseVM vm => viewModel;
}
