﻿class PeriodicView : CardView
{
    public override string Header => "Summary";
    public override string Icon => Icons.Sigma;
    DayPicker startDate, endDate;
    ActionButton refresh;
    Grid reportGrid;
    DatewiseSummary dateReport;
    MultiLineChart dateChart;
    HeadwiseSummary headReport;
    PieChart deptChart;
    DetailSummary detailReport;
    DeptwiseSummary deptSummary;
    PeriodicVM vm;
    public static double Top { get; set; }
    public static double Left { get; set; }
    public static double Width { get; set; }
    public static double Height { get; set; }

    public PeriodicView() {
        vm = new PeriodicVM();
        DataContext = vm;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void initializeUI() {
        var title = new TextBlock() { 
            Text = "for the period ",
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
            FontSize = 14
        };
        startDate = new DayPicker() {
            Hint = "from",
            Width = 190,
            StartDate = vm.MinDate,
            EndDate = DateTime.Today,
            DateFormat = "dd/MM/yyyy"
        };
        endDate = new DayPicker() {
            Hint = "to",
            Width = 190,
            StartDate = vm.MinDate,
            EndDate = DateTime.Today,
            DateFormat = "dd/MM/yyyy"
        };
        refresh = new ActionButton() {
            Margin = new Thickness(5,0,0,0),
            ToolTip = "Refresh",
            Icon = Icons.Refresh,
            Command = vm.RefreshReports
        };
        initializeReportGrid();
        Grid.SetColumn(startDate, 1);
        Grid.SetColumn(endDate, 2);
        Grid.SetColumn(refresh, 3);
        Grid.SetRow(reportGrid, 1);
        Grid.SetColumnSpan(reportGrid, 4);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition() {Height = new GridLength(50)},
                new RowDefinition(),
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto},
                new ColumnDefinition() { Width = GridLength.Auto},
                new ColumnDefinition() { Width = GridLength.Auto}
            },
            Children = { title, startDate, endDate, refresh, reportGrid }
        };
        setContent(grid);
    }
    void initializeReportGrid() {
        dateChart = new MultiLineChart() { Margin = new Thickness(0, 0, 0, 10) };
        deptChart = new PieChart() { 
            IsSelectable = true,
            SelectedValuePath = nameof(KeyValueSeries.Name)
        };
        deptSummary = new DeptwiseSummary();
        Grid.SetRow(deptChart, 1);
        Grid.SetRow(deptSummary, 2);
        var charts = new Grid() {
            Margin = new Thickness(10,0,0,0),
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(.7, GridUnitType.Star)}
            },
            Children = { dateChart, deptChart, deptSummary }
        };
        dateReport = new DatewiseSummary();
        detailReport = new DetailSummary();
        headReport = new HeadwiseSummary();

        Grid.SetColumn(detailReport, 1);
        Grid.SetRowSpan(detailReport, 3);
        Grid.SetRow(headReport, 2);
        Grid.SetColumn(charts, 2);
        Grid.SetRowSpan(charts, 3);
        reportGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = new GridLength(20)},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = {dateReport, headReport, detailReport, charts }
        };
    }
    void bind() {
        startDate.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.StartDate)));
        endDate.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.EndDate)));
        dateReport.SetBinding(DatewiseSummary.ItemsSourceProperty, new Binding(nameof(vm.DatewiseReport)));
        dateReport.SetBinding(DatewiseSummary.SelectedItemProperty, new Binding(nameof(vm.SelectedPaymentDate)));
        dateChart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(vm.DateSeries)));
        headReport.SetBinding(HeadwiseSummary.ItemsSourceProperty, new Binding(nameof(vm.HeadwiseReport)));
        detailReport.SetBinding(DetailSummary.ItemsSourceProperty, new Binding(nameof(vm.DetailReport)));
        deptChart.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.DeptSeries)));
        deptChart.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(vm.SelectedDept)));
        deptSummary.SetBinding(DeptwiseSummary.ItemsSourceProperty, new Binding(nameof(vm.DeptSummary)));
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var zeros = new Point(0, 0);
        var left = startDate.TransformToAncestor(this).Transform(zeros);   
        var bottom = detailReport.TransformToAncestor(this).Transform(zeros);

        var top = PointToScreen(zeros);
        left = PointToScreen(left);
        bottom = PointToScreen(bottom);

        left.X /= dpi.DpiScaleX;
        top.Y /= dpi.DpiScaleY;
        bottom.Y /= dpi.DpiScaleY;

        Top = top.Y + Constants.CardMargin.Top;
        Left = left.X;
        Width = 418;
        Height = bottom.Y - top.Y + 10;
    }
}
