﻿class AccountsView : CardView
{
    public override string Header => "Accounts";
    public override string Icon => Icons.Accounts;

    EditText search;
    TextBlock numAccounts;
    ListBoxEx deptwiseList;

    AccountsVM vm;
    public AccountsView() {
        vm = new AccountsVM();
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search
        };
        numAccounts = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(numAccounts, 1);
        var topGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto }
            },
            Children = { search, numAccounts }
        };
        deptwiseList = new ListBoxEx() {
            ItemTemplate = new AccountTemplate(vm),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)){
                            Setters = { new Setter(GroupItem.TemplateProperty, new AccountGroupTemplate())}
                    }
                }
            }
        };
        deptwiseList.SetValue(Grid.IsSharedSizeScopeProperty, true);

        Grid.SetColumnSpan(topGrid, 3);
        Grid.SetRow(deptwiseList, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topGrid, deptwiseList }
        };
        setContent(grid);
    }
    void bind() {
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        deptwiseList.SetBinding(ListBoxEx.ItemsSourceProperty, new Binding(nameof(vm.Accounts)));
       
        numAccounts.SetBinding(TextBlock.TextProperty, new Binding() {
            Path = new PropertyPath($"{nameof(ListBox.Items)}.{nameof(ListBox.Items.Count)}"),
            StringFormat = "N0",
            Source = deptwiseList,
            Mode = BindingMode.OneWay
        });
    }
}
