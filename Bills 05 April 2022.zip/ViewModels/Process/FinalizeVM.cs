﻿class FinalizeVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public RawInfo Info { get; set; }
    public AmountInfo SelectedBill { get; set; }
    public AmountInfo SelectedPayment { get; set; }
    public bool CanShowInfo { get; set; }
    public static event Action BillChanged;
    public static event Action OkChanged;
    public static event Action AdjustOkCount;
    public FinalizeVM() {
        LoadVM.SelectionChanged += onSelectionChanged;
    }
    public void onOkAdjustment() {
        Info.IsOk = false;
        Info.OnPropertyChanged(nameof(RawInfo.IsOk));
        AdjustOkCount?.Invoke();
    }
    void onSelectionChanged(RawInfo info) {
        if(Info is not null) Info.AdjustOk -= onOkAdjustment;
        Info = info;
        if(Info is not null) {
            Info.AdjustOk += onOkAdjustment;
            if (!CanShowInfo) {
                CanShowInfo = true;
                OnPropertyChanged(nameof(CanShowInfo));
            }
        }
        else if (CanShowInfo) {
            CanShowInfo = false;
            OnPropertyChanged(nameof(CanShowInfo));
        }
        OnPropertyChanged(nameof(Info));
    }   
    public void SetOk() {
        if (Info is null) return;
        var error = App.BP.ValidationErrors(Info);
        if(error.Count == 0) {
            var dept = AppData.GetDepartment(Info.Department.Trim());
            var customerId = Info.CustomerNo.Trim();
            if (!AppData.HasAccount(dept.Name, customerId)) {
                var dialog = new AccountCreateDialog(dept.Name, customerId);
                if (!dialog.ShowDialog().Value) return;

                var (name, address) = dialog.GetNameAndAddress();
                var account = AppData.GetAccount(dept.Name, customerId, name, address);
                Info.CustomerId = account.Id;
            }
            else Info.CustomerId = AppData.accounts.First(x => x.AccountNo.Equals(customerId)).Id;
            
            var hasCell = !string.IsNullOrWhiteSpace(Info.PaidFrom);
            if (hasCell) Info.MobileId = AppData.GetMobile(Info.PaidFrom).Id;
            Info.DeptId = dept.Id;
            OkChanged?.Invoke();
        }
        else {
            var errorDialog = new BillErrorDialog(Left, Top, Width, Height, error);
            errorDialog.ShowDialog();
        }
    }
    public void RaiseBillChanged() => BillChanged?.Invoke();
    public void RemovePaymentRow() {
        if (SelectedPayment is null) return;
        Info.TotalPayment -= SelectedPayment.Amount;
        Info.PaymentInfo.Remove(SelectedPayment);
        Info.OnPropertyChanged(nameof(RawInfo.TotalPayment));
        BillChanged?.Invoke();
    }
    public void RemoveBillRow() {
        if (SelectedBill is null) return;
        Info.TotalBill -= SelectedBill.Amount;
        Info.BillInfo.Remove(SelectedBill);
        Info.OnPropertyChanged(nameof(RawInfo.TotalBill));
    }
}

