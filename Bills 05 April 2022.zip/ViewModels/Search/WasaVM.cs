﻿class WasaVM : SearchBaseVM
{
    //int deptId;
    //public WasaVM() : base() {
    //    deptId = AppData.departments.First(x => x.Name.Equals(BillProcessor.WASA)).Id;
    //}
    //public override bool filter(object o) {
    //    var acc = (Account)o;
    //    if (string.IsNullOrWhiteSpace(QueryAccount)) return acc.DeptId == deptId;
    //    return acc.DeptId == deptId && acc.AccountNo.Contains(QueryAccount);
    //}
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.WASA)).Id;
}
