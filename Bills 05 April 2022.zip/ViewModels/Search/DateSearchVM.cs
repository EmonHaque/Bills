﻿class DateSearchVM : Notifiable
{
    string imagePath;
    ColorState state;
    List<ReportEntry> reserved;
    DateTime? selectedDate;
    public DateTime? SelectedDate {
        get { return selectedDate; }
        set { selectedDate = value; updateReportables(); }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    ReportEntry selectedBill;
    public ReportEntry SelectedBill {
        get { return selectedBill; }
        set {
            selectedBill = value;
            updateEntryInfo();
            OnPropertyChanged(nameof(SelectedBill));
        }
    }
    bool isAccountOnEdit;
    public bool IsAccountOnEdit {
        get { return isAccountOnEdit; }
        set {
            isAccountOnEdit = value;
            if (value) cloneAccount();
            else updateAccount();
        }
    }
    bool isBillOnEdit;
    public bool IsBillOnEdit {
        get { return isBillOnEdit; }
        set {
            isBillOnEdit = value;
            if (value) cloneBill();
            else updateBill();
        }
    }
    bool areEntriesOnEdit;
    public bool AreEntriesOnEdit {
        get { return areEntriesOnEdit; }
        set {
            areEntriesOnEdit = value;
            if (value) cloneBillEntries();
            else updateBillEntries();
        }
    }
    public ReportEntry EditedBill { get; set; }
    public Account SelectedAccount { get; set; }
    public Account EditedAccount { get; set; }
    public BitmapImage Bitmap { get; set; }
    public List<Breakup> Breakups { get; set; }
    public List<Breakup> EditedBreakups { get; set; }
    public List<KeyValueSeries> BillPieValues { get; set; }
    public List<KeyValueSeries> DeptPieValues { get; set; }
    public double TotalBill { get; set; }
    public double TotalPayment { get; set; }
    public int TotalItem { get; set; }
    public bool HasSelectedItem { get; set; }
    public ICollectionView Reportables { get; set; }
    public bool HasAccount { get; set; }
    public static event Action<Account> AccountChanged;
    public static event Action<ReportEntry> BillChanged;
    public DateSearchVM() {
        Reportables = CollectionViewSource.GetDefaultView(new List<ReportEntry>());
        SelectedDate = DateTime.Today;
        SearchBaseVM.AccountChanged += onAccountUpdated;
        SearchBaseVM.BillChanged += onBillUpdated;
    }

    void onAccountUpdated(Account a) => updateAccountNo(a);
    void updateAccountNo(Account a) {
        foreach (ReportEntry item in Reportables) {
            if (item.AccountId == a.Id) {
                item.AccountNo = a.AccountNo;
                item.OnPropertyChanged(nameof(ReportEntry.AccountNo));
            }
        }
    }
    void onBillUpdated(ReportEntry e) {
        ReportEntry tobeRemoved = null;
        foreach (ReportEntry item in Reportables) {
            if (item.BillId == e.BillId) {
                item.BillNo = e.BillNo;
                item.FileName = e.FileName;
                item.Period = e.Period;
                item.TransactionId = e.TransactionId;
                item.Mobile = e.Mobile;
                if (item.PaymentDate != e.PaymentDate) {
                    item.PaymentDate = e.PaymentDate;
                    tobeRemoved = item;
                }
                item.OnPropertyChanged(null);
                break;
            }
        }
        if(tobeRemoved != null) {
            reserved.Remove(tobeRemoved);
            updateDeptPie();
        }
    }
    bool filter(object o) {
        var e = (ReportEntry)o;
        if (string.IsNullOrWhiteSpace(Query)) 
            return e.PaymentDate.Equals(SelectedDate);
        return e.AccountNo.Contains(Query) && e.PaymentDate.Equals(SelectedDate);
    }
    void updateReportables() {
        TotalItem = 0;
        TotalBill = 0;
        TotalPayment = 0;
        DeptPieValues = new List<KeyValueSeries>();
        OnPropertyChanged(nameof(DeptPieValues));
        Reportables.CollectionChanged -= onCollectionChanged;
        if (SelectedDate is null) {
            Reportables = CollectionViewSource.GetDefaultView(new List<ReportEntry>());
            HasAccount = false;
            OnPropertyChanged(nameof(Reportables));
            OnPropertyChanged(nameof(HasAccount));
            OnPropertyChanged(nameof(DeptPieValues));
            OnPropertyChanged(nameof(TotalItem));
            OnPropertyChanged(nameof(TotalBill));
            OnPropertyChanged(nameof(TotalPayment));
            return;
        }
        reserved = new List<ReportEntry>();
        lock (SQL.key) {
            SQL.command.CommandText = $@"SELECT b.Id, b.DeptId, AccountId, BillNo, Period, TransactionId, m.Name, PaymentDate, FileName,
                                   (SELECT sum(Amount) FROM BillEntries WHERE BillId = b.Id),
                                   (SELECT sum(Amount) FROM PaymentEntries WHERE BillId = b.Id),
                                   a.AccountNo
                                   FROM Bills b
                                   LEFT JOIN Mobile m ON m.Id = b.MobileId
                                   LEFT JOIN Account a ON a.Id = b.AccountId 
                                   WHERE PaymentDate = '{SelectedDate.Value.ToString("yyyy-MM-dd")}'";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                reserved.Add(new ReportEntry() {
                    BillId = reader.GetInt32(0),
                    DeptId = reader.GetInt32(1),
                    AccountId = reader.GetInt32(2),
                    BillNo = reader.IsDBNull(3) ? "" : reader.GetString(3),
                    Period = reader.GetString(4),
                    TransactionId = reader.GetString(5),
                    Mobile = reader.IsDBNull(6) ? null : reader.GetString(6),
                    PaymentDate = reader.GetDateTime(7),
                    FileName = reader.GetString(8),
                    Bill = reader.GetDouble(9),
                    Payment = reader.GetDouble(10),
                    AccountNo = reader.GetString(11)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        if (reserved.Count > 0) {
            Reportables = new CollectionViewSource() {
                Source = reserved,
                IsLiveGroupingRequested = true,
                IsLiveFilteringRequested = true,
                LiveGroupingProperties = { nameof(ReportEntry.DeptId) },
                LiveFilteringProperties = { nameof(ReportEntry.PaymentDate) }
            }.View;
            Reportables.CollectionChanged += onCollectionChanged;
            Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReportEntry.DeptId)));
            Reportables.Filter = filter;
            
            updateDeptPie();
        }
        else {
            Reportables = CollectionViewSource.GetDefaultView(new List<ReportEntry>());
            OnPropertyChanged(nameof(TotalItem));
            OnPropertyChanged(nameof(TotalBill));
            OnPropertyChanged(nameof(TotalPayment));
        }
        
        if (!HasAccount) {
            HasAccount = true;
            OnPropertyChanged(nameof(HasAccount));
        }
        OnPropertyChanged(nameof(Reportables));
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalItem = 0;
        TotalBill = 0;
        TotalPayment = 0;
        foreach (ReportEntry item in Reportables) {
            TotalItem++;
            TotalBill += item.Bill;
            TotalPayment += item.Payment;
        }
        OnPropertyChanged(nameof(TotalItem));
        OnPropertyChanged(nameof(TotalBill));
        OnPropertyChanged(nameof(TotalPayment));
    }
    void updateEntryInfo() {
        Breakups = new List<Breakup>();
        BillPieValues = new List<KeyValueSeries>();
        HasSelectedItem = true;
        if (SelectedBill is null) {
            Bitmap = null;
            HasSelectedItem = false;
            SelectedAccount = null;
            OnPropertyChanged(nameof(Bitmap));
            OnPropertyChanged(nameof(HasSelectedItem));
            OnPropertyChanged(nameof(BillPieValues));
            OnPropertyChanged(nameof(Breakups));
            OnPropertyChanged(nameof(SelectedAccount));
            return;
        }
        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH T1(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, Amount , null, Id, null FROM BillEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ), 
                                        T2(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, null, Amount, null, Id FROM PaymentEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ),
                                        --T3 FULL OUTER JOIN
                                        T3 (Head, Bill, Payment, BillId, PaymentId) AS (
                                            SELECT t1.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T1 t1 LEFT JOIN T2 t2 ON t1.Head = t2.Head	
                                            UNION  ALL
                                            SELECT t2.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T2 t2 LEFT JOIN T1 t1 ON t2.Head = t1.Head
                                            WHERE t1.Head IS NULL
                                        )
                                        SELECT h.Name, coalesce(Bill, 0), coalesce(Payment, 0), coalesce(BillId, 0), coalesce(PaymentId, 0) 
                                        FROM T3 LEFT JOIN Heads h ON h.Id = Head
                                        ORDER BY h.Id";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Breakups.Add(new Breakup() {
                    Head = reader.GetString(0),
                    Bill = reader.GetDouble(1),
                    Payment = reader.GetDouble(2),
                    BillId = reader.GetInt32(3),
                    PaymentId = reader.GetInt32(4)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        SelectedAccount = AppData.accounts.First(x => x.Id == SelectedBill.AccountId);
        OnPropertyChanged(nameof(SelectedAccount));
        OnPropertyChanged(nameof(Breakups));
        OnPropertyChanged(nameof(HasSelectedItem));
        updateBillPie();
        imagePath = Constants.ImageFolder + "/" + SelectedBill.FileName;
        if (!System.IO.File.Exists(imagePath)) {
            Bitmap = null;
            OnPropertyChanged(nameof(Bitmap));
            return;
        }
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
    }
    void cloneAccount() {
        EditedAccount = new Account() {
            Id = SelectedAccount.Id,
            DeptId = SelectedAccount.DeptId,
            AccountNo = SelectedAccount.AccountNo,
            Name = SelectedAccount.Name,
            Address = SelectedAccount.Address
        };
        OnPropertyChanged(nameof(EditedAccount));
    }
    void updateAccount() {
        if (EditedAccount.Name.Equals(SelectedAccount.Name) &&
            EditedAccount.Address.Equals(SelectedAccount.Address) &&
            EditedAccount.AccountNo.Equals(SelectedAccount.AccountNo)) return;

        AppData.UpdateAccount(EditedAccount);
        SelectedAccount.AccountNo = EditedAccount.AccountNo;
        SelectedAccount.Name = EditedAccount.Name;
        SelectedAccount.Address = EditedAccount.Address;
        SelectedAccount.OnPropertyChanged(null);
        updateAccountNo(SelectedAccount);
        AccountChanged?.Invoke(SelectedAccount);
    }
    void cloneBill() {
        EditedBill = new ReportEntry() {
            BillId = SelectedBill.BillId,
            DeptId = SelectedBill.DeptId,
            BillNo = SelectedBill.BillNo,
            FileName = SelectedBill.FileName,
            PaymentDate = SelectedBill.PaymentDate,
            Period = SelectedBill.Period,
            TransactionId = SelectedBill.TransactionId,
            Mobile = SelectedBill.Mobile
        };
        OnPropertyChanged(nameof(EditedBill));
    }
    void updateBill() {
        bool isDateEqual = SelectedBill.PaymentDate.Equals(EditedBill.PaymentDate);
        bool isTransactionEqual = SelectedBill.TransactionId.Equals(EditedBill.TransactionId);
        if (SelectedBill.Period.Equals(EditedBill.Period) &&
            isDateEqual && isTransactionEqual &&
            SelectedBill.BillNo.Equals(EditedBill.BillNo) &&
            SelectedBill.Mobile.Equals(EditedBill.Mobile)) return;

        if (isDateEqual && isTransactionEqual) AppData.UpdateBill(EditedBill);
        else {
            var date = EditedBill.PaymentDate.ToString("yyyy-MM-dd");
            var dept = AppData.departments.First(x => x.Id == EditedBill.DeptId).Name;
            var newFileName = $"{date}-{dept}-{EditedBill.TransactionId}.png";
            AppData.UpdateBill(EditedBill, newFileName);
            EditedBill.FileName = newFileName;
        }
        
        SelectedBill.BillNo = EditedBill.BillNo;
        SelectedBill.FileName = EditedBill.FileName;
        SelectedBill.PaymentDate = EditedBill.PaymentDate;
        SelectedBill.Period = EditedBill.Period;
        SelectedBill.TransactionId = EditedBill.TransactionId;
        SelectedBill.Mobile = EditedBill.Mobile;
        SelectedBill.OnPropertyChanged(null);

        if (!isDateEqual) {
            reserved.Remove(SelectedBill);
            DeptPieValues = new List<KeyValueSeries>();
            updateDeptPie();
        }
        BillChanged?.Invoke(SelectedBill);
    }
    void cloneBillEntries() {
        EditedBreakups = new List<Breakup>();
        foreach (var item in Breakups) {
            EditedBreakups.Add(new Breakup() {
                Head = item.Head,
                Bill = item.Bill,
                Payment = item.Payment,
                BillId = item.BillId,
                PaymentId = item.PaymentId
            });
        }
        OnPropertyChanged(nameof(EditedBreakups));
    }
    void updateBillEntries() {
        List<UpdatedEntry> entries = new();
        double billAdjustment = 0;
        double paymentAdjustment = 0;
        for (int i = 0; i < Breakups.Count; i++) {
            if (Breakups[i].Bill != EditedBreakups[i].Bill) {
                entries.Add(new UpdatedEntry() {
                    Table = "BillEntries",
                    Id = Breakups[i].BillId,
                    Amount = EditedBreakups[i].Bill
                });
                billAdjustment += (EditedBreakups[i].Bill - Breakups[i].Bill);
            }
            if (Breakups[i].Payment != EditedBreakups[i].Payment) {
                entries.Add(new UpdatedEntry() {
                    Table = "PaymentEntries",
                    Id = Breakups[i].PaymentId,
                    Amount = EditedBreakups[i].Payment
                });
                paymentAdjustment += (EditedBreakups[i].Payment - Breakups[i].Payment);
            }
        }
        if (entries.Count == 0) return;

        AppData.UpdateEntries(entries);
        Breakups = EditedBreakups;
        SelectedBill.Bill += billAdjustment;
        SelectedBill.Payment += paymentAdjustment;
        TotalBill += billAdjustment;
        TotalPayment += paymentAdjustment;

        OnPropertyChanged(nameof(Breakups));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Bill));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Payment));
        OnPropertyChanged(nameof(TotalBill));
        OnPropertyChanged(nameof(TotalPayment));

        BillPieValues = new List<KeyValueSeries>();
        DeptPieValues = new List<KeyValueSeries>();
        updateDeptPie();
        updateBillPie();
    }
    void updateDeptPie() {
        DeptPieValues = reserved
            .GroupBy(x => x.DeptId)
            .Select(x => new KeyValueSeries() {
                Name = AppData.departments.First(y => y.Id == x.Key).Name,
                Total = x.Sum(x => x.Payment)
            }).ToList();
        OnPropertyChanged(nameof(DeptPieValues));
    }
    void updateBillPie() {
        foreach (var breakup in Breakups) {
            BillPieValues.Add(new KeyValueSeries() {
                Name = breakup.Head,
                Total = breakup.Head.Equals("Amount") ? breakup.Bill : breakup.Payment + breakup.Bill
            });
        }
        OnPropertyChanged(nameof(BillPieValues));
    }
    public void Refresh() => updateReportables();
    public void MakeBlackWhite() {
        state = ColorState.BlackWhite;
        Bitmap = ImageProcessor.GetBlackAndWhite(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeGray() {
        state = ColorState.Gray;
        Bitmap = ImageProcessor.GetGrayScale(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeNormal() {
        state = ColorState.Color;
        Bitmap = ImageProcessor.GetNormal(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
}
