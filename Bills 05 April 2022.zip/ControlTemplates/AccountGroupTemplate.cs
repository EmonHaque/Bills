﻿class AccountGroupTemplate : ControlTemplate
{
    public AccountGroupTemplate() {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var header = new FrameworkElementFactory(typeof(Run));
        var openParen = new FrameworkElementFactory(typeof(Run));
        var count = new FrameworkElementFactory(typeof(Run));
        var closeParen = new FrameworkElementFactory(typeof(Run));
        var block = new FrameworkElementFactory(typeof(TextBlock));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        header.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        openParen.SetValue(Run.TextProperty, " (");
        closeParen.SetValue(Run.TextProperty, ")");
        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
        header.SetBinding(Run.TextProperty, new Binding(nameof(GroupItem.Name)) { 
            Converter = new DeptIdToNameConverter(),
            Mode = BindingMode.OneWay
        });
        count.SetBinding(Run.TextProperty, new Binding(nameof(CollectionViewGroup.ItemCount)) { Mode = BindingMode.OneWay });

        block.AppendChild(header);
        block.AppendChild(openParen);
        block.AppendChild(count);
        block.AppendChild(closeParen);

        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(block);
        grid.AppendChild(items);

        VisualTree = grid;
    }
}
