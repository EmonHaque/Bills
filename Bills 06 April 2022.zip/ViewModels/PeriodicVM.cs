﻿class PeriodicVM : Notifiable
{
    List<SummaryEntry> summary, subSummary;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime MinDate { get; set; }
    public List<PinSeries> DateSeries { get; set; }
    public List<KeyValueSeries> DeptSeries { get; set; }
    public List<KeyValueSeries> DeptSummary { get; set; }
    public List<DateEntry> DatewiseReport { get; set; }
    public ICollectionView HeadwiseReport { get; set; }
    public ICollectionView DetailReport { get; set; }
    DateEntry selectedPaymentDate;
    public DateEntry SelectedPaymentDate {
        get { return selectedPaymentDate; }
        set {
            selectedPaymentDate = value;
            subSummary = value is null ? summary : summary.Where(x => x.Date == value.Date).ToList();
            makeHeadWiseSummary();
            makeDetailSummary();
        }
    }
    string selectedDept;
    public string SelectedDept {
        get { return selectedDept; }
        set { selectedDept = value; makeDeptSummary(); }
    }

    public PeriodicVM() {
        StartDate = DateTime.Today.AddYears(-1);
        EndDate = DateTime.Today;
        summary = new List<SummaryEntry>();
        lock (SQL.key) {
            SQL.command.CommandText = "SELECT MIN(PaymentDate) FROM Bills";
            var date = SQL.command.ExecuteScalar();
            MinDate = date.Equals(DBNull.Value) ? DateTime.Today : DateTime.Parse(date.ToString());
        }
        SearchBaseVM.AccountChanged += onAccountUpdated;
        DateSearchVM.AccountChanged += onAccountUpdated;
    }

    void onAccountUpdated(Account a) {
        foreach (SummaryEntry entry in DetailReport) {
            if(entry.AccountId == a.Id) {
                entry.AccountNo = a.AccountNo;
                entry.AccountAddress = a.Address;
                entry.AccountName = a.Name;
                entry.OnPropertyChanged(null);
            }
        }
    }

    public void RefreshReports() {
        if (EndDate < StartDate) {
            var errors = new List<ValidationError>() {
                new ValidationError(){ Head = "from", Error = "cannot be greater than to"},
                new ValidationError(){ Head = "to", Error = "cannot be less than from"}
            };
            var dialog = new BillErrorDialog(PeriodicView.Left, PeriodicView.Top, PeriodicView.Width, PeriodicView.Height, errors);
            dialog.ShowDialog();
            return;
        }
        fetchData();
        makeDatewiseSummary();
        subSummary = summary;
        SelectedPaymentDate = null;
        OnPropertyChanged(nameof(SelectedPaymentDate));
    }
    void makeDatewiseSummary() {
        DatewiseReport = summary.GroupBy(x => x.Date, (key, value) => new DateEntry() {
            Date = key,
            Bill = value.Sum(x => x.Bill),
            Payment = value.Sum(x => x.Payment)
        }).OrderBy(x => x.Date).ToList();

        if (DatewiseReport.Count > 15) {
            DateSeries = DatewiseReport
                .Skip(DatewiseReport.Count - 15)
                .Select(x => new PinSeries() {
                    Date = x.Date,
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                }).ToList();
        }
        else DateSeries = DatewiseReport
            .Select(x => new PinSeries() {
                Date = x.Date,
                PinAmount = x.Bill,
                LineAmount = x.Payment
            }).ToList();

        OnPropertyChanged(nameof(DatewiseReport));
        OnPropertyChanged(nameof(DateSeries));
    }
    void makeHeadWiseSummary() {
        var grouped = subSummary
            .GroupBy(
            x => new { x.Head, x.DeptName },
            (key, value) => new SummaryEntry() {
                Head = key.Head,
                DeptName = key.DeptName,
                Bill = value.Sum(x => x.Bill),
                Payment = value.Sum(x => x.Payment)
            }).ToList();
        HeadwiseReport = CollectionViewSource.GetDefaultView(grouped);
        HeadwiseReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.Head)));
        HeadwiseReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.DeptName)));
        OnPropertyChanged(nameof(HeadwiseReport));
    }
    void makeDetailSummary() {
        var grouped = subSummary
            .GroupBy(
            x => new { x.DeptName, x.AccountNo, x.Head },
            (key, value) => new SummaryEntry() {
                DeptName = key.DeptName,
                Head = key.Head,
                AccountNo = key.AccountNo,
                AccountId = value.First().AccountId,
                AccountName = value.First().AccountName,
                AccountAddress = value.First().AccountAddress,
                Bill = value.Sum(x => x.Bill),
                Payment = value.Sum(x => x.Payment)
            }).ToList();
        DetailReport = CollectionViewSource.GetDefaultView(grouped);
        DetailReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.DeptName)));
        DetailReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.Head)));

        DeptSeries = new List<KeyValueSeries>();
        foreach (CollectionViewGroup group in DetailReport.Groups) {
            double total = 0;
            foreach (CollectionViewGroup subGroup in group.Items) {
                total += subGroup.Items.Cast<SummaryEntry>().Sum(x => x.Payment);
            }
            DeptSeries.Add(new KeyValueSeries() {
                Name = group.Name.ToString(),
                Total = total
            });
        }

        OnPropertyChanged(nameof(DetailReport));
        OnPropertyChanged(nameof(DeptSeries));
        makeDeptSummary();
    }
    void makeDeptSummary() {
        if (SelectedDept is null) DeptSummary = null;
        else {
            DeptSummary = new List<KeyValueSeries>();
            var inter = subSummary
                .Where(x => x.DeptName.Equals(SelectedDept))
                .GroupBy(x => x.Head)
                .Select(x => new {
                    Head = x.Key,
                    Bill = x.Sum(x => x.Bill),
                    Payment = x.Sum(x => x.Payment)
                }).ToList();
            foreach (var item in inter) {
                if (item.Head.Equals("Amount")) {
                    DeptSummary.Add(new KeyValueSeries() {
                        Name = item.Head,
                        Total = item.Bill
                    });
                }
                else {
                    DeptSummary.Add(new KeyValueSeries() {
                        Name = item.Head,
                        Total = item.Bill + item.Payment
                    });
                }
            }
        }

        OnPropertyChanged(nameof(DeptSummary));
    }
    void fetchData() {
        summary.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = @$"WITH T1 AS(
											SELECT Id FROM Bills 
											WHERE PaymentDate BETWEEN 
											'{StartDate.ToString("yyyy-MM-dd")}' AND '{EndDate.ToString("yyyy-MM-dd")}'
										),
										T2(Date, DeptId, AccountId, Head, Bill, Payment, UID) AS(
											SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, be.Amount, null, bi.Id
											FROM BillEntries be
											LEFT JOIN Bills bi ON bi.Id = be.BillId
											LEFT JOIN Heads h ON h.Id = be.HeadId
											WHERE be.BillId IN (SELECT * FROM T1)
										),
										T3(Date, DeptId, AccountId, Head, Bill, Payment, UID) AS(
											SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, null, pe.Amount, bi.Id
											FROM PaymentEntries pe
											LEFT JOIN Bills bi ON bi.Id = pe.BillId
											LEFT JOIN Heads h ON h.Id = pe.HeadId
											WHERE pe.BillId IN (SELECT * FROM T1)
										),
										T4 (Date, DeptId, AccountId, Head, Bill, Payment) AS (
											SELECT t2.Date, t2.DeptId, t2.AccountId, t2.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0)
											FROM T2 t2 
											LEFT JOIN T3 t3 USING(AccountId, Head, UID)	
										    UNION  ALL
											SELECT t3.Date, t3.DeptId, t3.AccountId, t3.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0) 
											FROM T3 t3 
											LEFT JOIN T2 t2 USING(AccountId, Head, UID)	
										    WHERE t2.Head IS NULL
										)
										SELECT d.Name, a.AccountNo, a.Name, a.Address, t.Head, t.Bill, t.Payment, t.Date, t.AccountId FROM T4 t
										LEFT JOIN Department d ON d.Id = t.DeptId
										LEFT JOIN Account a ON a.Id = t.AccountId";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                summary.Add(new SummaryEntry() {
                    DeptName = reader.GetString(0),
                    AccountNo = reader.GetString(1),
                    AccountName = reader.GetString(2),
                    AccountAddress = reader.GetString(3),
                    Head = reader.GetString(4),
                    Bill = reader.GetDouble(5),
                    Payment = reader.GetDouble(6),
                    Date = reader.GetDateTime(7),
                    AccountId = reader.GetInt32(8)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
    }
}
