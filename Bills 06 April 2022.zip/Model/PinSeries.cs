﻿class PinSeries
{
    public DateTime Date { get; set; }
    public double PinAmount { get; set; }
    public double LineAmount { get; set; }
}
