﻿class ProcessView : View
{
    override public string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    Grid grid;
    public ProcessView() {
        var load = new LoadView();
        var image = new ImageView();
        var extracted = new ExtractedView();
        var finalize = new FinalizeView();

        Grid.SetRowSpan(load, 2);
        Grid.SetColumn(image, 1);
        Grid.SetRowSpan(image, 2);
        Grid.SetColumn(extracted, 2);
        Grid.SetColumn(finalize, 2);
        Grid.SetRow(finalize, 1);
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star) },
                new ColumnDefinition(),
            },
            Children = { load, image, extracted, finalize }
        };
        AddVisualChild(grid);
    }
}
