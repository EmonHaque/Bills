﻿class EntryTemplate : DataTemplate
{
    public EntryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var period = new FrameworkElementFactory(typeof(TextBlock));
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.DateColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        period.SetValue(Grid.ColumnProperty, 1);
        bill.SetValue(Grid.ColumnProperty, 2);
        payment.SetValue(Grid.ColumnProperty, 3);
        period.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        bill.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        bill.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.PaymentDate)) { StringFormat = "yyyy-MM-dd"});
        period.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Period)));
        bill.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Bill)) { StringFormat = "N2"});
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(ReportEntry.Payment)) { StringFormat = "N2" });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(date);
        grid.AppendChild(period);
        grid.AppendChild(bill);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}