﻿class DateEntryTemplate : Grid
{
    TextBlock head, bill, payment;
    public DateEntryTemplate() {
        head = new TextBlock();
        bill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        payment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(bill, 1);
        Grid.SetColumn(payment, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) });

        Children.Add(head);
        Children.Add(bill);
        Children.Add(payment);
    }
    public override void EndInit() {
        base.EndInit();
        var breakup = (DateEntry)DataContext;
        head.Text = breakup.Date.ToString("yyyy-MM-dd");
        bill.Text = breakup.Bill.ToString(Constants.NumberFormat);
        payment.Text = breakup.Payment.ToString(Constants.NumberFormat);
    }
}