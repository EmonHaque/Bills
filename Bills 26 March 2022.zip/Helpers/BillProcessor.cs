﻿class BillProcessor
{
    const string NagadAccNo = "Nagad Acc. No";
    const string TransactionId = "Transaction ID";
    const string BillNumber = "Bill Number";
    const string BillNo = "Bill No";
    const string CustomerCode = "Customer Code";
    const string AccountNo = "Account No";
    const string PhoneNo = "Phone Number";
    const string InvoiceArea = "Invoice ID/Area Code";
    const string Time = "Time";
    const string Amount = "Amount";
    const string Fee = "Fee";
    const string VAT = "VAT";
    const string FixedCharge = "Fixed Charge";
    const string SurCharge = "Sur Charge";
    const string Surcharge = "Surcharge";
    const string SewerBill = "Sewer Bill";
    const string WaterBill = "Water Bill";
    const string MonthYear = "MonthYear (MMYY/MMYYYY)";
    const string Month = "Month";
    const string Year = "Year";
    const string Titas = "titas";
    bool inPaymentInfo;
    string[] months = CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedMonthNames;
    public const string WASA = "WASA";
    public const string DESCO = "DESCO";
    public const string TGCL = "TGCL";
    public const string BTCL = "BTCL";

    public RawInfo ProcessBill(string file) {
        var newInfo = new RawInfo();

        var lines = getLines(file);
        bool gotToThePoint = false;
        string cleaned = "";
        newInfo = new RawInfo() {
            FileName = file.Substring(file.LastIndexOf("\\") + 1),
            FilePath = file
        };
        inPaymentInfo = false;
        foreach (var line in lines) {
            if (!gotToThePoint) {
                if (line.Contains("bill information", StringComparison.InvariantCultureIgnoreCase)) {
                    gotToThePoint = true;
                }
                continue;
            }
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith("Status")) continue;
            if (line.Contains("payment information", StringComparison.InvariantCultureIgnoreCase)) {
                inPaymentInfo = true;
                cleaned += "---------------------------\n";
                continue;
            }
            if (line.Contains("generated electronically", StringComparison.InvariantCultureIgnoreCase)) break;
            cleaned += line + "\n";
            processLine(line, newInfo);
        }
        if (!gotToThePoint) {
            foreach (var line in lines) {
                if (string.IsNullOrWhiteSpace(line)) continue;
                cleaned += line + "\n";
                processLine(line, newInfo);
            }
        }

        newInfo.FileName = file.Substring(file.LastIndexOf("\\") + 1);
        newInfo.FilePath = file;
        newInfo.RawText = cleaned;
        newInfo.TotalPayment = newInfo.PaymentInfo.Sum(x => x.Amount);
        newInfo.TotalBill = newInfo.BillInfo.Sum(x => x.Amount);
        return newInfo;
    }
    public List<ValidationError> ValidationErrors(RawInfo info) {
        List<ValidationError> e = new();
        if (string.IsNullOrWhiteSpace(info.Department)) {
            e.Add(new ValidationError() { Head = nameof(info.Department), Error = "cannot be empty" });
        }
        else {
            if (info.Department.Equals(WASA) || info.Department.Equals(DESCO)) {
                if (string.IsNullOrWhiteSpace(info.BillNo)) {
                    e.Add(new ValidationError() { Head = nameof(info.BillInfo), Error = "cannot be empty" });
                }
            }
        }
        if (string.IsNullOrWhiteSpace(info.TransactionNo)) {
            e.Add(new ValidationError() { Head = nameof(info.TransactionNo), Error = "cannot be empty" });
        }
        if (string.IsNullOrWhiteSpace(info.PaymentDate)) {
            e.Add(new ValidationError() { Head = nameof(info.PaymentDate), Error = "cannot be empty" });
        }
        else {
            if (!DateTime.TryParseExact(info.PaymentDate, "yyyy-MM-dd", new CultureInfo("en-US"), DateTimeStyles.None, out _)) {
                e.Add(new ValidationError() { Head = nameof(info.PaymentDate), Error = "YYYY-MM-DD format expected" });
            }
        }
        if (string.IsNullOrWhiteSpace(info.CustomerNo)) {
            e.Add(new ValidationError() { Head = nameof(info.CustomerNo), Error = "cannot be empty" });
        }
        if (string.IsNullOrWhiteSpace(info.Period)) {
            e.Add(new ValidationError() { Head = nameof(info.Period), Error = "cannot be empty" });
        }
        if (info.BillInfo.Count == 0) {
            e.Add(new ValidationError() { Head = nameof(info.BillInfo), Error = "cannot be empty" });
        }
        else {
            if (info.TotalBill <= 0) {
                e.Add(new ValidationError() { Head = nameof(info.TotalBill), Error = "cannot be negative" });
            }
            else if (info.TotalBill > info.TotalPayment) {
                e.Add(new ValidationError() { Head = nameof(info.TotalBill), Error = "cannot exceed payment" });
            }
        }
        if (info.PaymentInfo.Count == 0) {
            e.Add(new ValidationError() { Head = nameof(info.PaymentInfo), Error = "cannot be empty" });
        }
        else {
            if (info.TotalPayment <= 0) {
                e.Add(new ValidationError() { Head = nameof(info.TotalPayment), Error = "cannot be negative" });
            }
            else if (info.TotalBill > info.TotalPayment) {
                e.Add(new ValidationError() { Head = nameof(info.TotalPayment), Error = "cannot be less than Bill" });
            }
        }
        for (int i = 0; i < info.BillInfo.Count; i++) {
            if (string.IsNullOrWhiteSpace(info.BillInfo[i].Head)) {
                e.Add(new ValidationError() { Head = $"BillInfo {i + 1} head", Error = "cannot be empty" });
            }
            if (info.BillInfo[i].Amount <= 0) {
                e.Add(new ValidationError() { Head = $"BillInfo {i + 1} amount", Error = "should be greater than 0" });
            }
        }
        for (int i = 0; i < info.PaymentInfo.Count; i++) {
            if (string.IsNullOrWhiteSpace(info.PaymentInfo[i].Head)) {
                e.Add(new ValidationError() { Head = $"PaymentInfo {i + 1} head", Error = "cannot be empty" });
            }
            if (info.PaymentInfo[i].Amount <= 0) {
                e.Add(new ValidationError() { Head = $"PaymentInfo {i + 1} amount", Error = "should be greater than 0" });
            }
        }

        return e;
    }
    string[] getLines(string file) {
        //var mat = new OpenCvSharp.Mat(file, OpenCvSharp.ImreadModes.Grayscale);
        //var outMat = new OpenCvSharp.Mat();
        //OpenCvSharp.Cv2.Threshold(mat, outMat, 200, 255, OpenCvSharp.ThresholdTypes.Binary);
        var mat = new OpenCvSharp.Mat(file);
        App.OCR.Run(mat, out var outputText, out _, out _, out _);
        mat.Dispose();
        //outMat.Dispose();
        return outputText.Split("\n", StringSplitOptions.RemoveEmptyEntries);
    }
    void processLine(string line, RawInfo newInfo) {
        if (line.Contains(Titas, StringComparison.InvariantCultureIgnoreCase)) {
            newInfo.Department = TGCL;
        }
        else if (line.Contains(WASA, StringComparison.InvariantCultureIgnoreCase)) {
            newInfo.Department = WASA;
        }
        else if (line.Contains(DESCO, StringComparison.InvariantCultureIgnoreCase)) {
            newInfo.Department = DESCO;
        }
        else if (line.Contains(BTCL, StringComparison.InvariantCultureIgnoreCase)) {
            newInfo.Department = BTCL;
        }
        else if (line.StartsWith(Month)) {
            if (newInfo.Department.Equals(TGCL)) {
                newInfo.Period = line.Replace(MonthYear, "").Trim();
            }
            else if (newInfo.Department.Equals(BTCL)) {
                newInfo.Period = line.Replace(Month, "").Trim();
            }
        }
        else if (line.StartsWith(Year)) {
            newInfo.Period += ", " + line.Replace(Year, "").Trim();
        }
        else if (line.StartsWith(TransactionId)) {
            newInfo.TransactionNo = line.Replace(TransactionId, "").Trim();
        }
        else if (line.StartsWith(NagadAccNo)) {
            newInfo.PaidFrom = line.Replace(NagadAccNo, "").Trim();
        }
        else if (line.StartsWith(BillNumber)) {
            newInfo.BillNo = line.Replace(BillNumber, "").Trim();
        }
        else if (line.StartsWith(BillNo)) {
            newInfo.BillNo = line.Replace(BillNo, "").Trim();
        }
        else if (line.StartsWith(CustomerCode)) {
            newInfo.CustomerNo = line.Replace(CustomerCode, "").Trim();
        }
        else if (line.StartsWith(AccountNo)) {
            newInfo.CustomerNo = line.Replace(AccountNo, "").Trim();
        }
        else if (line.StartsWith(PhoneNo)) {
            newInfo.CustomerNo = line.Replace(PhoneNo, "").Trim();
        }
        else if (line.StartsWith(InvoiceArea)) {
            newInfo.CustomerNo = line.Replace(InvoiceArea, "").Trim();
        }
        else if (line.StartsWith(Time)) {
            var str = line.Replace(Time, "").Trim();
            if (!string.IsNullOrWhiteSpace(str)) {
                str = str.Substring(0, str.IndexOf(','));
                var parts = str.Split(' ');
                int monthIndex = Array.IndexOf(months, parts[1]) + 1;

                var day = parts[0];
                var month = monthIndex.ToString("0#");
                var year = parts[2];
                newInfo.PaymentDate = $"{year}-{month}-{day}";
            }
        }
        else if (line.StartsWith(Amount)) {
            var number = getNumber(line.Replace(Fee, "").Trim());
            if (number > 0) {
                var amountInfo = new AmountInfo() {
                    Head = Amount,
                    Amount = getNumber(line.Replace(Amount, "").Trim())
                };
                if (inPaymentInfo) newInfo.PaymentInfo.Add(amountInfo);
                else newInfo.BillInfo.Add(amountInfo);
            }
        }
        else if (line.StartsWith(Fee)) {
            var number = getNumber(line.Replace(Fee, "").Trim());
            if (number > 0) {
                newInfo.PaymentInfo.Add(new AmountInfo() {
                    Head = Fee,
                    Amount = number
                });
            }
        }
        else if (line.StartsWith(VAT)) {
            var number = getNumber(line.Replace(VAT, "").Trim());
            if (number > 0) {
                var amountInfo = new AmountInfo() {
                    Head = VAT,
                    Amount = number
                };
                if (inPaymentInfo) newInfo.PaymentInfo.Add(amountInfo);
                else newInfo.BillInfo.Add(amountInfo);
            }
        }
        else if (line.StartsWith(WaterBill)) {
            var number = getNumber(line.Replace(WaterBill, "").Trim());
            if (number > 0) {
                newInfo.BillInfo.Add(new AmountInfo() {
                    Head = Amount,
                    Amount = number
                });
            }
        }
        else if (line.StartsWith(FixedCharge)) {
            var number = getNumber(line.Replace(FixedCharge, "").Trim());
            if (number > 0) {
                newInfo.BillInfo.Add(new AmountInfo() {
                    Head = FixedCharge,
                    Amount = number
                });
            }
        }
        else if (line.StartsWith(SurCharge)) {
            var number = getNumber(line.Replace(SurCharge, "").Trim());
            if (number > 0) {
                newInfo.BillInfo.Add(new AmountInfo() {
                    Head = Surcharge,
                    Amount = number
                });
            }
        }
        else if (line.StartsWith(SewerBill)) {
            var number = getNumber(line.Replace(SewerBill, "").Trim());
            if (number > 0) {
                newInfo.BillInfo.Add(new AmountInfo() {
                    Head = SewerBill,
                    Amount = number
                });
            }
        }
    }
    double getNumber(string line) {
        if (string.IsNullOrWhiteSpace(line)) return 0;
        var characters = line.Where(x => char.IsDigit(x) || x == '.').ToArray();
        if (characters.Length == 0) return 0;
        if (characters.Length == 1 && characters[0] == '.') return 0;
        int count = 0;
        for (int i = (characters.Length - 1); i > 0; i--) {
            if (char.IsDigit(characters[i])) break;
            count++;
        }
        count = characters.Length - count;
        string numStr = "";
        int dotCount = 0;
        for (int i = 0; i < count; i++) {
            if (characters[i] == '.') {
                dotCount++;
                if (dotCount > 1) numStr = numStr.Replace(".", "");
                numStr += characters[i];
            }
            else numStr += characters[i];
        }
        return double.Parse(numStr);
    }
}