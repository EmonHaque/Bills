﻿class ValidationError
{
    public string Head { get; set; }
    public string Error { get; set; }
}