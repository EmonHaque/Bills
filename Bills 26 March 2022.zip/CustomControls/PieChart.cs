﻿public class PieChart : FrameworkElement
{
    VisualCollection children;
    TextBlock nameBlock, infoBlock;
    StackPanel infoPanel;
    Run value, percentage;
    Path ellipse;
    DoubleAnimation ellipseAnim, infoAnim;
    ScaleTransform infoScale, ellipseScale;
    double total;
    bool isSliceOpen;
    List<double> values;
    List<KeyValueSeries> series;
    public string SelectedValuePath { get; set; }
    public bool IsSelectable { get; set; }
    public PieChart() {
        children = new VisualCollection(this);
        Margin = new Thickness(10, 10, 10, 0);
        value = new Run() { FontWeight = FontWeights.Bold, Foreground = Brushes.Gray };
        percentage = new Run() { Foreground = Brushes.LightGray };
        infoScale = new ScaleTransform(0, 0);
        nameBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontWeight = FontWeights.Bold,
            TextWrapping = TextWrapping.Wrap
        };
        infoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            Inlines = { value, new LineBreak(), percentage }
        };

        infoPanel = new StackPanel() {
            VerticalAlignment = VerticalAlignment.Center,
            RenderTransform = infoScale,
            Children = { nameBlock, infoBlock }
        };
        ellipseScale = new ScaleTransform(0, 0);
        ellipse = new Path() {
            Fill = Constants.Background,
            Data = new EllipseGeometry(),
            RenderTransform = ellipseScale
        };
        ellipseAnim = new DoubleAnimation() {
            BeginTime = TimeSpan.FromSeconds(0.5),
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        infoAnim = new DoubleAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
    }

    void updateInfo(KeyValueSeries s) {
        infoPanel.Visibility = Visibility.Visible;
        value.Text = s.Total.ToString("N2");
        percentage.Text = (s.Total / total * 100).ToString("N2") + "%";
    }
    protected override Size ArrangeOverride(Size finalSize) {
        Point center = new();
        var availableHeight = finalSize.Height;
        center = new Point(finalSize.Width / 2, availableHeight / 2);
        double radius, startAngle, sweepAngle, endAngle;
        startAngle = sweepAngle = endAngle = 0d;
        radius = center.X > center.Y ? center.Y : center.X;
        int index = 0;
        foreach (PieSlice item in children.OfType<PieSlice>()) {
            var value = values[index];
            startAngle += sweepAngle;
            sweepAngle = 2 * Math.PI * value / total;
            endAngle = startAngle + sweepAngle;
            bool isLarge = (double)value / total > 0.5;
            item.SetParameters(center, radius, startAngle, sweepAngle, isLarge);
            item.Arrange(new Rect(item.DesiredSize));
            index++;
        }
        var geo = (EllipseGeometry)ellipse.Data;
        geo.RadiusX = geo.RadiusY = radius - 0.3 * radius;
        geo.Center = center;
        ellipse.Measure(finalSize);
        ellipse.Arrange(new Rect(ellipse.DesiredSize));
        ellipseScale.CenterX = center.X;
        ellipseScale.CenterY = center.Y;

        infoPanel.Width = geo.RadiusX;
        infoPanel.Measure(finalSize);
        infoScale.CenterX = infoPanel.DesiredSize.Width / 2;
        infoScale.CenterY = infoPanel.DesiredSize.Height / 2;
        infoPanel.Arrange(new Rect(new Point(center.X - infoScale.CenterX, center.Y - infoScale.CenterY), infoPanel.DesiredSize));
        return finalSize;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        var point = e.GetPosition(this);
        var result = VisualTreeHelper.HitTest(this, point);
        if (result != null) {
            if (result.VisualHit is PieSlice) {
                var slice = (PieSlice)result.VisualHit;
                var summary = (KeyValueSeries)slice.value;
                double val = Convert.ToDouble(summary.Total);
                nameBlock.Text = summary.Name;
                value.Text = val.ToString("N2");
                percentage.Text = (val / total * 100).ToString("N2") + "%";
                animate(1);
            }
        }
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (!isSliceOpen)
            animate(0);
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (!IsSelectable) return;
        if (e.OriginalSource is not PieSlice) {
            foreach (var piece in children.OfType<PieSlice>()) {
                if (piece.IsSelected) piece.IsSelected = false;
            }
            isSliceOpen = false;
            SelectedValue = null;
            return;
        }
        foreach (var piece in children.OfType<PieSlice>()) {
            if (piece.IsSelected) piece.IsSelected = false;
        }
        var slice = ((PieSlice)e.OriginalSource);
        slice.IsSelected = true;
        isSliceOpen = true;
        SelectedValue = (string)slice.value.GetType().GetProperty(SelectedValuePath).GetValue(slice.value);

    }
    protected override Visual GetVisualChild(int index) => children[index];
    protected override int VisualChildrenCount => children.Count;
    void animate(double scale) {
        if (scale == 1) infoAnim.BeginTime = TimeSpan.FromSeconds(1);
        else infoAnim.BeginTime = TimeSpan.FromSeconds(0.5);
        ellipseAnim.To = infoAnim.To = scale;
        ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, ellipseAnim);
        ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, ellipseAnim);
        infoScale.BeginAnimation(ScaleTransform.ScaleXProperty, infoAnim);
        infoScale.BeginAnimation(ScaleTransform.ScaleYProperty, infoAnim);
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public string SelectedValue {
        get { return (string)GetValue(SelectedValueProperty); }
        set { SetValue(SelectedValueProperty, value); }
    }
    public static readonly DependencyProperty SelectedValueProperty =
        DependencyProperty.Register("SelectedValue", typeof(string), typeof(PieChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(PieChart), new PropertyMetadata(null, onSourceChanged));

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as PieChart;
        if (e.OldValue is not null) o.children.Clear();
        if (e.NewValue is null) return;

        o.series = ((IEnumerable<KeyValueSeries>)e.NewValue).ToList();
        Random rand = new();
        o.values = new List<double>();
        o.total = 0;
        bool hasMatch = false;
        KeyValueSeries selected = null;
        foreach (KeyValueSeries item in o.series) {
            if (item.Total > 0) {
                o.total += item.Total;
                o.values.Add(item.Total);
                var color = Color.FromRgb((byte)rand.Next(127, 256), (byte)rand.Next(127, 256), (byte)rand.Next(127, 256));
                var slice = new PieSlice(new SolidColorBrush(color), item);
                o.children.Add(slice);
                if (item.Name.Equals(o.SelectedValue)) {
                    slice.IsSelected = true;
                    hasMatch = true;
                    selected = item;
                }
            }
        }
        o.children.Add(o.ellipse);
        o.children.Add(o.infoPanel);
       
        o.InvalidateArrange();
        if (hasMatch) {
            o.updateInfo(selected);
            o.animate(1);
        }
        else o.animate(0);
    }
}
