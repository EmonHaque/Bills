﻿class DescoVM : AccountSearchBaseVM
{
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.DESCO)).Id;
}
