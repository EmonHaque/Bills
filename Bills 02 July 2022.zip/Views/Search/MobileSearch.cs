﻿class MobileSearch : CardView
{
    public override string Header => "Mobile";
    public override string Icon => Icons.Phone;

    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }

    DependencyPropertyDescriptor descriptor;
    SelectItem select;
    DayPicker from, to;
    ListBox entries;
    Grid left, right;
    TextBlock totalAmount;
    Run totalEntries;
    Image image;
    Border middle;
    ActionButton refreshAccount, refreshAccountSummary;
    ExpanderState toggleExpansion;
    SummaryAccountwise accountSummary;
    MobileSearchVM vm;
    
    public MobileSearch() {
        vm = new MobileSearchVM();
        DataContext = vm;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    
    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
        descriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        descriptor.AddValueChanged(toggleExpansion, onIsExpandedChanged);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
        descriptor.RemoveValueChanged(toggleExpansion, onIsExpandedChanged);
    }
    void onIsExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(entries);
        if (toggleExpansion.IsTrue) foreach (GroupItem item in items) item.Tag = true;
        else foreach (GroupItem item in items) item.Tag = false;
    }
    void initializeUI() {
        initializeLeftGrid();
        initializeMiddleBorder();
        initializeRightGrid();
        Grid.SetColumn(middle, 1);
        Grid.SetColumn(right, 2);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(1.16, GridUnitType.Star)},
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = { left, middle, right }
        };
        setContent(grid);
    }
    void initializeLeftGrid() {
        select = new SelectItem() {
            Margin = new Thickness(5, 10, 0, 5),
            Icon = Icons.Tenant,
            Hint = "Account",
            ItemTemplate = new MobileTemplate(),
            SelectedValuePath = nameof(Mobile.Id)
        };
        from = new DayPicker() {
            IsRequired = true,
            Hint = "from",
            DateFormat = "dd/MM/yyyy"
        };
        to = new DayPicker() {
            IsRequired = true,
            Hint = "to",
            DateFormat = "dd/MM/yyyy"
        };
        refreshAccount = new ActionButton() {
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 5, 0, 0),
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = () => {
                vm.RefreshAccount.Invoke();
                toggleExpansion.IsTrue = false;
            }
        };
        toggleExpansion = new ExpanderState() { Margin = new Thickness(5, 5, 0, 0) };

        Grid.SetColumnSpan(select, 2);
        Grid.SetColumn(toggleExpansion, 2);
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refreshAccount, 2);
        Grid.SetRow(from, 1);
        Grid.SetRow(to, 1);
        Grid.SetRow(refreshAccount, 1);
        var topGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            Children = { select, toggleExpansion, from, to, refreshAccount }
        };

        #region header
        var particulars = new TextBlock() { Text = "Particulars" };
        var amount = new TextBlock() { Text = "Amount" };
        Grid.SetColumn(amount, 1);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { particulars, amount }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion

        entries = new ListBox() {
            ItemTemplate = new MobileEntryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)){
                            Setters = { new Setter(GroupItem.TemplateProperty, new MobileEntryGroupTemplate())}
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };

        #region footer
        totalEntries = new Run();
        var entryBlock = new TextBlock() { Inlines = { "Total of ", totalEntries } };
        totalAmount = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { entryBlock, totalAmount }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion

        Grid.SetRow(header, 1);
        Grid.SetRow(entries, 2);
        Grid.SetRow(footer, 3);
        left = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { topGrid, header, entries, footer }
        };
    }
    void initializeMiddleBorder() {
        var blackWhite = new ActionButton() {
            Icon = Icons.ImageBW,
            ToolTip = "Black & White",
            Command = vm.MakeBlackWhite
        };
        var gray = new ActionButton() {
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.ImageGray,
            ToolTip = "GrayScale",
            Command = vm.MakeGray
        };
        var normal = new ActionButton() {
            Icon = Icons.ImageColor,
            ToolTip = "Camera",
            Command = vm.MakeNormal
        };
        var stack = new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 0, 5),
            Children = { blackWhite, gray, normal }
        };
        image = new Image();
        var scroll = new ScrollViewerEx() { Content = image };
        Grid.SetRow(scroll, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { stack, scroll }
        };
        middle = new Border() {
            Margin = new Thickness(5, 0, 10, 0),
            Padding = new Thickness(5, 0, 5, 0),
            BorderThickness = new Thickness(1, 0, 1, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }
    void initializeRightGrid() {
        refreshAccountSummary = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = vm.RefreshAccountSummary
        };
        accountSummary = new SummaryAccountwise();
        Grid.SetRow(accountSummary, 1);
        right = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition()
            },
            Children = { refreshAccountSummary, accountSummary }
        };
    }
    void bind() {
        select.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(vm.AccountId)));
        select.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(vm.SelectionView)));
        select.SetBinding(SelectItem.QueryProperty, new Binding(nameof(vm.QueryAccount)) { Mode = BindingMode.OneWayToSource });

        from.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        from.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.To)}"));
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.From)}"));

        to.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        to.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.End)}"));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.To)}"));

        refreshAccount.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(vm.IsRefreshValid)));
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        entries.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)));
        totalEntries.SetBinding(Run.TextProperty, new Binding(nameof(vm.TotalItem)) { StringFormat = "N0" });
        totalAmount.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalAmount)) { StringFormat = Constants.NumberFormat });

        image.SetBinding(Image.SourceProperty, new Binding(nameof(vm.Bitmap)));
        accountSummary.SetBinding(SummaryAccountwise.ItemsSourceProperty, new Binding(nameof(vm.Summary)));
        accountSummary.SetBinding(SummaryAccountwise.TotalProperty, new Binding(nameof(vm.TotalSummary)) { Mode = BindingMode.TwoWay });
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = left.TransformToAncestor(this).Transform(new Point(0, 0));
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Top = position.Y;
        Left = position.X;
        Width = left.ActualWidth;
        Height = left.ActualHeight;
    }
}
