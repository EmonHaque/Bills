﻿class SummaryDeptwise : Grid
{
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(SummaryDeptwise), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourcheChanged
        });

    static void onSourcheChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (SummaryDeptwise)d;
        o.Visibility = Visibility.Collapsed;
        if (e.NewValue is null) return;
        
        var source = (List<KeyValueSeries>)e.NewValue;
        if(source.Count == 0) return;
        
        double amount = 0;
        foreach (var item in source) {
            amount += item.Total;
        }
        o.total.Text = amount.ToString("N2");
        o.Visibility = Visibility.Visible;
    }

    TextBlock totalText, total;
    ListBox box;

    public SummaryDeptwise() {
        Visibility = Visibility.Collapsed;
        VerticalAlignment = VerticalAlignment.Bottom;
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        initializeHeader();
        box = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new DeptSummaryTemplate(),
            Resources = {{
                        typeof(ScrollViewer),
                        new Style() {
                            Setters = {
                                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                            }
                        }
                    }
                }
        };
        SetRow(box, 1);
        Children.Add(box);
        initializeFooter();
        box.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
    }
    void initializeHeader() {
        TextBlock headBlock, totalBlock;
        headBlock = new TextBlock() { Text = "Head" };
        totalBlock = new TextBlock() { Text = "Total", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBlock, 1);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { headBlock, totalBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        Children.Add(header);
    }
    void initializeFooter() {
        totalText = new TextBlock() { Text = "Total" };
        total = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(total, 1);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalText, total }
        };
        var footer = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        SetRow(footer, 2);
        Children.Add(footer);
    }
}
