﻿class PinSeries
{
    public string Date { get; set; }
    public double PinAmount { get; set; }
    public double LineAmount { get; set; }
}
