﻿class SummaryAccount
{
    public string Department { get; set; }
    public string Account { get; set; }
    public string NameAndAddress { get; set; }
    public double Amount { get; set; }
}
