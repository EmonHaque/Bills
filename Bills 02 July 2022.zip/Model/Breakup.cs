﻿class Breakup
{
    public string Head { get; set; }
    public double Bill { get; set; }
    public double Payment { get; set; }
    public int BillId { get; set; }
    public int PaymentId { get; set; }
}
