﻿class AccountSummaryGroupTemplate : ControlTemplate
{
    public AccountSummaryGroupTemplate() {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var row3 = new FrameworkElementFactory(typeof(RowDefinition));
        var header = new FrameworkElementFactory(typeof(TextBlock)) { Name = "header" };
        var items = new FrameworkElementFactory(typeof(ItemsPresenter)) { Name = "presenter" };
        var footer = new FrameworkElementFactory(typeof(Border)) { Name = "footer" };
        var total = new FrameworkElementFactory(typeof(TextBlock));

        grid.SetValue(Grid.MarginProperty, new Thickness(5, 0, 0, 0));
        header.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(10, 0, 0, 0));
        footer.SetValue(Grid.RowProperty, 2);
        footer.SetValue(Border.BorderThicknessProperty, new Thickness(0, 1, 0, 0));
        footer.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        footer.SetValue(Border.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        footer.SetValue(Border.WidthProperty, Constants.AmountColumnWidth);
        total.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        header.SetBinding(TextBlock.TextProperty, new Binding(nameof(GroupItem.Name)) { Mode = BindingMode.OneWay });
        total.SetBinding(TextBlock.TextProperty, new Binding() { 
            Converter = Converters.ASC,
            StringFormat = Constants.NumberFormat
        });

        footer.AppendChild(total);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(row3);
        grid.AppendChild(header);
        grid.AppendChild(items);
        grid.AppendChild(footer);
        VisualTree = grid;

        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                    new Condition(new Binding(nameof(CollectionViewGroup.IsBottomLevel)), true),
                    new Condition(new Binding(nameof(CollectionViewGroup.ItemCount)), 1),
                },
            Setters = {
                    new Setter(TextBlock.VisibilityProperty, Visibility.Collapsed, "header"),
                    new Setter(ItemsPresenter.MarginProperty, new Thickness(-5,0,0,0), "presenter"),
                    new Setter(ContentControl.VisibilityProperty, Visibility.Collapsed, "footer")
                }
        });
    }
}
