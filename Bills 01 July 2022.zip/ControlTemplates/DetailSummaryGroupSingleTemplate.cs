﻿class DetailSummaryGroupSingleTemplate : ControlTemplate
{
    public DetailSummaryGroupSingleTemplate() {
        TargetType = typeof(GroupItem);
        var content = new FrameworkElementFactory(typeof(ContentControl));
        content.SetValue(ContentControl.ContentTemplateProperty, new DetailEntryTemplateAccount());
        content.SetValue(ContentControl.MarginProperty, new Thickness(5, 0, 0, 0));
        content.SetBinding(ContentControl.ContentProperty, new Binding(nameof(CollectionViewGroup.Items)) {
            Converter = Converters.DRSIC
        });
        VisualTree = content;
    }
}
