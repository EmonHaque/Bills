﻿class MobileEntryGroupTemplate : ControlTemplate
{
    public MobileEntryGroupTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander)) { Name = "exp" };
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new MobileExpanderHeaderTemplate());
        expander.SetBinding(Expander.IsExpandedProperty, new Binding(nameof(Expander.Tag)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(GroupItem), 1),
            TargetNullValue = false,
            //FallbackValue = false
        });
        expander.AppendChild(items);
        VisualTree = expander;
    }
}
