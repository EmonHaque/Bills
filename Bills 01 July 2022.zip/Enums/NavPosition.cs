﻿enum NavPosition
{
    Right,
    Bottom
}
