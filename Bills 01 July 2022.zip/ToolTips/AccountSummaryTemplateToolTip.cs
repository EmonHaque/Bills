﻿class AccountSummaryTemplateToolTip : ToolTip
{
    public AccountSummaryTemplateToolTip() {
        BorderBrush = null;
        Effect = null;
        HasDropShadow = false;
        var text = new TextBlock() { TextAlignment = TextAlignment.Center };
        text.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryAccount.NameAndAddress)));
        Content = new Border() {
            Padding = new Thickness(5),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(5),
            BorderBrush = Brushes.LightGray,
            Child = text
        };
    }
}
