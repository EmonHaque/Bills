﻿class DetailSummaryEntryTemplateToolTip : ToolTip
{
    public DetailSummaryEntryTemplateToolTip() {
        BorderBrush = null;
        Effect = null;
        HasDropShadow = false;
        var name = new Run();
        var address = new Run();
        var text = new TextBlock() { 
            Inlines = { name, new Run("\n"), address },
            TextAlignment = TextAlignment.Center
        };
        name.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountName)));
        address.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountAddress)));
        Content = new Border() {
            Padding = new Thickness(5),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(5),
            BorderBrush = Brushes.LightGray,
            Child = text
        };
    }
}
