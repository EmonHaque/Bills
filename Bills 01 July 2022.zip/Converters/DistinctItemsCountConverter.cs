﻿class DistinctItemCountConverter : IValueConverter
{
    List<string> getAccounts(CollectionViewGroup group) {
        List<string> accounts = new();
        if (group.IsBottomLevel) {
            accounts.AddRange(group.Items.Cast<SummaryEntry>().Select(x => x.AccountNo));
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                accounts.AddRange(getAccounts(subGroup));
            }
        }
        return accounts;
    }
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        int count = 0;
        if (group.IsBottomLevel) count = group.ItemCount;
        else {
            List<string> accounts = new();
            foreach (CollectionViewGroup subGroup in group.Items) {
                accounts.AddRange(getAccounts(subGroup));
            }
            count = accounts.Distinct().Count();
        }
        return count;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
