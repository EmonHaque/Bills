﻿class DetailReportSingleItemConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var entry = (SummaryEntry)((ReadOnlyObservableCollection<object>)value)[0];
        return new SummaryEntry() {
            AccountName = entry.AccountName,
            AccountAddress = entry.AccountAddress,
            AccountNo = entry.Head + " - " + entry.AccountNo,
            Bill = entry.Bill,
            Payment = entry.Payment
        };
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}