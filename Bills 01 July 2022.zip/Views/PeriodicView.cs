﻿class PeriodicView : CardView
{
    public override string Header => "Summary";
    public override string Icon => Icons.Sigma;

    DependencyPropertyDescriptor descriptor;
    DayPicker startDate, endDate;
    ActionButton refresh;
    MultiState reportState, detailGroupState, expandState;
    Grid reportGrid;
    SummaryDatewise dateReport;
    MultiLineChart dateChart;
    SummaryHeadwise headReport;
    PieChart deptChart;
    SummaryDetail detailReport;
    SummaryDeptwise deptSummary;
    PeriodicVM vm;
    public static double Top { get; set; }
    public static double Left { get; set; }
    public static double Width { get; set; }
    public static double Height { get; set; }

    public PeriodicView() {
        vm = new PeriodicVM();
        DataContext = vm;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
        descriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        descriptor.AddValueChanged(expandState, onExpandStateChanged);
        descriptor.AddValueChanged(detailGroupState, onGroupStateChanged);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
        descriptor.RemoveValueChanged(expandState, onExpandStateChanged);
        descriptor.RemoveValueChanged(detailGroupState, onGroupStateChanged);
    }
    void onExpandStateChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(detailReport.List);

        if (expandState.State == 1) foreach (GroupItem item in items) item.Tag = true;
        else foreach (GroupItem item in items) item.Tag = false;
    }
    void onGroupStateChanged(object? sender, EventArgs e) {
        if (detailGroupState.State == 0) {
            detailReport.List.ItemTemplate = new DetailEntryTemplateAccount();
        }
        else {
            detailReport.List.ItemTemplate = new DetailEntryTemplateHead();
        }
        expandState.State = 0;
    }
    void initializeUI() {
        reportState = new MultiState() {
            Texts = new string[] { "Date", "Month" },
            Icons = new string[] { Icons.CalendarEdit, Icons.Calendar },
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0,0,5,0),
        };
        expandState = new MultiState() {
            IsIconInfront = true,
            Texts = new string[] { "Expand", "Collapse" },
            Icons = new string[] { Icons.Minus, Icons.Plus },
            HorizontalAlignment = HorizontalAlignment.Left,
            Margin = new Thickness(5,0,0,0)
        };
        detailGroupState = new MultiState() {
            IsIconInfront = true,
            Texts = new string[] { "Mobile", "Account" },
            Icons = new string[] { Icons.Phone, Icons.ControlHead },
            HorizontalAlignment = HorizontalAlignment.Left,
            Margin = new Thickness(5, 0, 0, 0)
        };
        var title = new TextBlock() {
            Text = "for the period ",
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
            FontSize = 14
        };
        startDate = new DayPicker() {
            Hint = "from",
            Width = 190,
            StartDate = vm.MinDate,
            EndDate = DateTime.Today,
            DateFormat = "dd/MM/yyyy"
        };
        endDate = new DayPicker() {
            Hint = "to",
            Width = 190,
            StartDate = vm.MinDate,
            EndDate = DateTime.Today,
            DateFormat = "dd/MM/yyyy"
        };
        refresh = new ActionButton() {
            Margin = new Thickness(5, 5, 0, 0),
            ToolTip = "Refresh",
            Icon = Icons.Refresh,
            Command = () => {
                vm.RefreshReport.Invoke();
                expandState.State = 0;
            }
        };
        Grid.SetColumn(detailGroupState, 1);
        Grid.SetColumn(title, 1);
        Grid.SetColumn(startDate, 2);
        Grid.SetColumn(endDate, 3);
        Grid.SetColumn(refresh, 4);
        
        var dateGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto},
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto},
                new ColumnDefinition() { Width = GridLength.Auto},
                new ColumnDefinition() { Width = GridLength.Auto}
            },
            Children = { expandState, detailGroupState, title, startDate, endDate, refresh }
        };
        Grid.SetColumn(dateGrid, 1);
        var topGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(2.5, GridUnitType.Star)}
            },
            Children = { reportState, dateGrid }
        };
        initializeReportGrid();
        Grid.SetRow(reportGrid, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition() {Height = new GridLength(50)},
                new RowDefinition(),
            },
            Children = { topGrid, reportGrid }
        };
        setContent(grid);
    }
    void initializeReportGrid() {
        dateChart = new MultiLineChart() { Margin = new Thickness(0, 0, 0, 10) };
        deptChart = new PieChart() { 
            IsSelectable = true,
            SelectedValuePath = nameof(KeyValueSeries.Name)
        };
        deptSummary = new SummaryDeptwise();
        Grid.SetRow(deptChart, 1);
        Grid.SetRow(deptSummary, 2);
        var charts = new Grid() {
            Margin = new Thickness(10,0,0,0),
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(.7, GridUnitType.Star)}
            },
            Children = { dateChart, deptChart, deptSummary }
        };
        dateReport = new SummaryDatewise();
        detailReport = new SummaryDetail();
        headReport = new SummaryHeadwise();

        Grid.SetColumn(detailReport, 1);
        Grid.SetRowSpan(detailReport, 3);
        Grid.SetRow(headReport, 2);
        Grid.SetColumn(charts, 2);
        Grid.SetRowSpan(charts, 3);
        reportGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = new GridLength(20)},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            Children = {dateReport, headReport, detailReport, charts }
        };
    }
    void bind() {
        reportState.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.ReportState)));
        detailGroupState.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.GroupDetailState)));
        startDate.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.StartDate)));
        endDate.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.EndDate)));
        dateReport.SetBinding(SummaryDatewise.ItemsSourceProperty, new Binding(nameof(vm.DateMonthwiseReport)));
        dateReport.SetBinding(SummaryDatewise.SelectedItemProperty, new Binding(nameof(vm.SelectedDayMonth)));
        dateChart.SetBinding(MultiLineChart.ItemsSourceProperty, new Binding(nameof(vm.DateMonthSeries)));
        headReport.SetBinding(SummaryHeadwise.ItemsSourceProperty, new Binding(nameof(vm.HeadwiseReport)));
        detailReport.SetBinding(SummaryDetail.ItemsSourceProperty, new Binding(nameof(vm.DetailReport)));
        deptChart.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.DeptSeries)));
        deptChart.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(vm.SelectedDept)));
        deptSummary.SetBinding(SummaryDeptwise.ItemsSourceProperty, new Binding(nameof(vm.DeptSummary)));
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var zeros = new Point(0, 0);
        var left = startDate.TransformToAncestor(this).Transform(zeros);   
        var bottom = detailReport.TransformToAncestor(this).Transform(zeros);

        var top = PointToScreen(zeros);
        left = PointToScreen(left);
        bottom = PointToScreen(bottom);

        left.X /= dpi.DpiScaleX;
        top.Y /= dpi.DpiScaleY;
        bottom.Y /= dpi.DpiScaleY;

        Top = top.Y + Constants.CardMargin.Top;
        Left = left.X;
        Width = 418;
        Height = bottom.Y - top.Y + 10;
    }
}
