﻿class MobileView : CardView
{
    public override string Header => "Mobile";

    ListBox list;
    MobileVM vm;
    public MobileView() {
        vm = new MobileVM();
        DataContext = vm;
        list = new ListBox() {
            ItemTemplate = new MobileTemplate()
        };
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Mobiles)));
        setContent(list);
    }
}
