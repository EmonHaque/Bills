﻿class ExtractedView : CardView
{
    public override string Header => "Extract";

    TextBox extractedText;
    DetailVM vm;

    public ExtractedView() {
        vm = new DetailVM();
        DataContext = vm;
        initialize();
        bind();
        extractedText.MouseWheel += zoom;
        Unloaded += onUnloaded;
    }
    void initialize() {
        extractedText = new TextBox() {
            BorderThickness = new Thickness(0),
            BorderBrush = Brushes.LightGray,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        initializeContextMenu();

        setContent(extractedText);
    }
    void initializeContextMenu() {
        var cut = new MenuItem() { Icon = Helper.GetIcon(Icons.Cut), Header = "Cut", Command = ApplicationCommands.Cut };
        var copy = new MenuItem() { Icon = Helper.GetIcon(Icons.Copy), Header = "Copy", Command = ApplicationCommands.Copy };
        var paste = new MenuItem() { Icon = Helper.GetIcon(Icons.Paste), Header = "Paste", Command = ApplicationCommands.Paste };
        extractedText.ContextMenu = new ContextMenu() {
            BorderThickness = new Thickness(1),
            Items = { cut, copy, paste }
        };
    }
    void bind() {

        extractedText.SetBinding(TextBox.TextProperty, new Binding($"{ nameof(vm.Info) }.{ nameof(RawInfo.RawText) }"));
    }
    void zoom(object sender, MouseWheelEventArgs e) {
        if (!Keyboard.IsKeyDown(Key.LeftCtrl)) return;
        if (e.Delta > 0) extractedText.FontSize++;
        else if (extractedText.FontSize > 12)
            extractedText.FontSize--;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        extractedText.MouseWheel -= zoom;
        Unloaded -= onUnloaded;
    }
}
