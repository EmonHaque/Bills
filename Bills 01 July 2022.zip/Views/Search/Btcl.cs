﻿class Btcl : AccountSearchBase
{
    public override string Icon => Icons.Telephone;
    public override string Header => "BTCL";
    BtclVM viewModel = new();
    protected override AccountSearchBaseVM vm => viewModel;
}
