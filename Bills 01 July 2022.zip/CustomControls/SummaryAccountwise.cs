﻿class SummaryAccountwise : Grid
{
    #region DependencyProperties
    public static readonly DependencyProperty ItemsSourceProperty;
    public static readonly DependencyProperty TotalProperty;
    static SummaryAccountwise() {
        ItemsSourceProperty = DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(SummaryAccountwise));
        TotalProperty = DependencyProperty.Register("Total", typeof(double), typeof(SummaryAccountwise));
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    } 
    public double Total {
        get { return (double)GetValue(TotalProperty); }
        set { SetValue(TotalProperty, value); }
    }
    #endregion

    TextBlock totalText, total;
    Border footer;
    DragItemOutListBox box;

    public SummaryAccountwise() {
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        initializeHeader();
        box = new DragItemOutListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new AccountSummaryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new AccountSummaryGroupTemplate())
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };
        SetRow(box, 1);
        Children.Add(box);
        initializeFooter();
        box.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
        total.SetBinding(TextBlock.TextProperty, new Binding(nameof(Total)) { 
            Source = this, 
            StringFormat = Constants.NumberFormat 
        });
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    
    void onLoaded(object sender, RoutedEventArgs e) {
        footer.DragEnter += onFooterDragEmter;
        footer.DragLeave += onFooterDragLeave;
        footer.Drop += onFooterDrop;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        footer.DragEnter -= onFooterDragEmter;
        footer.DragLeave -= onFooterDragLeave;
        footer.Drop -= onFooterDrop;
    }
    void onFooterDrop(object sender, DragEventArgs e) {
        var data = e.Data.GetData(typeof(SummaryAccount)) as SummaryAccount;
        var view = (ICollectionView)ItemsSource;
        var list = (ObservableCollection<SummaryAccount>)view.SourceCollection;
        list.Remove(data);
        Total -= data.Amount;
        footer.Background = null;
    }
    void onFooterDragLeave(object sender, DragEventArgs e) {
        if(footer.Background is not null)
            footer.Background = null;
    }
    void onFooterDragEmter(object sender, DragEventArgs e) {
        var data = e.Data.GetData(typeof(SummaryAccount)) as SummaryAccount;
        if (data is null) return;
        footer.Background = Constants.BackgroundDark;
    }
    void initializeHeader() {
        TextBlock headBlock, totalBlock;
        headBlock = new TextBlock() { Text = "Account" };
        totalBlock = new TextBlock() { Text = "Amount", HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalBlock, 1);
        var headerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { headBlock, totalBlock }
        };
        var header = new Border() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        Children.Add(header);
    }
    void initializeFooter() {
        totalText = new TextBlock() { Text = "Total" };
        total = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(total, 1);
        var footerGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = { totalText, total }
        };
        footer = new Border() {
            AllowDrop = true,
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        SetRow(footer, 2);
        Children.Add(footer);
    }
}