﻿class Helper
{
    public static Path GetIcon(string data) => new Path() {
        Data = Geometry.Parse(data),
        Fill = Brushes.LightGray,
        Width = 12,
        Height = 12,
        Stretch = Stretch.Uniform
    };
    public static DataTemplate GetDataTemplate(Type t) {
        return new DataTemplate() {
            VisualTree = new FrameworkElementFactory(t)
        };
    }
    public static T FindVisualChild<T>(DependencyObject o) where T : DependencyObject {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
            var child = VisualTreeHelper.GetChild(o, i);
            if (child != null && child is T) return (T)child;
            else {
                T grandChild = FindVisualChild<T>(child);
                if (grandChild != null) return grandChild;
            }
        }
        return null;
    }
    public static IEnumerable<T> FindVisualChildren<T>(DependencyObject o) where T : DependencyObject {
        if (o != null) {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
                DependencyObject child = VisualTreeHelper.GetChild(o, i);
                if (child != null && child is T) {
                    yield return (T)child;
                }

                foreach (T childOfChild in FindVisualChildren<T>(child)) {
                    yield return childOfChild;
                }
            }
        }
    }
}

