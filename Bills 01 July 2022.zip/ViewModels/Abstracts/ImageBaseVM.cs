﻿class ImageBaseVM : Notifiable
{
    protected ColorState state;
    protected string imagePath;
    BitmapImage bitmap;
    public BitmapImage Bitmap {
        get { return bitmap; }
        set { bitmap = value; OnPropertyChanged(nameof(Bitmap)); }
    }

    public void MakeBlackWhite() {
        if (imagePath is null) return;
        state = ColorState.BlackWhite;
        Bitmap = ImageProcessor.GetBlackAndWhite(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeGray() {
        if (imagePath is null) return;
        state = ColorState.Gray;
        Bitmap = ImageProcessor.GetGrayScale(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
    public void MakeNormal() {
        if (imagePath is null) return;
        state = ColorState.Color;
        Bitmap = ImageProcessor.GetNormal(imagePath);
        OnPropertyChanged(nameof(Bitmap));
    }
}
