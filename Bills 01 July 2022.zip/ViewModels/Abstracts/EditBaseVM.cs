﻿abstract class EditBaseVM : ImageBaseVM
{
    protected ObservableCollection<ReportEntry> reportables;
    protected bool isDateEqual;

    ReportEntry selectedBill;
    public ReportEntry SelectedBill {
        get { return selectedBill; }
        set {
            selectedBill = value;
            if (value is null) nullify();
            else updateEntryInfo();
            OnPropertyChanged(nameof(SelectedBill));
        }
    }
    bool isAccountOnEdit;
    public bool IsAccountOnEdit {
        get { return isAccountOnEdit; }
        set {
            isAccountOnEdit = value;
            if (value) cloneAccount();
            else updateAccount();
        }
    }
    bool isBillOnEdit;
    public bool IsBillOnEdit {
        get { return isBillOnEdit; }
        set {
            isBillOnEdit = value;
            if (value) cloneBill();
            else updateBill();
        }
    }
    bool areEntriesOnEdit;
    public bool AreEntriesOnEdit {
        get { return areEntriesOnEdit; }
        set {
            areEntriesOnEdit = value;
            if (value) cloneBillEntries();
            else updateBillEntries();
        }
    }

    public int TotalItem { get; set; }
    public double TotalBill { get; set; }
    public double TotalPayment { get; set; }
    public ReportEntry EditedBill { get; set; }
    public Account SelectedAccount { get; set; }
    public Account EditedAccount { get; set; }
    public List<Breakup> Breakups { get; set; }
    public List<Breakup> EditedBreakups { get; set; }
    public List<KeyValueSeries> PieValues { get; set; }
    public ICollectionView Reportables { get; set; }
    protected abstract string Where { get; }
    
    public EditBaseVM() {
        reportables = new ObservableCollection<ReportEntry>();
    }

    protected abstract void onAccountUpdate();
    protected abstract void onBillUpdate();
    protected abstract void onBillEntriesUpdate();
    protected abstract void updateChart();
    
    protected void updatePie() {
        foreach (var breakup in Breakups) {
            PieValues.Add(new KeyValueSeries() {
                Name = breakup.Head,
                Total = breakup.Head.Equals("Amount") ? breakup.Bill : breakup.Payment + breakup.Bill
            });
        }
        OnPropertyChanged(nameof(PieValues));
    }
    protected void nullify() {
        onNullify();
        imagePath = null;
        Bitmap = null;
        Breakups = null;
        PieValues = null;
        OnPropertyChanged(nameof(TotalItem));
        OnPropertyChanged(nameof(TotalBill));
        OnPropertyChanged(nameof(TotalPayment));
        OnPropertyChanged(nameof(Breakups));
        OnPropertyChanged(nameof(PieValues));
    }
    protected void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalItem = 0;
        TotalBill = 0;
        TotalPayment = 0;
        foreach (ReportEntry item in Reportables) {
            TotalItem++;
            TotalBill += item.Bill;
            TotalPayment += item.Payment;
        }
        OnPropertyChanged(nameof(TotalItem));
        OnPropertyChanged(nameof(TotalBill));
        OnPropertyChanged(nameof(TotalPayment));
    }
    protected void updateReportables() {
        if(this is AccountSearchBaseVM) {
            var vm = this as AccountSearchBaseVM;
            if (vm.AccountId is null) return;
        }
        reportables.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = $@"SELECT b.Id, b.DeptId, AccountId, BillNo, Period, TransactionId, m.MobileNo, PaymentDate, FileName,
                                   (SELECT sum(Amount) FROM BillEntries WHERE BillId = b.Id),
                                   (SELECT sum(Amount) FROM PaymentEntries WHERE BillId = b.Id),
                                   a.AccountNo
                                   FROM Bills b
                                   LEFT JOIN Mobile m ON m.Id = b.MobileId
                                   LEFT JOIN Account a ON a.Id = b.AccountId 
                                   WHERE {Where}
                                   ORDER BY PaymentDate";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                reportables.Add(new ReportEntry() {
                    BillId = reader.GetInt32(0),
                    DeptId = reader.GetInt32(1),
                    AccountId = reader.GetInt32(2),
                    BillNo = reader.IsDBNull(3) ? "" : reader.GetString(3),
                    Period = reader.GetString(4),
                    TransactionId = reader.GetString(5),
                    Mobile = reader.GetString(6),
                    PaymentDate = reader.GetDateTime(7),
                    FileName = reader.GetString(8),
                    Bill = reader.GetDouble(9),
                    Payment = reader.GetDouble(10),
                    AccountNo = reader.GetString(11)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        if (reportables.Count > 0) SelectedBill = reportables.Last();
        else nullify();
        updateChart();
    }
    protected virtual void onEntryInfoUpdate() { }
    protected virtual void onNullify() { }
    public void Refresh() => updateReportables();
    void updateAccount() {
        if (EditedAccount.Name.Equals(SelectedAccount.Name) &&
            EditedAccount.Address.Equals(SelectedAccount.Address) &&
            EditedAccount.AccountNo.Equals(SelectedAccount.AccountNo)) return;

        AppData.UpdateAccount(EditedAccount);
        SelectedAccount.AccountNo = EditedAccount.AccountNo;
        SelectedAccount.Name = EditedAccount.Name;
        SelectedAccount.Address = EditedAccount.Address;
        SelectedAccount.OnPropertyChanged(null);

        onAccountUpdate();
    }
    void updateBill() {
        isDateEqual = SelectedBill.PaymentDate.Equals(EditedBill.PaymentDate);
        bool isTransactionEqual = SelectedBill.TransactionId.Equals(EditedBill.TransactionId);
        if (SelectedBill.Period.Equals(EditedBill.Period) &&
            isDateEqual && isTransactionEqual &&
            SelectedBill.BillNo.Equals(EditedBill.BillNo) &&
            SelectedBill.Mobile.Equals(EditedBill.Mobile)) return;

        if (!AppData.HasMobile(EditedBill.Mobile)) {
            var dialog = new MobileCreateDialog(EditedBill.Mobile);
            if (!dialog.ShowDialog().Value) return;
            AppData.GetMobile(EditedBill.Mobile, dialog.GetName());
        }

        if (isDateEqual && isTransactionEqual) AppData.UpdateBill(EditedBill);
        else {
            var date = EditedBill.PaymentDate.ToString("yyyy-MM-dd");
            var dept = AppData.departments.First(x => x.Id == EditedBill.DeptId).Name;
            var newFileName = $"{date}-{dept}-{EditedBill.TransactionId}.png";
            AppData.UpdateBill(EditedBill, newFileName);
            EditedBill.FileName = newFileName;
        }

        SelectedBill.BillNo = EditedBill.BillNo;
        SelectedBill.FileName = EditedBill.FileName;
        SelectedBill.PaymentDate = EditedBill.PaymentDate;
        SelectedBill.Period = EditedBill.Period;
        SelectedBill.TransactionId = EditedBill.TransactionId;
        SelectedBill.Mobile = EditedBill.Mobile;
        SelectedBill.OnPropertyChanged(null);

        onBillUpdate();
    }
    void updateBillEntries() {
        List<UpdatedEntry> entries = new();
        double billAdjustment = 0;
        double paymentAdjustment = 0;
        for (int i = 0; i < Breakups.Count; i++) {
            if (Breakups[i].Bill != EditedBreakups[i].Bill) {
                entries.Add(new UpdatedEntry() {
                    Table = "BillEntries",
                    Id = Breakups[i].BillId,
                    Amount = EditedBreakups[i].Bill
                });
                billAdjustment += (EditedBreakups[i].Bill - Breakups[i].Bill);
            }
            if (Breakups[i].Payment != EditedBreakups[i].Payment) {
                entries.Add(new UpdatedEntry() {
                    Table = "PaymentEntries",
                    Id = Breakups[i].PaymentId,
                    Amount = EditedBreakups[i].Payment
                });
                paymentAdjustment += (EditedBreakups[i].Payment - Breakups[i].Payment);
            }
        }
        if (entries.Count == 0) return;

        AppData.UpdateEntries(entries);
        Breakups = EditedBreakups;
        SelectedBill.Bill += billAdjustment;
        SelectedBill.Payment += paymentAdjustment;
        TotalBill += billAdjustment;
        TotalPayment += paymentAdjustment;

        OnPropertyChanged(nameof(Breakups));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Bill));
        SelectedBill.OnPropertyChanged(nameof(ReportEntry.Payment));
        OnPropertyChanged(nameof(TotalBill));
        OnPropertyChanged(nameof(TotalPayment));

        onBillEntriesUpdate();
    }
    void cloneAccount() {
        EditedAccount = new Account() {
            Id = SelectedAccount.Id,
            DeptId = SelectedAccount.DeptId,
            AccountNo = SelectedAccount.AccountNo,
            Name = SelectedAccount.Name,
            Address = SelectedAccount.Address
        };
        OnPropertyChanged(nameof(EditedAccount));
    }
    void cloneBill() {
        EditedBill = new ReportEntry() {
            BillId = SelectedBill.BillId,
            DeptId = SelectedBill.DeptId,
            BillNo = SelectedBill.BillNo,
            FileName = SelectedBill.FileName,
            PaymentDate = SelectedBill.PaymentDate,
            Period = SelectedBill.Period,
            TransactionId = SelectedBill.TransactionId,
            Mobile = SelectedBill.Mobile
        };
        OnPropertyChanged(nameof(EditedBill));
    }
    void cloneBillEntries() {
        EditedBreakups = new List<Breakup>();
        foreach (var item in Breakups) {
            EditedBreakups.Add(new Breakup() {
                Head = item.Head,
                Bill = item.Bill,
                Payment = item.Payment,
                BillId = item.BillId,
                PaymentId = item.PaymentId
            });
        }
        OnPropertyChanged(nameof(EditedBreakups));
    }
    void updateEntryInfo() {
        onEntryInfoUpdate();
        Breakups = new List<Breakup>();
        PieValues = new List<KeyValueSeries>();
        if (SelectedBill is null) return;

        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH T1(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, Amount , null, Id, null FROM BillEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ), 
                                        T2(Head, Bill, Payment, BillId, PaymentId) AS(
                                             SELECT HeadId, null, Amount, null, Id FROM PaymentEntries
                                             WHERE BillId = {SelectedBill.BillId}
                                        ),
                                        --T3 FULL OUTER JOIN
                                        T3 (Head, Bill, Payment, BillId, PaymentId) AS (
                                            SELECT t1.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T1 t1 LEFT JOIN T2 t2 ON t1.Head = t2.Head	
                                            UNION  ALL
                                            SELECT t2.Head, t1.Bill, t2.Payment, t1.BillId, t2.PaymentId FROM T2 t2 LEFT JOIN T1 t1 ON t2.Head = t1.Head
                                            WHERE t1.Head IS NULL
                                        )
                                        SELECT h.Name, coalesce(Bill, 0), coalesce(Payment, 0), coalesce(BillId, 0), coalesce(PaymentId, 0) 
                                        FROM T3 LEFT JOIN Heads h ON h.Id = Head
                                        ORDER BY h.Id";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Breakups.Add(new Breakup() {
                    Head = reader.GetString(0),
                    Bill = reader.GetDouble(1),
                    Payment = reader.GetDouble(2),
                    BillId = reader.GetInt32(3),
                    PaymentId = reader.GetInt32(4)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
        OnPropertyChanged(nameof(Breakups));
        updatePie();
        imagePath = Constants.ImageFolder + "/" + SelectedBill.FileName;
        if (!System.IO.File.Exists(imagePath)) {
            Bitmap = null;
            return;
        }
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
    }  
}
