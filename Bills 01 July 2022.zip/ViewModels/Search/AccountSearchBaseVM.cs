﻿abstract class AccountSearchBaseVM : EditBaseVM
{
    CollectionViewSource accounts;
    int? accountId;
    public int? AccountId {
        get { return accountId; }
        set {
            if (accountId != value) {
                accountId = value;
                if (AppData.isAddingAccount) {
                    reportables.Clear();
                    nullify();
                    SelectedAccount = null;
                    updateChart();
                }
                else if (value is null) SelectedAccount = null;
                else {
                    SelectedAccount = AppData.accounts.First(x => x.Id == AccountId);
                    updateReportables();
                }
                OnPropertyChanged(nameof(SelectedAccount));
            }
        }
    }
    string queryAccount;
    public string QueryAccount {
        get { return queryAccount; }
        set {
            if (queryAccount != value) {
                queryAccount = value?.Trim().ToLower();
                SelectionView.Refresh();
            }
        }
    }
    string queryParticulars;
    public string QueryParticulars {
        get { return queryParticulars; }
        set { queryParticulars = value; Reportables.Refresh(); }
    }

    public ICollectionView SelectionView { get; }
    public List<PinSeries> PinLineValues { get; set; }
    public abstract int DeptId { get; }
    protected override string Where => $"AccountId = {AccountId}";
    public static event Action<Account> AccountChanged;
    public static event Action<ReportEntry> BillChanged;

    public AccountSearchBaseVM() : base() {
        Reportables = new CollectionViewSource() {
            Source = reportables,
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(ReportEntry.PaymentDate) }
        }.View;
        Reportables.CollectionChanged += onCollectionChanged;
        Reportables.SortDescriptions.Add(new SortDescription(nameof(ReportEntry.PaymentDate), ListSortDirection.Descending));
        Reportables.Filter = filterParticulars;

        accounts = new CollectionViewSource() {
            Source = AppData.accounts,
            IsLiveFilteringRequested = true
        };
        SelectionView = accounts.View;
        SelectionView.Filter = filter;

        DateSearchVM.BillChanged += onBillChanged;
    }

    void onBillChanged(ReportEntry e) {
        if (e.AccountId != AccountId) return;
        foreach (ReportEntry item in reportables) {
            if (item.BillId == e.BillId) {
                item.BillNo = e.BillNo;
                item.FileName = e.FileName;
                item.Period = e.Period;
                item.TransactionId = e.TransactionId;
                item.Mobile = e.Mobile;
                if (item.PaymentDate != e.PaymentDate) {
                    item.PaymentDate = e.PaymentDate;
                    updateChart();
                }
                item.OnPropertyChanged(null);
                break;
            }
        }
    }
    bool filter(object o) {
        var acc = (Account)o;
        if (string.IsNullOrWhiteSpace(QueryAccount)) return acc.DeptId == DeptId;
        return acc.DeptId == DeptId && acc.AccountNo.Contains(QueryAccount);
    }
    bool filterParticulars(object o) {
        if (string.IsNullOrWhiteSpace(QueryParticulars)) return true;
        return ((ReportEntry)o).Period.Contains(QueryParticulars);
    }
    protected override void onAccountUpdate() {
        AccountChanged?.Invoke(SelectedAccount);
    }
    protected override void onBillUpdate() {
        if (!isDateEqual) updateChart();
        BillChanged?.Invoke(SelectedBill);
    }
    protected override void onBillEntriesUpdate() {
        PieValues = new List<KeyValueSeries>();
        updatePie();
        foreach (var pin in PinLineValues) {
            if (pin.Date.Equals(SelectedBill.PaymentDate)) {
                updateChart();
                break;
            }
        }
    }
    protected override void updateChart() {
        if (reportables.Count == 0) PinLineValues = null;
        else if (reportables.Count > 15) {
            PinLineValues = reportables
                .Skip(reportables.Count - 15)
                .Select(x => new PinSeries() {
                    Date = x.PaymentDate.ToString("yyyy-MM-dd"),
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                })
                .OrderBy(x => x.Date).ToList();
        }
        else PinLineValues = reportables.
                Select(x => new PinSeries() {
                    Date = x.PaymentDate.ToString("yyyy-MM-dd"),
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                })
                .OrderBy(x => x.Date).ToList();
        OnPropertyChanged(nameof(PinLineValues));
    }
    public void Sort() {
        if (Reportables is null) return;
        var oldSort = Reportables.SortDescriptions.First();
        var newSort = new SortDescription() { PropertyName = nameof(ReportEntry.PaymentDate) };
        if (oldSort.Direction == ListSortDirection.Descending) {
            newSort.Direction = ListSortDirection.Ascending;
        }
        else newSort.Direction = ListSortDirection.Descending;
        Reportables.SortDescriptions.Clear();
        Reportables.SortDescriptions.Add(newSort);
    }
}
