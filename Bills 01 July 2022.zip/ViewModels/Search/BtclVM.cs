﻿class BtclVM : AccountSearchBaseVM
{
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.BTCL)).Id;
}
