﻿class LoadVM : Notifiable
{
    static object duplicateKey = new();
    Socket listener;
    bool isCancelled;
    BlockingCollection<Packet> packets;
    BlockingCollection<string> netfiles;
    ManualResetEventSlim mrSlim;

    string[] files;
    Thread processor, updater;
    ObservableCollection<RawInfo> info;
    CollectionViewSource infoSource;

    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public bool IsListening { get; set; }
    public string ListeningString { get; set; }
    public string Directory { get; set; }
    public string ProcessingInfo { get; set; }
    public double ProgressValue { get; set; }
    public ICollectionView Info { get; set; }
    public bool IsInProgress { get; set; }
    public bool IsInUpdate { get; set; }
    string query;
    public string Query {
        get { return query; }
        set { query = value ?? ""; Info.Refresh(); }
    }
    string updatingInfo;
    public string UpdatingInfo {
        get { return updatingInfo; }
        set { updatingInfo = value; OnPropertyChanged(nameof(UpdatingInfo)); }
    }
    bool canUpdate;
    public bool CanUpdate {
        get { return canUpdate; }
        set { canUpdate = value; OnPropertyChanged(nameof(CanUpdate)); }
    }
    double totalPaid;
    public double TotalPaid {
        get { return totalPaid; }
        set { totalPaid = value; OnPropertyChanged(nameof(TotalPaid)); }
    }
    int okCount;
    public int OkCount {
        get { return okCount; }
        set { okCount = value; OnPropertyChanged(nameof(OkCount)); }
    }
    RawInfo selectedItem;
    public RawInfo SelectedItem {
        get { return selectedItem; }
        set { selectedItem = value; SelectionChanged?.Invoke(value); }
    }
    public static event Action<RawInfo> SelectionChanged;
    public LoadVM() {
        Directory = "Choose a directory";
        info = new ObservableCollection<RawInfo>();
        infoSource = new CollectionViewSource() {
            Source = info,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(RawInfo.Department) }
        };
        Info = infoSource.View;
        Info.GroupDescriptions.Add(new PropertyGroupDescription(nameof(RawInfo.Department)));
        Info.Filter = filterImage;
        mrSlim = new ManualResetEventSlim(true);
        FinalizeVM.BillChanged += onBillChanged;
        FinalizeVM.OkChanged += onOkChanged;
        FinalizeVM.AdjustOkCount += onOkAdjust;
    }
    void onOkAdjust() {
        if (OkCount > 0) {
            OkCount--;
            if (info.FirstOrDefault(x => x.IsOk) is null) {
                if (CanUpdate) CanUpdate = false;
            }
        }
    }
    bool filterImage(object o) {
        var info = (RawInfo)o;
        if (info.RawText.Contains(Query)) return true;
        return false;
    }
    public void setOk() {
        var error = App.BP.ValidationErrors(SelectedItem);
        if (error.Count == 0) {
            var dept = AppData.GetDepartment(SelectedItem.Department.Trim());
            var customerId = SelectedItem.CustomerNo.Trim();
            if (!AppData.HasAccount(dept.Name, customerId)) {
                var dialog = new AccountCreateDialog(dept.Name, customerId);
                if (!dialog.ShowDialog().Value) return;

                var (name, address, isCorrect) = dialog.GetNameAndAddress();
                var account = AppData.GetAccount(dept.Name, customerId, name, address, isCorrect);
                SelectedItem.CustomerId = account.Id;
            }
            else {
                var account = AppData.accounts.First(x => x.AccountNo.Equals(customerId));
                if (account.IsWrong == 0) {
                    SelectedItem.CustomerId = AppData.accounts.First(x => x.AccountNo.Equals(customerId)).Id;
                }
                else {
                    var dialog = new AccountErrorDialog(Left, Top, Width, Height, account);
                    if (dialog.ShowDialog().Value) {
                        SelectedItem.CustomerId = AppData.accounts.First(x => x.AccountNo.Equals(customerId)).Id;
                    }
                    else return;
                }
            }

            if (AppData.HasMobile(SelectedItem.PaidFrom)) {
                SelectedItem.MobileId = AppData.mobiles.First(x => x.MobileNo.Equals(SelectedItem.PaidFrom)).Id;
            }
            else {
                var dialog = new MobileCreateDialog(SelectedItem.PaidFrom);
                if (!dialog.ShowDialog().Value) return;

                var mobile = AppData.GetMobile(SelectedItem.PaidFrom, dialog.GetName());
                SelectedItem.MobileId = mobile.Id;
            }
            SelectedItem.DeptId = dept.Id;
            onOkChanged();
        }
        else {
            var errorDialog = new BillErrorDialog(Left, Top, Width, Height, error);
            errorDialog.ShowDialog();
        }
    }
    public void onOkChanged() {
        if (SelectedItem.IsOk) {
            SelectedItem.IsOk = false;
            SelectedItem.OnPropertyChanged(nameof(RawInfo.IsOk));
            OkCount--;
        }
        if (SelectedItem.IsDuplicate) {
            SelectedItem.IsDuplicate = false;
            SelectedItem.OnPropertyChanged(nameof(RawInfo.IsDuplicate));
        }
        var desiredName = $"{SelectedItem.PaymentDate}-{SelectedItem.Department}-{SelectedItem.TransactionNo}.png";
        if (System.IO.File.Exists($"{Constants.ImageFolder}/{desiredName}")) {
            SelectedItem.HasImageWithSameName = true;
            SelectedItem.OnPropertyChanged(nameof(RawInfo.HasImageWithSameName));
            if (info.FirstOrDefault(x => x.IsOk) is null) {
                if (CanUpdate) CanUpdate = false;
            }
            return;
        }
        bool isDuplicate = false;
        foreach (var item in info) {
            if (item.Equals(SelectedItem)) continue;
            if (string.IsNullOrWhiteSpace(item.OutputFileName)) continue;
            if (item.OutputFileName.Equals(desiredName)) {
                isDuplicate = true;
                if (!item.IsDuplicate) {
                    item.IsDuplicate = true;
                    item.OnPropertyChanged(nameof(RawInfo.IsDuplicate));
                }
                if (item.IsOk) {
                    item.IsOk = false;
                    item.OnPropertyChanged(nameof(RawInfo.IsOk));
                    onOkAdjust();
                }
                break;
            }
        }
        SelectedItem.OutputFileName = desiredName;
        if (isDuplicate) {
            SelectedItem.IsDuplicate = true;
            SelectedItem.OnPropertyChanged(nameof(RawInfo.IsDuplicate));
            return;
        }

        SelectedItem.IsOk = true;
        SelectedItem.OnPropertyChanged(nameof(RawInfo.IsOk));
        OkCount++;
        if (SelectedItem.HasImageWithSameName) {
            SelectedItem.HasImageWithSameName = false;
            SelectedItem.OnPropertyChanged(nameof(RawInfo.HasImageWithSameName));
        }
        if (!CanUpdate) CanUpdate = true;
    }
    public void removeItem() {
        bool hadImage = false;
        if (SelectedItem.HasImageWithSameName) hadImage = true;
        if (SelectedItem.IsOk) OkCount--;
        TotalPaid -= SelectedItem.TotalPayment;
        info.Remove(SelectedItem);
        if (SelectedItem is null) {
            TotalPaid = 0; // double/float arithmetic produces unexpected result like -0.00;
            return;
        }
        if (hadImage) {
            bool hasMore = false;
            bool hasValidOk = false;
            foreach (var item in info) {
                if (item.HasImageWithSameName) {
                    hasMore = true;
                    break;
                }
                else if (item.IsOk) hasValidOk = true;
            }
            if (!hasMore && hasValidOk) CanUpdate = true;
        }
    }
    public void UpdateInfo() {
        CanUpdate = false;
        IsInUpdate = true;
        UpdatingInfo = "Analyzing information ...";
        OnPropertyChanged(nameof(IsInUpdate));
        OnPropertyChanged(nameof(UpdatingInfo));
        updater = new Thread(update);
        updater.Start();
    }
    void update() {
        UpdatingInfo = "Checking info ...";
        var toBeRemoved = new List<RawInfo>();
        foreach (var item in info) if (item.IsOk) toBeRemoved.Add(item);

        var entries = getEntries(toBeRemoved);
        int count = 1;
        foreach (var entry in entries) {
            UpdatingInfo = $"Copying {count}/{entries.Count} images ...";
            var image = System.Drawing.Image.FromFile(toBeRemoved[count - 1].FilePath);
            image.Save($"{Constants.ImageFolder}/{entry.Bill.FileName}");
            image.Dispose();
            count++;
            Thread.Sleep(250);
        }
        UpdatingInfo = $"Finished copying {entries.Count} images";
        Thread.Sleep(1000);

        UpdatingInfo = "Creating Commands ...";
        var commands = getCommands(entries);
        UpdatingInfo = $"Finished creating {commands.Count} commands";
        Thread.Sleep(1000);
        UpdatingInfo = "Inserting records in database ...";

        if (!SQL.Transaction(commands)) {
            UpdatingInfo = "Error inserting records in database ...";
            Thread.Sleep(1000);
            UpdatingInfo = "Deleting images ...";
            foreach (var entry in entries) {
                System.IO.File.Delete($"{Constants.ImageFolder}/{entry.Bill.FileName}");
            }
        }
        else {
            UpdatingInfo = $"Finished inserting {commands.Count} records";
            App.Current.Dispatcher.Invoke(() => {
                foreach (var item in toBeRemoved) {
                    TotalPaid -= item.TotalPayment;
                    info.Remove(item);
                }
            });
            Thread.Sleep(1000);
        }
        IsInUpdate = false;
        OkCount = 0;
        App.Current.Dispatcher.Invoke(() => OnPropertyChanged(nameof(IsInUpdate)));
    }
    List<Transaction> getEntries(List<RawInfo> infos) {
        var list = new List<Transaction>();
        foreach (var info in infos) {
            if (info.HasImageWithSameName) continue;
            var billId = ++AppData.MaxBillId;
            var tr = new Transaction();
            tr.Bill = new Bill() {
                AccountId = info.CustomerId,
                DeptId = info.DeptId,
                BillNo = info.BillNo,
                TransactionId = info.TransactionNo,
                PaymentDate = DateTime.Parse(info.PaymentDate),
                Period = info.Period,
                MobileId = info.MobileId,
                FileName = info.OutputFileName
            };

            foreach (var bill in info.BillInfo) {
                var head = AppData.GetHead(bill.Head.Trim());
                tr.BillEntries.Add(new BillEntry() {
                    BillId = billId,
                    HeadId = head.Id,
                    Amount = bill.Amount
                });
            }
            foreach (var pay in info.PaymentInfo) {
                var head = AppData.GetHead(pay.Head.Trim());
                tr.PaymentEntries.Add(new PaymentEntry() {
                    BillId = billId,
                    HeadId = head.Id,
                    Amount = pay.Amount,
                });
            }
            list.Add(tr);
        }
        return list;
    }
    List<KeyValuePair<string, List<SqliteParameter>>> getCommands(List<Transaction> entries) {
        List<KeyValuePair<string, List<SqliteParameter>>> commands = new();
        foreach (var e in entries) {
            var commandText = @$"INSERT INTO Bills(DeptId, AccountId, BillNo, FileName, Period, PaymentDate, MobileId, TransactionId) 
                                    VALUES({e.Bill.DeptId}, {e.Bill.AccountId}, @BillNo, 
                                    @FileName, @Period, @PaymentDate, @MobileId, @TransactionId)";
            var paras = new List<SqliteParameter>() {
                new SqliteParameter("@BillNo", e.Bill.BillNo is null ? DBNull.Value : e.Bill.BillNo),
                new SqliteParameter("@FileName", e.Bill.FileName),
                new SqliteParameter("@Period", e.Bill.Period),
                new SqliteParameter("@PaymentDate", e.Bill.PaymentDate.ToString("yyyy-MM-dd")),
                new SqliteParameter("@MobileId", e.Bill.MobileId == 0 ? DBNull.Value : e.Bill.MobileId),
                new SqliteParameter("@TransactionId", e.Bill.TransactionId)
            };
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(commandText, paras));
            foreach (var bill in e.BillEntries) {
                commandText = $@"INSERT INTO BillEntries(BillId, HeadId, Amount) VALUES({bill.BillId}, {bill.HeadId}, {bill.Amount})";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(commandText, null));
            }
            foreach (var bill in e.PaymentEntries) {
                commandText = $@"INSERT INTO PaymentEntries(BillId, HeadId, Amount) VALUES({bill.BillId}, {bill.HeadId}, {bill.Amount})";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(commandText, null));
            }
        }
        return commands;
    }
    void onBillChanged() => TotalPaid = info.Sum(x => x.TotalPayment);
    public void OnDirectorySelected() {
        var dialog = new System.Windows.Forms.FolderBrowserDialog();
        if (dialog.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
        isCancelled = true;
        files = System.IO.Directory.GetFiles(dialog.SelectedPath, "*.jpg", System.IO.SearchOption.AllDirectories);
        if (files.Length == 0) {
            ProcessingInfo = "No image found for processing";
            OnPropertyChanged(nameof(ProcessingInfo));
            return;
        }
        SelectionChanged?.Invoke(null);
        
        App.Current.MainWindow.TaskbarItemInfo.ProgressState = TaskbarItemProgressState.Normal;
        processor = new Thread(processDirectoryImage);
        processor.Start();
        Directory = dialog.SelectedPath;
        TotalPaid = 0;
        IsInProgress = false;
        CanUpdate = false;
        OnPropertyChanged(nameof(Directory));
        OnPropertyChanged(nameof(IsInProgress));
    }
    public void Listen() {
        if (IsListening) return;
        var addresses = Dns.GetHostAddresses(Dns.GetHostName());
        var address = addresses.First(x => x.AddressFamily == AddressFamily.InterNetwork);
        int port = 5555;
        listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        listener.Bind(new IPEndPoint(address, port));
        listener.Listen(10);
        IsListening = true;
        ListeningString = " Listening on " + address.ToString() + " : " + port;
        OnPropertyChanged(nameof(IsListening));
        OnPropertyChanged(nameof(ListeningString));

        packets = new BlockingCollection<Packet>();
        netfiles = new BlockingCollection<string>();

        new Thread(processPacket) { IsBackground = true }.Start();
        new Thread(processNetworkImage) { IsBackground = true }.Start();
        new Thread(accept) { IsBackground = true }.Start();
    }
    void accept() {
        while (true) {
            var client = listener.Accept();
            var thread = new Thread(receive) { IsBackground = true };
            thread.Start(client);
        }
    }
    void receive(object o) {
        var client = (Socket)o;
        bool isConnected = true;
        while (isConnected) {
            try {
                var buffer = new byte[8];
                int read = client.Receive(buffer, 0, 8, SocketFlags.None);
                if (read == 0) break;
                //Do you need this while or the Receive halts until it fills buffer with 8 bytes?
                while (read < 8) {
                    int received = client.Receive(buffer, read, 8 - read, SocketFlags.None);
                    if (received == 0) {
                        isConnected = false;
                        break;
                    }
                    read += received;
                }
                var nameLength = BitConverter.ToInt32(buffer.Take(4).Reverse().ToArray());
                var fileLength = BitConverter.ToInt32(buffer.Skip(4).Reverse().ToArray());
                var totalLength = nameLength + fileLength;

                buffer = new byte[totalLength];
                read = 0;
                while (read < totalLength) {
                    int received = client.Receive(buffer, read, totalLength - read, SocketFlags.None);
                    if (received == 0) {
                        isConnected = false;
                        break;
                    }
                    read += received;
                }
                if (isConnected) {
                    packets.Add(new Packet() {
                        NameLength = nameLength,
                        Bytes = buffer
                    });
                }
            }
            catch { isConnected = false; }
        }
        client.Shutdown(SocketShutdown.Both);
        client.Close();
        client.Dispose();
    }
    void processPacket() {
        while (true) {
            var packet = packets.Take();
            byte[] nameArray = packet.Bytes.Take(packet.NameLength).ToArray();
            byte[] fileAray = packet.Bytes.Skip(packet.NameLength).ToArray();
            if (fileAray.Length <= 0) continue;
            
            var name = Encoding.UTF8.GetString(nameArray, 0, nameArray.Length);
            var path = @"temp\\" + name + ".jpg";
            var stream = new System.IO.MemoryStream(fileAray);
            var image = System.Drawing.Image.FromStream(stream);
            image.Save(path, System.Drawing.Imaging.ImageFormat.Jpeg);
            netfiles.Add(path);
            stream.Close();
            image.Dispose();
        }
    }
    void processDirectoryImage() {
        mrSlim.Wait();
        mrSlim.Reset();
        isCancelled = false;
        App.Current.Dispatcher.Invoke(info.Clear);

        var start = DateTime.UtcNow;
        int count = 1;
        int total = files.Length;
        foreach (var file in files) {
            if (isCancelled) break;
            ProcessingInfo = "Processing " + count + " of " + files.Length + " files";
            OnPropertyChanged(nameof(ProcessingInfo));
            var newInfo = App.BP.ProcessBill(file);
            double value = (double)count / total;
            TotalPaid += newInfo.TotalPayment;
            ProgressValue = value;
            OnPropertyChanged(nameof(ProgressValue));
            App.Current.Dispatcher.InvokeAsync(() => {
                info.Add(newInfo);
                App.Current.MainWindow.TaskbarItemInfo.ProgressValue = value;
            }, DispatcherPriority.Background);
            count++;
        }

        checkDuplicates();
        var time = (DateTime.UtcNow - start).TotalMilliseconds;
        ProcessingInfo = "Finished processing " + files.Length + " files in " + time.ToString("N0") + " ms.";
        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));
        OnPropertyChanged(nameof(ProcessingInfo));
        mrSlim.Set();
        App.Current.Dispatcher.Invoke(() => {
            App.Current.MainWindow.TaskbarItemInfo.ProgressState = TaskbarItemProgressState.None;
        });
    }
    void checkDuplicates() {
        // one check with transaction ID will work?
        foreach (CollectionViewGroup group in Info.Groups) {
            if (isCancelled) break;
            if (group.Name is null) continue;
            if (group.Name.Equals(BillProcessor.WASA) || group.Name.Equals(BillProcessor.DESCO)) {
                var grouped = group.Items.Cast<RawInfo>().GroupBy(x => x.BillNo).Where(x => x.Count() > 1).ToList();
                if (grouped?.Count > 0) {
                    foreach (var dup in grouped) {
                        foreach (var i in dup) {
                            i.IsDuplicate = true;
                            i.OnPropertyChanged(nameof(RawInfo.IsDuplicate));
                        }
                    }
                }
            }
            else if (group.Name.Equals(BillProcessor.BTCL) || group.Name.Equals(BillProcessor.TGCL)) {
                var grouped = group.Items.Cast<RawInfo>().GroupBy(x => new { x.CustomerNo, x.Period }).Where(x => x.Count() > 1).ToList();
                if (grouped?.Count > 0) {
                    foreach (var dup in grouped) {
                        foreach (var i in dup) {
                            i.IsDuplicate = true;
                            i.OnPropertyChanged(nameof(RawInfo.IsDuplicate));
                        }
                    }
                }
            }
        }
    }
    void processNetworkImage() {
        while (true) {
            var file = netfiles.Take();
            var newInfo = App.BP.ProcessBill(file);
            TotalPaid += newInfo.TotalPayment;
            
            App.Current.Dispatcher.InvokeAsync(() => {
                Monitor.Enter(duplicateKey);
                info.Add(newInfo);
                Monitor.Exit(duplicateKey);
            }, DispatcherPriority.Background);

            Monitor.Enter(duplicateKey);
            checkDuplicates();
            Monitor.Exit(duplicateKey);
        }
    }
}