﻿class AmountInfo
{
    public string Head { get; set; }
    public double Amount { get; set; }
}
