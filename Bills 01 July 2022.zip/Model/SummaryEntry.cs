﻿class SummaryEntry : Notifiable
{
    public string Date { get; set; }
    public string DeptName { get; set; }
    public string AccountNo { get; set; }
    public string AccountName { get; set; }
    public string AccountAddress { get; set; }
    public string Head { get; set; }
    public double Bill { get; set; }
    public double Payment { get; set; }
    public int AccountId { get; set; }
    public string Mobile { get; set; }
    public string Month { get; set; }
}
