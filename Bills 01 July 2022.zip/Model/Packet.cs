﻿class Packet
{
    public int NameLength { get; set; }
    public byte[] Bytes { get; set; }
}