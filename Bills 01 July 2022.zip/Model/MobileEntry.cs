﻿class MobileEntry
{
    string monthYear;
    public string MonthYear {
        get { return monthYear; }
        set {
            var month = Convert.ToByte(value.Substring(0, 2));
            var year = value.Substring(2);
            monthYear = getMonthName(month) + year; 
        }
    }

    public string Dept { get; set; }
    public DateTime Date { get; set; }
    public double Amount { get; set; }
    public string FileName { get; set; }
    public string Account { get; set; }

    string getMonthName(byte monthNo) {
        return monthNo switch {
            1 => "January",
            2 => "February",
            3 => "March",
            4 => "April",
            5 => "May",
            6 => "June",
            7 => "July",
            8 => "August",
            9 => "September",
            10 => "October",
            11 => "November",
            _ => "December",
        };
    }
}
