﻿class Bill
{
    public int Id { get; set; }
    public int DeptId { get; set; }
    public int AccountId { get; set; }
    public string BillNo { get; set; }
    public string FileName { get; set; }
    public string Period { get; set; }
    public DateTime PaymentDate { get; set; }
    public int MobileId { get; set; }
    public string TransactionId { get; set; }
}
