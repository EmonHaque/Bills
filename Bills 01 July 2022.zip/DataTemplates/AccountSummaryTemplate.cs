﻿class AccountSummaryTemplate : DataTemplate
{
    public AccountSummaryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var account = new FrameworkElementFactory(typeof(TextBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));
        
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        amount.SetValue(Grid.ColumnProperty, 1);

        account.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryAccount.Account)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryAccount.Amount)) { StringFormat = Constants.NumberFormat });
        grid.SetValue(Grid.ToolTipProperty, new AccountSummaryTemplateToolTip());

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(account);
        grid.AppendChild(amount);
        VisualTree = grid;
    }
}
