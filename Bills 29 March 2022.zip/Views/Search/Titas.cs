﻿class Titas : SearchBase
{
    public override string Icon => Icons.Gas;
    public override string Header => "TGCL";
    TitasVM viewModel = new();
    protected override SearchBaseVM vm => viewModel;
}
