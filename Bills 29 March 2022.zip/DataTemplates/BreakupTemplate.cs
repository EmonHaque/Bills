﻿class BreakupTemplate : Grid
{
    TextBlock head, bill, payment;
    public BreakupTemplate() {
        head = new TextBlock();
        bill = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        payment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(bill, 1);
        Grid.SetColumn(payment, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth)});
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) });

        Children.Add(head);
        Children.Add(bill);
        Children.Add(payment);
    }
    public override void EndInit() {
        base.EndInit();
        var breakup = (Breakup)DataContext;
        head.Text = breakup.Head;
        bill.Text = breakup.Bill.ToString(Constants.NumberFormat);
        payment.Text = breakup.Payment.ToString(Constants.NumberFormat);
    }
}