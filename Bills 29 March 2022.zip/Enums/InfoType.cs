﻿enum InfoType
{
    Bill,
    Payment
}

