﻿class DragItemOutListBox : ListBox
{
    bool isMouseDown, isDragging;
    double startX, dragX, startY, dragY;
    Popup draggerPopup;
    Border draggerBorder;
    ListBoxItem dragItem;

    public DragItemOutListBox() {
        AllowDrop = true;
        draggerBorder = new Border() {
            BorderThickness = new Thickness(0, 0.5, 0, 0.5),
            BorderBrush = Brushes.LightGray
        };
        draggerPopup = new Popup() {
            Placement = PlacementMode.MousePoint,
            Child = draggerBorder
        };
    }
    void DragContrinueHandler(object sender, QueryContinueDragEventArgs e) {
        draggerPopup.HorizontalOffset = dragX - startX;
        draggerPopup.VerticalOffset = dragY - startY - 10;
        if (e.Action == DragAction.Continue && e.KeyStates != DragDropKeyStates.LeftMouseButton) {
            draggerPopup.IsOpen = false;
        }
    }
    protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs e) {
        var position = e.GetPosition(this);
        var result = VisualTreeHelper.HitTest(this, position);
        var obj = result.VisualHit;
        while (VisualTreeHelper.GetParent(obj) != null && !(obj is ListBoxItem)) {
            obj = VisualTreeHelper.GetParent(obj);
        }
        dragItem = obj as ListBoxItem;
        if(dragItem is not null) {
            startX = position.X;
            startY = position.Y;
            isMouseDown = true;
        }
    }
    protected override void OnPreviewDragOver(DragEventArgs e) {
        var position = e.GetPosition(this);
        dragX = position.X;
        dragY = position.Y;
    }
    protected override void OnPreviewMouseMove(MouseEventArgs e) {
        if (isMouseDown) {
            dragX = Math.Abs(e.GetPosition(this).X - startX);
            dragY = Math.Abs(e.GetPosition(this).Y - startY);

            if ((isDragging == false) &&
                (dragX > SystemParameters.MinimumHorizontalDragDistance) &&
                (dragY > SystemParameters.MinimumVerticalDragDistance)) {

                CaptureMouse();
                draggerBorder.Width = dragItem.ActualWidth;
                draggerBorder.Height = dragItem.ActualHeight;
                draggerBorder.Background = new VisualBrush(dragItem);
                draggerPopup.IsOpen = true;
                isDragging = true;

                var data = ItemContainerGenerator.ItemFromContainer(dragItem);
                DragDrop.AddQueryContinueDragHandler(this, DragContrinueHandler);
                DragDrop.DoDragDrop(this, data, DragDropEffects.All);
            }
        }
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (!isMouseDown) return;
        isMouseDown = false;
        isDragging = false;
        ReleaseMouseCapture();
        DragDrop.RemoveQueryContinueDragHandler(this, DragContrinueHandler);
    }
    protected override void OnGiveFeedback(GiveFeedbackEventArgs e) {
        Mouse.SetCursor(Cursors.Hand);
        e.Handled = true;
    }
}
