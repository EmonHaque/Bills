﻿class ScrollViewerEx : ScrollViewer
{
    double hOff, vOff;
    Point start;
    FrameworkElement content;
    public ScrollViewerEx() {
        HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
    }
    public override void OnApplyTemplate() {
        base.OnApplyTemplate();
        ((Rectangle)Template.FindName("Corner", this)).Fill = Constants.Background;
        content = (FrameworkElement)Content;
        content.LayoutTransform = new ScaleTransform();
    }
    protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonDown(e);
        if (!e.Source.Equals(Content)) return;
        content.CaptureMouse();
        hOff = HorizontalOffset;
        vOff = VerticalOffset;
        start = e.GetPosition(this);
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonUp(e);
        content.ReleaseMouseCapture();
    }
    protected override void OnPreviewMouseMove(MouseEventArgs e) {
        base.OnPreviewMouseMove(e);
        if (!content.IsMouseCaptured) return;
        var end = e.GetPosition(this);
        ScrollToHorizontalOffset(hOff + start.X - end.X);
        ScrollToVerticalOffset(vOff + start.Y - end.Y);
    }
    protected override void OnPreviewMouseWheel(MouseWheelEventArgs e) {
        base.OnPreviewMouseWheel(e);
        var point = e.GetPosition(content);
        var scaleX = ((ScaleTransform)content.LayoutTransform).ScaleX;
        var scaleY = ((ScaleTransform)content.LayoutTransform).ScaleY;
        if (e.Delta > 0) {
            scaleX += 0.1;
            scaleY += 0.1;
        }
        else if (scaleX > 0.2) {
            scaleX -= 0.1;
            scaleY -= 0.1;
        }
        content.LayoutTransform = new ScaleTransform(scaleX, scaleY, point.X, point.Y);
        e.Handled = true;
    }
}
