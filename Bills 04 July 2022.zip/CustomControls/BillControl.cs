﻿class BillControl : Grid
{
    TextBlock dateBlock, transactionBlock, billNoBlock, mobileBlock, periodBlock;
    Run date, transaction, bill, mobile;
    TextBox editedDate, editedTransaction, editedBill, editedMobile, editedPeriod;
    ActionButton edit, cancel, save;
    StackPanel buttonStack;

    #region DependencyProperties
    public static readonly DependencyProperty DeptIdProperty;
    public static readonly DependencyProperty DateProperty;
    public static readonly DependencyProperty TransactionProperty;
    public static readonly DependencyProperty MobileNoProperty;
    public static readonly DependencyProperty BillNoProperty;
    public static readonly DependencyProperty PeriodProperty;
    public static readonly DependencyProperty IsOnEditProperty;
    public static readonly DependencyProperty EditedDateProperty;
    public static readonly DependencyProperty EditedTransactionProperty;
    public static readonly DependencyProperty EditedMobileNoProperty;
    public static readonly DependencyProperty EditedBillNoProperty;
    public static readonly DependencyProperty EditedPeriodProperty;

    static BillControl() {
        DeptIdProperty = DependencyProperty.Register("DeptId", typeof(int), typeof(BillControl));
        DateProperty = DependencyProperty.Register("Date", typeof(string), typeof(BillControl));
        TransactionProperty = DependencyProperty.Register("Transaction", typeof(string), typeof(BillControl), new PropertyMetadata() {
            PropertyChangedCallback = (d,e) => {
                var o = (BillControl)d;
                if (e.NewValue is null || string.IsNullOrWhiteSpace(e.NewValue.ToString()))
                    o.Visibility = Visibility.Hidden;
                else o.Visibility = Visibility.Visible;
            }
        });
        MobileNoProperty = DependencyProperty.Register("MobileNo", typeof(string), typeof(BillControl));
        BillNoProperty = DependencyProperty.Register("BillNo", typeof(string), typeof(BillControl));
        PeriodProperty = DependencyProperty.Register("Period", typeof(string), typeof(BillControl));
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = false,
            BindsTwoWayByDefault = true
        });
        EditedDateProperty = DependencyProperty.Register("EditedDate", typeof(string), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedTransactionProperty = DependencyProperty.Register("EditedTransaction", typeof(string), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedMobileNoProperty = DependencyProperty.Register("EditedMobileNo", typeof(string), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedBillNoProperty = DependencyProperty.Register("EditedBillNo", typeof(string), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        EditedPeriodProperty = DependencyProperty.Register("EditedPeriod", typeof(string), typeof(BillControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
    }
    
    public int DeptId {
        get { return (int)GetValue(DeptIdProperty); }
        set { SetValue(DeptIdProperty, value); }
    }
    public string Date {
        get { return (string)GetValue(DateProperty); }
        set { SetValue(DateProperty, value); }
    }
    public string Transaction {
        get { return (string)GetValue(TransactionProperty); }
        set { SetValue(TransactionProperty, value); }
    }
    public string MobileNo {
        get { return (string)GetValue(MobileNoProperty); }
        set { SetValue(MobileNoProperty, value); }
    }
    public string BillNo {
        get { return (string)GetValue(BillNoProperty); }
        set { SetValue(BillNoProperty, value); }
    }
    public string Period {
        get { return (string)GetValue(PeriodProperty); }
        set { SetValue(PeriodProperty, value); }
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public string EditedDate {
        get { return (string)GetValue(EditedDateProperty); }
        set { SetValue(EditedDateProperty, value); }
    }
    public string EditedTransaction {
        get { return (string)GetValue(EditedTransactionProperty); }
        set { SetValue(EditedTransactionProperty, value); }
    }
    public string EditedMobileNo {
        get { return (string)GetValue(EditedMobileNoProperty); }
        set { SetValue(EditedMobileNoProperty, value); }
    }
    public string EditedBillNo {
        get { return (string)GetValue(EditedBillNoProperty); }
        set { SetValue(EditedBillNoProperty, value); }
    }
    public string EditedPeriod {
        get { return (string)GetValue(EditedPeriodProperty); }
        set { SetValue(EditedPeriodProperty, value); }
    }
    #endregion

    public BillControl() {
        Visibility = Visibility.Hidden;
        Margin = new Thickness(0, 0, 10, 0);
        Background = Brushes.Transparent;
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { save, cancel }
        };

        date = new Run();
        transaction = new Run();
        bill = new Run();
        mobile = new Run();

        dateBlock = new TextBlock() {
            Inlines = {
                new Run(){Text = "Date "},
                date
            }
        };
        transactionBlock = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Inlines = {
                new Run(){Text = "Transaction "},
                transaction
            }
        };
        billNoBlock = new TextBlock() {
            Inlines = {
                new Run(){Text = "Bill No "},
                bill
            }
        };
        mobileBlock = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Inlines = {
                new Run(){Text = "Mobile "},
                mobile
            }
        };
        periodBlock = new TextBlock() {
            Margin = new Thickness(0, 0, 0, 5),
            HorizontalAlignment = HorizontalAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        double minWidth = 100;
        editedDate = new TextBox() {
            MinWidth = minWidth,
            Margin = new Thickness(0, 0, 0, 5),
            HorizontalAlignment = HorizontalAlignment.Left,
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Visibility = Visibility.Collapsed
        };
        editedTransaction = new TextBox() {
            MinWidth = minWidth,
            Margin = new Thickness(0, 0, 0, 5),
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right,
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Visibility = Visibility.Collapsed
        };
        editedBill = new TextBox() {
            MinWidth = minWidth,
            Margin = new Thickness(0, 0, 0, 5),
            HorizontalAlignment = HorizontalAlignment.Left,
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Visibility = Visibility.Collapsed
        };
        editedMobile = new TextBox() {
            MinWidth = minWidth,
            Margin = new Thickness(0, 0, 0, 5),
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right,
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Visibility = Visibility.Collapsed
        };
        editedPeriod = new TextBox() {
            TextAlignment = TextAlignment.Center,
            Margin = new Thickness(0,0,0,5),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            Visibility = Visibility.Collapsed
        };
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumn(edit, 1);
        SetColumn(buttonStack, 1);

        SetRow(periodBlock, 1);
        SetColumnSpan(periodBlock, 2);
        SetRow(dateBlock, 2);
        SetRow(transactionBlock, 2);
        SetColumn(transactionBlock, 1);
        SetRow(billNoBlock, 3);
        SetRow(mobileBlock, 3);
        SetColumn(mobileBlock, 1);

        SetRow(editedPeriod, 1);
        SetColumnSpan(editedPeriod, 2);
        SetRow(editedDate, 2);
        SetRow(editedTransaction, 2);
        SetColumn(editedTransaction, 1);
        SetRow(editedBill, 3);
        SetRow(editedMobile, 3);
        SetColumn(editedMobile, 1);

        Children.Add(edit);
        Children.Add(buttonStack);

        Children.Add(dateBlock);
        Children.Add(transactionBlock);
        Children.Add(billNoBlock);
        Children.Add(periodBlock);
        Children.Add(mobileBlock);

        Children.Add(editedDate);
        Children.Add(editedTransaction);
        Children.Add(editedBill);
        Children.Add(editedMobile);
        Children.Add(editedPeriod);

        date.SetBinding(Run.TextProperty, new Binding(nameof(Date)) { Source = this });
        transaction.SetBinding(Run.TextProperty, new Binding(nameof(Transaction)) { Source = this });
        bill.SetBinding(Run.TextProperty, new Binding(nameof(BillNo)) { Source = this });
        mobile.SetBinding(Run.TextProperty, new Binding(nameof(MobileNo)) { Source = this });
        periodBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(Period)) { Source = this });

        editedDate.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedDate)) { Source = this, /*UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged*/ });
        editedTransaction.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedTransaction)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
        editedBill.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedBillNo)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
        editedMobile.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedMobileNo)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
        editedPeriod.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedPeriod)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
    }

    void setEdit() {
        IsOnEdit = true;
        dateBlock.Visibility = Visibility.Collapsed;
        transactionBlock.Visibility = Visibility.Collapsed;
        billNoBlock.Visibility = Visibility.Collapsed;
        mobileBlock.Visibility = Visibility.Collapsed;
        periodBlock.Visibility = Visibility.Collapsed;
        edit.Visibility = Visibility.Collapsed;

        editedDate.Visibility = Visibility.Visible;
        editedTransaction.Visibility = Visibility.Visible;
        editedBill.Visibility = Visibility.Visible;
        editedMobile.Visibility = Visibility.Visible;
        editedPeriod.Visibility = Visibility.Visible;
        buttonStack.Visibility = Visibility.Visible;
    }
    void cancelEdit() {
        if (!Period.Equals(EditedPeriod)) EditedPeriod = Period;
        if (!Date.Equals(EditedDate)) EditedDate = Date;
        if (!Transaction.Equals(EditedTransaction)) EditedTransaction = Transaction;
        if (!BillNo.Equals(EditedBillNo)) EditedBillNo = BillNo;
        if (!MobileNo.Equals(EditedMobileNo)) EditedMobileNo = MobileNo;
        resetVisibility();
    }
    void saveEdit() {
        List<ValidationError> errors = new();
        DateTime outDate;
        if(!DateTime.TryParseExact(editedDate.Text, "yyyy-MM-dd", new CultureInfo("en-US"), DateTimeStyles.None, out outDate)) {
            errors.Add(new ValidationError() {
                Head = "Date",
                Error = "expected format is yyyy-MM-dd"
            });
        }
        else EditedDate = outDate.ToString("yyyy-MM-dd");
        
        if (string.IsNullOrWhiteSpace(EditedTransaction)) {
            errors.Add(new ValidationError() {
                Head = "Transaction Id",
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(EditedPeriod)) {
            errors.Add(new ValidationError() {
                Head = "Period",
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(EditedMobileNo)) {
            errors.Add(new ValidationError() {
                Head = "Mobile No.",
                Error = "cannot be empty"
            });
        }

        var dept = AppData.departments.First(x => x.Id == DeptId).Name;
        var oldFile = $"{Date}-{dept}-{Transaction}.png";
        var newFile = $"{EditedDate}-{dept}-{EditedTransaction}.png";
        if (!oldFile.Equals(newFile)) {
            if (System.IO.File.Exists($"{Constants.ImageFolder}/{newFile}")) {
                errors.Add(new ValidationError() {
                    Head = "Transaction ",
                    Error = $"another entry with same TransactionId and Date exists in {dept}"
                });
            }
        }
        
        if (errors.Count > 0) {
            var errorDialog = new BillErrorDialog(AccountSearchBase.Left, AccountSearchBase.Top, AccountSearchBase.Width, AccountSearchBase.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        resetVisibility();
    }
    void resetVisibility() {
        IsOnEdit = false;
        editedDate.Visibility = Visibility.Collapsed;
        editedTransaction.Visibility = Visibility.Collapsed;
        editedBill.Visibility = Visibility.Collapsed;
        editedMobile.Visibility = Visibility.Collapsed;
        editedPeriod.Visibility = Visibility.Collapsed;
        buttonStack.Visibility = Visibility.Collapsed;

        dateBlock.Visibility = Visibility.Visible;
        transactionBlock.Visibility = Visibility.Visible;
        billNoBlock.Visibility = Visibility.Visible;
        mobileBlock.Visibility = Visibility.Visible;
        periodBlock.Visibility = Visibility.Visible;
        edit.Visibility = Visibility.Hidden;
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }
}