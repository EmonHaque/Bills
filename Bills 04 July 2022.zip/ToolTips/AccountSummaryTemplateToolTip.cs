﻿class AccountSummaryTemplateToolTip : ToolTip
{
    public AccountSummaryTemplateToolTip() {
        var text = new TextBlock() { 
            TextAlignment = TextAlignment.Center,
            Foreground = Brushes.LightGray,
        };
        text.SetBinding(TextBlock.TextProperty, new Binding(nameof(SummaryAccount.NameAndAddress)));
        Content = text;
    }
}
