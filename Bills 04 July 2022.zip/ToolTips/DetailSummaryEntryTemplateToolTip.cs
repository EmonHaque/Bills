﻿class DetailSummaryEntryTemplateToolTip : ToolTip
{
    public DetailSummaryEntryTemplateToolTip() {
        var name = new Run();
        var address = new Run();
        name.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountName)));
        address.SetBinding(Run.TextProperty, new Binding(nameof(SummaryEntry.AccountAddress)));
        Content = new TextBlock() {
            Foreground = Brushes.LightGray,
            Inlines = { name, new Run("\n"), address },
            TextAlignment = TextAlignment.Center
        };
    }
    public DetailSummaryEntryTemplateToolTip(Account account) {
        var name = new Run() { Text = account.Name };
        var address = new Run() { Text = account.Address };
        Content = new TextBlock() {
            Foreground = Brushes.LightGray,
            Inlines = { name, new Run("\n"), address },
            TextAlignment = TextAlignment.Center
        };
    }
}
