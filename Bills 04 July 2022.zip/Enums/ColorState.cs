﻿enum ColorState
{
    BlackWhite,
    Gray,
    Color
}
