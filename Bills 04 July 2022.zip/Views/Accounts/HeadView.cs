﻿class HeadView : CardView
{
    public override string Header => "Heads";
    public override string Icon => Icons.ControlHead;

    ListBox list;
    HeadVM vm;
    public HeadView() {
        vm = new HeadVM();
        DataContext = vm;
        list = new ListBox() { DisplayMemberPath = nameof(Head.Name) };
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Heads)));
        setContent(list);
    }
}
