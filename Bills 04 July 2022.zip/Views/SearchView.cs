﻿class SearchView : ViewContainer
{
    public override string Icon => Icons.Search;
    public SearchView() {
        Children.Add(new Wasa());
        Children.Add(new Titas());
        Children.Add(new Desco());
        Children.Add(new Btcl());
        Children.Add(new DateSearch());
        Children.Add(new MobileSearch());
    }
}
