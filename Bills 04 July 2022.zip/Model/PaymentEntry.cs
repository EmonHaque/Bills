﻿class PaymentEntry
{
    public int Id { get; set; }
    public int BillId { get; set; }
    public int HeadId { get; set; }
    public double Amount { get; set; }
}