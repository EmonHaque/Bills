﻿class DetailGroupLevel2Thickness : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        if (group.IsBottomLevel) return new Thickness(0);

        var first = (CollectionViewGroup)(group.Items).First();

        if (first.IsBottomLevel) return new Thickness(0, 0.5, 0, 0);
        return new Thickness(0);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
