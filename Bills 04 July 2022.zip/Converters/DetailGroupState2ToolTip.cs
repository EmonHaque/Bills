﻿class DetailGroupState2ToolTip : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        byte state = (byte)values[0];
        if (state == 0) return null;

        var group = (CollectionViewGroup)values[1];
        if (!group.IsBottomLevel) return null;

        var accountNo = group.Name.ToString();
        var account = AppData.accounts.First(x => x.AccountNo.Equals(accountNo));
        return new DetailSummaryEntryTemplateToolTip(account);
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
