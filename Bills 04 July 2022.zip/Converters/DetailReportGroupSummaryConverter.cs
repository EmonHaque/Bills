﻿class DetailReportGroupSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var group = (CollectionViewGroup)value;
        if (group is null) return 0;
        double bill, payment;
        bill = payment = 0;

        if (group.IsBottomLevel) {
            var items = group.Items.OfType<SummaryEntry>();
            foreach (var e in items) {
                bill += e.Bill;
                payment += e.Payment;
            }
        }
        else {
            foreach (CollectionViewGroup subGroup in group.Items) {
                var sum = (Tuple<double, double>)Convert(subGroup, null, null, null);
                bill += sum.Item1;
                payment += sum.Item2;
            }
        }
        return new Tuple<double, double>(bill, payment);
    }
    public object ConvertBack(object value, Type targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}