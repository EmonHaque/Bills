﻿class DetailReportSummaryTemplate : DataTemplate
{
    public DetailReportSummaryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));

        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        var bill = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));

        bill.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        bill.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(Grid.ColumnProperty, 1);
        payment.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        bill.SetBinding(TextBlock.TextProperty, new Binding("Item1") { StringFormat = Constants.NumberFormat});
        payment.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(bill);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}
