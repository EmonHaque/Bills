﻿class MobileTemplate : DataTemplate 
{
    public MobileTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var name = new FrameworkElementFactory(typeof(TextBlock));
        var no = new FrameworkElementFactory(typeof(TextBlock));

        no.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(Mobile.Name)));
        no.SetBinding(TextBlock.TextProperty, new Binding(nameof(Mobile.MobileNo)));

        grid.AppendChild(name);
        grid.AppendChild(no);
        VisualTree = grid;
    }
}
