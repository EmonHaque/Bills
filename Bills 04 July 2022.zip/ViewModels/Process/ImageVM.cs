﻿class ImageVM : ImageBaseVM
{
    public RawInfo Info { get; set; }
    public ImageVM() {       
        LoadVM.SelectionChanged += onSelectionChanged;
    }
    void onSelectionChanged(RawInfo info) {       
        Info = info;
        if (Info is null) return;
        
        imagePath = Info.FilePath;
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
    }
}

