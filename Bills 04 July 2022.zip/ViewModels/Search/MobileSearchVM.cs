﻿class MobileSearchVM : ImageBaseVM
{
    CollectionViewSource selectionSource;
    ObservableCollection<MobileEntry> reportables;
    ObservableCollection<SummaryAccount> summary;
    int? accountId;
    public int? AccountId {
        get { return accountId; }
        set {
            if (accountId != value) {
                accountId = value;
                if (AppData.isAddingMobile) clearReportables();
                else {
                    IsRefreshValid = value is null ? false : true;
                    updateReportables();
                    OnPropertyChanged(nameof(IsRefreshValid));
                }
            }
        }
    }
    string queryAccount;
    public string QueryAccount {
        get { return queryAccount; }
        set {
            if (queryAccount != value) {
                queryAccount = value?.Trim().ToLower();
                SelectionView.Refresh();
            }
        }
    }
    MobileEntry selected;
    public MobileEntry Selected {
        get { return selected; }
        set { selected = value; updateEntryInfo(); }
    }
    public ReportDates Dates { get; set; }
    public int TotalItem { get; set; }
    public double TotalAmount { get; set; }
    public double TotalSummary { get; set; }
    public int TotalSummaryItem { get; set; }
    public ICollectionView SelectionView { get; set; }
    public ICollectionView Reportables { get; set; }
    public ICollectionView Summary { get; set; }
    public Action RefreshAccount { get; set; }
    public Action RefreshAccountSummary { get; set; }
    public bool IsRefreshValid { get; set; }

    public MobileSearchVM() {
        IsRefreshValid = true;
        selectionSource = new CollectionViewSource() { Source = AppData.mobiles };
        SelectionView = selectionSource.View;
        SelectionView.Filter = filterMobile;
        RefreshAccount = refreshAccount;
        RefreshAccountSummary = makeAccountSummary;
        Dates = new ReportDates();

        summary = new ObservableCollection<SummaryAccount>();
        Summary = CollectionViewSource.GetDefaultView(summary);
        Summary.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryAccount.Department)));
        Summary.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryAccount.Account)));

        reportables = new ObservableCollection<MobileEntry>();
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(MobileEntry.MonthYear)));
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(MobileEntry.Dept)));
        Reportables.CollectionChanged += onCollectionChanged;
    }

    bool filterMobile(object o) {
        if (string.IsNullOrWhiteSpace(QueryAccount)) return true;
        var mobile = (Mobile)o;
        return mobile.MobileNo.Contains(QueryAccount) || mobile.Name.Contains(QueryAccount);
    }
    void updateReportables() {
        if (AccountId is null) return;
        
        BusyWindow.Activate(MobileSearch.Left, MobileSearch.Top, MobileSearch.Width, MobileSearch.Height, "Loading");
        reportables.Clear();

        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH t1 AS(
                                        	SELECT Bills.Id, Department.Name Dept, Account.AccountNo Account, PaymentDate, FileName, 
                                            strftime('%m, %Y', PaymentDate) Month, 
                                            Account.Name, Account.Address FROM Bills
                                        	LEFT JOIN Account ON Account.Id = Bills.AccountId
                                            LEFT JOIN Department ON Department.Id = Bills.DeptId
                                        	WHERE MobileId = {AccountId}
                                        ),
                                        t2 AS(
                                        	SELECT BillId, SUM(Amount) Amount FROM PaymentEntries WHERE BillId IN(SELECT Id FROM t1)
                                        	GROUP BY BillId
                                        )
                                        SELECT Month, Dept, PaymentDate, t2.Amount, FileName, Account, Name, Address FROM t1
                                        LEFT JOIN t2 ON t2.BillId = t1.Id
                                        ORDER BY PaymentDate";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var e = new MobileEntry() {
                    MonthYear = reader.GetString(0),
                    Dept = reader.GetString(1),
                    Date = reader.GetDateTime(2),
                    Amount = reader.GetDouble(3),
                    FileName = reader.GetString(4),
                    Account = reader.GetString(5),
                    AccountName = reader.GetString(6),
                    AccountAddress = reader.GetString(7)
                };
                reportables.Add(e);
            }
            reader.Close();
            reader.DisposeAsync();
        }
        if (reportables.Count > 0) {
            Dates = new ReportDates();
            Dates.Start = Dates.From = reportables.First().Date;
            var last = reportables.Last();
            Dates.End = Dates.To = last.Date;
            makeAccountSummary();
            OnPropertyChanged(nameof(Dates));
            Selected = last;
        }
        else clearReportables();
        BusyWindow.Terminate();
    }
    void clearReportables() {
        summary.Clear();
        reportables.Clear();
        Dates = new ReportDates() { Start = DateTime.Now, End = DateTime.Now };
        Selected = null;
        OnPropertyChanged(nameof(Dates));
    }
    void makeAccountSummary() {
        summary.Clear();
        TotalSummary = 0;
        foreach (MobileEntry item in Reportables) {
            SummaryAccount group = null;
            for (int i = 0; i < summary.Count; i++) {
                if (summary[i].Department.Equals(item.Dept) && summary[i].Account.Equals(item.Account)) {
                    group = summary[i];
                    break;
                }
            }
            if(group is null) {
                var account = AppData.accounts.First(x => x.AccountNo.Equals(item.Account));
                group = new SummaryAccount() {
                    Department = item.Dept,
                    Account = item.Account,
                    NameAndAddress = account.Name + "\n" + account.Address,
                    Amount = item.Amount,
                    Count = 1
                };
                summary.Add(group);
            }
            else {
                group.Amount += item.Amount;
                group.Count++;
            }
            TotalSummary += item.Amount;
        }
        TotalSummaryItem = summary.Count;
        OnPropertyChanged(nameof(TotalSummary));
        OnPropertyChanged(nameof(TotalSummaryItem));
    }
    bool filterReportables(object o) {
        var e = (MobileEntry)o;
        return e.Date >= Dates.From && e.Date <= Dates.To;
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalItem = 0;
        TotalAmount = 0;
        foreach (MobileEntry item in Reportables) {
            TotalItem++;
            TotalAmount += item.Amount;
        }
        OnPropertyChanged(nameof(TotalItem));
        OnPropertyChanged(nameof(TotalAmount));
    }
    void refreshAccount() {
        if (Reportables.IsEmpty) updateReportables();
        else {
            BusyWindow.Activate(MobileSearch.Left, MobileSearch.Top, MobileSearch.Width, MobileSearch.Height, "Filtering");
            Reportables.Filter = filterReportables;
            makeAccountSummary();
            BusyWindow.Terminate();
        }
    }
    void updateEntryInfo() {
        if (Selected is null) {
            imagePath = null;
            Bitmap = null;
            return;
        }
        imagePath = Constants.ImageFolder + "/" + Selected.FileName;
        if (!System.IO.File.Exists(imagePath)) {
            //imagePath = null;
            Bitmap = null;
            return;
        }
        switch (state) {
            case ColorState.BlackWhite: MakeBlackWhite(); break;
            case ColorState.Gray: MakeGray(); break;
            case ColorState.Color: MakeNormal(); break;
        }
    }
}
