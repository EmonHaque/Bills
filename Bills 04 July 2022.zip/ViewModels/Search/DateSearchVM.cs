﻿class DateSearchVM : EditBaseVM
{
    DateTime? selectedDate;
    public DateTime? SelectedDate {
        get { return selectedDate; }
        set {
            selectedDate = value;
            if (value is not null) updateReportables();
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }

    public List<KeyValueSeries> DeptPieValues { get; set; }
    protected override string Where {
        get {
            if(SelectedDate.HasValue)
                return $"PaymentDate = '{SelectedDate.Value.ToString("yyyy-MM-dd")}'";
            return $"PaymentDate = '{DateTime.Today.ToString("yyyy-MM-dd")}'";
        }
    }
    public static event Action<Account> AccountChanged;
    public static event Action<ReportEntry> BillChanged;

    public DateSearchVM() : base() {
        SelectedDate = DateTime.Today;
        Reportables = new CollectionViewSource() {
            Source = reportables,
            IsLiveGroupingRequested = true,
            IsLiveFilteringRequested = true,
            LiveGroupingProperties = { nameof(ReportEntry.DeptId) },
            LiveFilteringProperties = { nameof(ReportEntry.PaymentDate) }
        }.View;
        Reportables.CollectionChanged += onCollectionChanged;
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(ReportEntry.DeptId)));
        Reportables.Filter = filter;

        AccountSearchBaseVM.AccountChanged += onAccountChanged;
        AccountSearchBaseVM.BillChanged += onBillChanged;
    }

    void onAccountChanged(Account a) => updateAccountNo(a);
    void updateAccountNo(Account a) {
        foreach (ReportEntry item in reportables) {
            if (item.AccountId == a.Id) {
                item.AccountNo = a.AccountNo;
                item.OnPropertyChanged(nameof(ReportEntry.AccountNo));
            }
        }
    }
    void onBillChanged(ReportEntry e) {
        bool toBeRemoved = false;
        bool isFound = false;
        foreach (ReportEntry item in reportables) {
            if (item.BillId == e.BillId) {
                item.BillNo = e.BillNo;
                item.FileName = e.FileName;
                item.Period = e.Period;
                item.TransactionId = e.TransactionId;
                item.Mobile = e.Mobile;
                if (item.PaymentDate != e.PaymentDate) {
                    item.PaymentDate = e.PaymentDate;
                    toBeRemoved = true;
                }
                item.OnPropertyChanged(null);
                isFound = true;
                break;
            }
        }
        if (!isFound) {
            if (e.PaymentDate == SelectedDate) {
                reportables.Add(e);
            }
        }
        if (toBeRemoved) updateChart();
    }
    bool filter(object o) {
        var e = (ReportEntry)o;
        if (string.IsNullOrWhiteSpace(Query))
            return e.PaymentDate.Equals(SelectedDate);
        return e.AccountNo.Contains(Query) && e.PaymentDate.Equals(SelectedDate);
    }
    protected override void onEntryInfoUpdate() {
        SelectedAccount = SelectedBill is null ? null :
            AppData.accounts.First(x => x.Id == SelectedBill.AccountId);
        OnPropertyChanged(nameof(SelectedAccount));
    }
    protected override void onAccountUpdate() {
        updateAccountNo(SelectedAccount);
        AccountChanged?.Invoke(SelectedAccount);
    }
    protected override void onBillUpdate() {
        if (!isDateEqual) {
            DeptPieValues = new List<KeyValueSeries>();
            updateChart();
        }
        BillChanged?.Invoke(SelectedBill);
    }
    protected override void onBillEntriesUpdate() {
        PieValues = new List<KeyValueSeries>();
        DeptPieValues = new List<KeyValueSeries>();
        updateChart();
        updatePie();
    }
    protected override void onNullify() {
        SelectedAccount = null;
        OnPropertyChanged(nameof(SelectedAccount));
    }
    protected override void updateChart() {
        if (reportables.Count == 0) DeptPieValues = null;
        else DeptPieValues = reportables.OfType<ReportEntry>()
            .GroupBy(x => x.DeptId)
            .Select(x => new KeyValueSeries() {
                Name = AppData.departments.First(y => y.Id == x.Key).Name,
                Total = x.Sum(x => x.Payment)
            }).ToList();
        OnPropertyChanged(nameof(DeptPieValues));
    }
}
