﻿class TitasVM : AccountSearchBaseVM
{
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.TGCL)).Id;
}
