﻿class MobileVM
{
    public ICollectionView Mobiles { get; set; }
    public MobileVM() {
        Mobiles = new CollectionViewSource() {
            Source = AppData.mobiles,
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Mobile.Name) },
        }.View;
        Mobiles.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Mobile.Name)));
    }
}
