﻿class DeptAccountsVM : Notifiable
{
    string query;
    public string Query {
        get { return query; }
        set { query = value; Accounts.Refresh(); }
    }
    public ICollectionView Accounts { get; set; }
    public DeptAccountsVM() {
        Accounts = new CollectionViewSource() {
            Source = AppData.accounts,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(Account.DeptId) },
        }.View;
        Accounts.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Account.DeptId)));
        Accounts.Filter = filter;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        var a = (Account)o;
        return a.Name.Contains(Query, StringComparison.InvariantCultureIgnoreCase) ||
            a.Address.Contains(Query, StringComparison.InvariantCultureIgnoreCase) ||
            a.AccountNo.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
}
