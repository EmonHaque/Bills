﻿class PeriodicVM : Notifiable
{
    List<SummaryEntry> summary, subSummary;
    byte reportState;
    public byte ReportState {
        get { return reportState; }
        set { reportState = value; makeDateMonthwiseReport(); }
    }
    byte groupDetailState;
    public byte GroupDetailState {
        get { return groupDetailState; }
        set { groupDetailState = value; makeDetailSummary(); }
    }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public DateTime MinDate { get; set; }
    public List<PinSeries> DateMonthSeries { get; set; }
    public List<KeyValueSeries> DeptSeries { get; set; }
    public List<KeyValueSeries> DeptSummary { get; set; }
    public List<DayMonthEntry> DateMonthwiseReport { get; set; }
    public ICollectionView HeadwiseReport { get; set; }
    public ICollectionView DetailReport { get; set; }
    public Action RefreshReport { get; set; }
    DayMonthEntry selectedDayMonth;
    public DayMonthEntry SelectedDayMonth {
        get { return selectedDayMonth; }
        set {
            selectedDayMonth = value;
            subSummary = value is null ? 
                summary : ReportState == 0 ?
                summary.Where(x => x.Date.Equals(value.DayMonth)).ToList() :
                summary.Where(x => x.Month.Equals(value.DayMonth)).ToList();
            makeHeadWiseSummary();
            makeDetailSummary();
            makeDeptSummary();
        }
    }
    string selectedDept;
    public string SelectedDept {
        get { return selectedDept; }
        set { selectedDept = value; makeDeptSummary(); }
    }

    public PeriodicVM() {
        StartDate = DateTime.Today.AddYears(-1);
        EndDate = DateTime.Today;
        summary = new List<SummaryEntry>();
        lock (SQL.key) {
            SQL.command.CommandText = "SELECT MIN(PaymentDate) FROM Bills";
            var date = SQL.command.ExecuteScalar();
            MinDate = date.Equals(DBNull.Value) ? DateTime.Today : DateTime.Parse(date.ToString());
        }
        AccountSearchBaseVM.AccountChanged += onAccountUpdated;
        DateSearchVM.AccountChanged += onAccountUpdated;
        RefreshReport = refreshReports;
    }

    void onAccountUpdated(Account a) {
        if (DetailReport is null) return;
        foreach (SummaryEntry entry in DetailReport) {
            if(entry.AccountId == a.Id) {
                entry.AccountNo = a.AccountNo;
                entry.AccountAddress = a.Address;
                entry.AccountName = a.Name;
                entry.OnPropertyChanged(null);
            }
        }
    }

    public void refreshReports() {
        if (EndDate < StartDate) {
            var errors = new List<ValidationError>() {
                new ValidationError(){ Head = "from", Error = "cannot be greater than to"},
                new ValidationError(){ Head = "to", Error = "cannot be less than from"}
            };
            var dialog = new BillErrorDialog(PeriodicView.Left, PeriodicView.Top, PeriodicView.Width, PeriodicView.Height, errors);
            dialog.ShowDialog();
            return;
        }
        fetchData();
        makeDateMonthwiseReport();
        subSummary = summary;
        SelectedDayMonth = null;
        OnPropertyChanged(nameof(SelectedDayMonth));
    }
    void makeDateMonthwiseReport() {
        if (ReportState == 0) DateMonthwiseReport = summary.GroupBy(x => x.Date, (key, value) => new DayMonthEntry() {
            DayMonth = key,
            Bill = value.Sum(x => x.Bill),
            Payment = value.Sum(x => x.Payment)
        }).OrderBy(x => x.DayMonth).ToList();
        else DateMonthwiseReport = summary.GroupBy(x => x.Month, (key, value) => new DayMonthEntry() {
            DayMonth = key,
            Bill = value.Sum(x => x.Bill),
            Payment = value.Sum(x => x.Payment)
        }).OrderBy(x => x.DayMonth).ToList();

        if (DateMonthwiseReport.Count > 15) {
            DateMonthSeries = DateMonthwiseReport
                .Skip(DateMonthwiseReport.Count - 15)
                .Select(x => new PinSeries() {
                    Date = x.DayMonth,
                    PinAmount = x.Bill,
                    LineAmount = x.Payment
                }).ToList();
        }
        else DateMonthSeries = DateMonthwiseReport
            .Select(x => new PinSeries() {
                Date = x.DayMonth,
                PinAmount = x.Bill,
                LineAmount = x.Payment
            }).ToList();

        OnPropertyChanged(nameof(DateMonthwiseReport));
        OnPropertyChanged(nameof(DateMonthSeries));
    }
    void makeHeadWiseSummary() {
        var grouped = new List<SummaryEntry>();
        DeptSeries = new List<KeyValueSeries>();
        foreach (var e in subSummary) {
            var group = grouped.FirstOrDefault(x => x.Head.Equals(e.Head) && x.DeptName.Equals(e.DeptName));
            if(group is null) {
                group = new SummaryEntry() {
                    Head = e.Head,
                    DeptName = e.DeptName,
                    Bill = e.Bill,
                    Payment = e.Payment
                };
                grouped.Add(group);
            }
            else {
                group.Bill += e.Bill;
                group.Payment += e.Payment;
            }
            var series = DeptSeries.FirstOrDefault(x => x.Name.Equals(e.DeptName));
            if (series is null) {
                series = new KeyValueSeries() {
                    Name = e.DeptName,
                    Total = e.Payment
                };
                DeptSeries.Add(series);
            }
            else series.Total += e.Payment;
        }
        HeadwiseReport = CollectionViewSource.GetDefaultView(grouped);
        HeadwiseReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.Head)));
        HeadwiseReport.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SummaryEntry.DeptName)));
        OnPropertyChanged(nameof(HeadwiseReport));
        OnPropertyChanged(nameof(DeptSeries));
    }
    void makeDetailSummary() {
        if (subSummary is null) return;
        if (groupDetailState == 0) {
            List<SummaryEntry> grouped = new();
            foreach (var item in subSummary) {
                var group = grouped.FirstOrDefault(
                    x =>
                    x.Mobile.Equals(item.Mobile) &&
                    x.DeptName.Equals(item.DeptName) &&
                    x.Head.Equals(item.Head) &&
                    x.AccountNo.Equals(item.AccountNo));
                if (group is null) {
                    group = new SummaryEntry() {
                        DeptName = item.DeptName,
                        Head = item.Head,
                        AccountNo = item.AccountNo,
                        AccountId = item.AccountId,
                        AccountName = item.AccountName,
                        AccountAddress = item.AccountAddress,
                        Mobile = item.Mobile,
                        Bill = item.Bill,
                        Payment = item.Payment
                    };
                    grouped.Add(group);
                }
                else {
                    group.Bill += item.Bill;
                    group.Payment += item.Payment;
                }
            }
            foreach (var group in grouped) {
                grouped.First(
                    x =>
                    x.Mobile.Equals(group.Mobile) &&
                    x.DeptName.Equals(group.DeptName) &&
                    x.Head.Equals(group.Head)).Count++;
            }
            DetailReport = new CollectionViewSource() {
                Source = grouped,
                GroupDescriptions = {
                    new PropertyGroupDescription(nameof(SummaryEntry.Mobile)),
                    new PropertyGroupDescription(nameof(SummaryEntry.DeptName)),
                    new PropertyGroupDescription(nameof(SummaryEntry.Head))
                },
                SortDescriptions = {
                    new SortDescription(nameof(SummaryEntry.Count), ListSortDirection.Descending)
                }
            }.View;
        }
        else {
            List<SummaryEntry> grouped = new();
            foreach (var item in subSummary) {
                var group = grouped.FirstOrDefault(
                    x =>
                    x.DeptName.Equals(item.DeptName) &&
                    x.AccountNo.Equals(item.AccountNo) &&
                    x.Head.Equals(item.Head));
                if(group is null) {
                    group = new SummaryEntry() {
                        DeptName = item.DeptName,
                        Head = item.Head,
                        AccountNo = item.AccountNo,
                        AccountId = item.AccountId,
                        AccountName = item.AccountName,
                        AccountAddress = item.AccountAddress,
                        Bill = item.Bill,
                        Payment = item.Payment
                    };
                    grouped.Add(group);
                }
                else {
                    group.Bill += item.Bill;
                    group.Payment += item.Payment;
                }
            }
            foreach (var group in grouped) {
                grouped.First(
                    x =>
                    x.DeptName.Equals(group.DeptName) &&
                    x.AccountNo.Equals(group.AccountNo)).Count++;
            }
            DetailReport = new CollectionViewSource() {
                Source = grouped,
                GroupDescriptions = {
                    new PropertyGroupDescription(nameof(SummaryEntry.DeptName)),
                    new PropertyGroupDescription(nameof(SummaryEntry.AccountNo))
                },
                SortDescriptions = {
                    new SortDescription(nameof(SummaryEntry.Count), ListSortDirection.Descending)
                }
            }.View;
        }    
        OnPropertyChanged(nameof(DetailReport));
    }
    void makeDeptSummary() {
        if (SelectedDept is null) DeptSummary = null;
        else {
            DeptSummary = new List<KeyValueSeries>();
            var inter = subSummary
                .Where(x => x.DeptName.Equals(SelectedDept))
                .GroupBy(x => x.Head)
                .Select(x => new {
                    Head = x.Key,
                    Bill = x.Sum(x => x.Bill),
                    Payment = x.Sum(x => x.Payment)
                }).ToList();
            foreach (var item in inter) {
                if (item.Head.Equals("Amount")) {
                    DeptSummary.Add(new KeyValueSeries() {
                        Name = item.Head,
                        Total = item.Bill
                    });
                }
                else {
                    DeptSummary.Add(new KeyValueSeries() {
                        Name = item.Head,
                        Total = item.Bill + item.Payment
                    });
                }
            }
        }

        OnPropertyChanged(nameof(DeptSummary));
    }
    void fetchData() {
        summary.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = @$"WITH T1 AS(
											SELECT Id FROM Bills 
											WHERE PaymentDate BETWEEN 
											'{StartDate.ToString("yyyy-MM-dd")}' AND '{EndDate.ToString("yyyy-MM-dd")}'
										),
										T2(Date, DeptId, AccountId, Head, Bill, Payment, UID, MobileId) AS(
                                        	SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, be.Amount, null, bi.Id, bi.MobileId
                                        	FROM BillEntries be
                                        	LEFT JOIN Bills bi ON bi.Id = be.BillId
                                        	LEFT JOIN Heads h ON h.Id = be.HeadId
                                        	WHERE be.BillId IN (SELECT * FROM T1)
                                        ),
                                        T3(Date, DeptId, AccountId, Head, Bill, Payment, UID, MobileId) AS(
                                        	SELECT bi.PaymentDate, bi.DeptId, bi.AccountId, h.Name, null, pe.Amount, bi.Id, bi.MobileId
                                        	FROM PaymentEntries pe
                                        	LEFT JOIN Bills bi ON bi.Id = pe.BillId
                                        	LEFT JOIN Heads h ON h.Id = pe.HeadId
                                        	WHERE pe.BillId IN (SELECT * FROM T1)
                                        ),
                                        T4 (Date, DeptId, AccountId, Head, Bill, Payment, MobileId) AS (
                                        	SELECT t2.Date, t2.DeptId, t2.AccountId, t2.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0), t2.MobileId
                                        	FROM T2 t2 
                                        	LEFT JOIN T3 t3 USING(AccountId, Head, UID)	
                                            UNION  ALL
                                        	SELECT t3.Date, t3.DeptId, t3.AccountId, t3.Head, coalesce(t2.Bill, 0), coalesce(t3.Payment, 0), t3.MobileId 
                                        	FROM T3 t3 
                                        	LEFT JOIN T2 t2 USING(AccountId, Head, UID)	
                                            WHERE t2.Head IS NULL
                                        )
                                        SELECT d.Name, a.AccountNo, a.Name, a.Address, t.Head, t.Bill, t.Payment, t.Date, t.AccountId, 
                                        MobileId, strftime('%Y-%m', t.Date) Month FROM T4 t
                                        LEFT JOIN Department d ON d.Id = t.DeptId
                                        LEFT JOIN Account a ON a.Id = t.AccountId";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var mobileId = reader.GetInt32(9);
                var mobile = AppData.mobiles.First(x => x.Id == mobileId);
                var e = new SummaryEntry() {
                    DeptName = reader.GetString(0),
                    AccountNo = reader.GetString(1),
                    AccountName = reader.GetString(2),
                    AccountAddress = reader.GetString(3),
                    Head = reader.GetString(4),
                    Bill = reader.GetDouble(5),
                    Payment = reader.GetDouble(6),
                    Date = reader.GetString(7),
                    AccountId = reader.GetInt32(8),
                    Mobile = mobile.Name + " - " + mobile.MobileNo, //AppData.mobiles. reader.GetInt32(9),
                    Month = reader.GetString(10)
                };
                summary.Add(e);
            }
            reader.Close();
            reader.DisposeAsync();
        }
    }
}
