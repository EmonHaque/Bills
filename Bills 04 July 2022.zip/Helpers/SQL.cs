﻿class SQL
{
    public static object key;
    public static SqliteConnection connection;
    public static SqliteCommand command;
    public static void Initialize() {
        key = new();
        connection = new(Constants.ConnectionString);
        connection.Open();
        command = connection.CreateCommand();
    }
    public static bool Transaction(List<KeyValuePair<string, List<SqliteParameter>>> commands) {
        bool isOk = true;
        command.CommandText = "BEGIN TRANSACTION;";
        command.ExecuteNonQuery();      
        foreach (var item in commands) {
            command.CommandText = item.Key;
            if(item.Value is not null) command.Parameters.AddRange(item.Value);
            try { command.ExecuteNonQuery(); }
            catch(Exception e) {
                command.CommandText = "ROLLBACK;";
                command.ExecuteNonQuery();
                isOk = false;
            }
            command.Parameters.Clear();
            if (!isOk) break;
        }
        if (isOk) {
            command.CommandText = "COMMIT;";
            command.ExecuteNonQuery();
        }
        return isOk;
    }
}
