﻿class DetailSummaryGroupTemplate : ControlTemplate
{
    public DetailSummaryGroupTemplate() {
        TargetType = typeof(GroupItem);
        var expander = new FrameworkElementFactory(typeof(Expander)) { Name = "exp" };
        var border = new FrameworkElementFactory(typeof(Border));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        expander.SetValue(Expander.MarginProperty, new Thickness(5, 0, 0, 0));
        expander.SetValue(Expander.TemplateProperty, new ExpanderTemplate());
        expander.SetValue(Expander.HeaderTemplateProperty, new DetailExpanderHeaderTemplate());
        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);

        expander.SetBinding(Expander.IsExpandedProperty, new Binding(nameof(Expander.Tag)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(GroupItem), 1),
            TargetNullValue = false,
            //FallbackValue = false
        });
        border.SetBinding(Border.BorderThicknessProperty, new Binding() { Converter = Converters.DGL2T });

        border.AppendChild(items);
        expander.AppendChild(border);
        VisualTree = expander;
    }
}
