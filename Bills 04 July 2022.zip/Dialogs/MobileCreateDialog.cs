﻿class MobileCreateDialog : Window
{
    EditText accountNo, name;
    ActionButton ok, cancel;
    string mobileNo;
    public MobileCreateDialog(string mobileNo) {
        this.mobileNo = mobileNo;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        Width = Owner.ActualWidth;
        Height = Owner.ActualHeight;
        ResizeMode = ResizeMode.NoResize;
        Left = Owner.Left;
        Top = Owner.Top;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });
        initializeContent();
    }

    void initializeContent() {
        var header = new TextBlock() {
            Margin = new Thickness(0, 0, 0, 10),
            FontSize = 18,
            Text = "Provide Name"
        };
        accountNo = new EditText() {
            Hint = "Mobile",
            Icon = Icons.ID,
            Text = mobileNo,
            IsEnabled = false
        };
        name = new EditText() { Hint = "Name", Icon = Icons.Tenant, IsRequired = true };

        ok = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Left,
            ToolTip = "Ok",
            Width = 24,
            Height = 24,
            Margin = new Thickness(5, 10, 0, 0),
            Icon = Icons.Ok,
            Command = validate
        };
        cancel = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            ToolTip = "Cancel",
            Width = 24,
            Height = 24,
            Margin = new Thickness(0, 10, 5, 0),
            Icon = Icons.Cancel,
            Command = () => {
                DialogResult = false;
                Close();
            }
        };
        var buttons = new Grid() {
            Margin = new Thickness(5, 10, 5, 5),
            Children = { ok, cancel }
        };
        Content = new Border() {
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(10),
            Background = Constants.Background,
            Width = this.Width / 3,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Child = new StackPanel() {
                Children = { header, accountNo, name, buttons }
            }
        };
    }

    void validate() {
        if (string.IsNullOrWhiteSpace(name.Text)) {
            name.Error = "is required";
            return;
        }
        DialogResult = true;
        Close();
    }
    public string GetName() => name.Text;
    protected override void OnPreviewMouseWheel(MouseWheelEventArgs e) {
        base.OnPreviewMouseWheel(e);
        double size = (double)GetValue(TextElement.FontSizeProperty);
        if (e.Delta > 0) SetValue(TextElement.FontSizeProperty, ++size);
        else if (size > 12) SetValue(TextElement.FontSizeProperty, --size);
    }
}
