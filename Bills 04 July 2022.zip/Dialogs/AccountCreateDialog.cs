﻿class AccountCreateDialog : Window
{
    EditText department, accountNo, name, address;
    MultiState isCorrect;
    TextBlock info;
    ActionButton ok, cancel;
    string dept, account;

    public AccountCreateDialog(string dept, string account) {
        this.dept = dept;
        this.account = account;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        Width = Owner.ActualWidth;
        Height = Owner.ActualHeight;
        ResizeMode = ResizeMode.NoResize;
        Left = Owner.Left;
        Top = Owner.Top;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });
        initializeContent();
    }
    void initializeContent() {
        var header = new TextBlock() {
            Margin = new Thickness(0,0,0,10),
            FontSize = 18,
            Text = "Provide Name and Address"
        };
        department = new EditText() {
            Hint = "Department",
            Icon = Icons.Business,
            Text = dept,
            IsEnabled = false,
        };
        accountNo = new EditText() {
            Hint = "Account",
            Icon = Icons.ID,
            Text = account,
            IsEnabled = false
        };
        name = new EditText() { Hint = "Name", Icon = Icons.Tenant };
        address = new EditText() { Hint = "Address", Icon = Icons.Address };
        isCorrect = new MultiState() {
            Texts = new string[] { "Correct", "Wrong" },
            Icons = new string[] { Icons.Checked, Icons.CloseCircle },
            Margin = new Thickness(0,10,0,0),
            HorizontalAlignment = HorizontalAlignment.Center
        };
        info = new TextBlock() { 
            Foreground = Brushes.Coral, 
            HorizontalAlignment = HorizontalAlignment.Center 
        };
        ok = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Left,
            ToolTip = "Ok",
            Width = 24,
            Height = 24,
            Margin = new Thickness(5, 10, 0, 0),
            Icon = Icons.Ok,
            Command = validate
        };
        cancel = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            ToolTip = "Cancel",
            Width = 24,
            Height = 24,
            Margin = new Thickness(0, 10, 5, 0),
            Icon = Icons.Cancel,
            Command = () => {
                DialogResult = false;
                Close();
            }
        };
        var buttons = new Grid() {
            Margin = new Thickness(5, 10, 5, 5),
            Children = { ok, cancel }
        };
        Content = new Border() {
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(10),
            Background = Constants.Background,
            Width = this.Width / 3,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Child = new StackPanel() {
                Children = { header, department, accountNo, name, address, isCorrect, info, buttons }
            }
        };
    }
    void validate() {
        if (string.IsNullOrWhiteSpace(name.Text) && string.IsNullOrWhiteSpace(address.Text)) {
            info.Text = "provide Name and Address";
            return;
        }
        DialogResult = true;
        Close();
    }
    public (string Name, string Address, byte isCorrect) GetNameAndAddress() => (name.Text, address.Text, (byte)isCorrect.State );
    protected override void OnPreviewMouseWheel(MouseWheelEventArgs e) {
        base.OnPreviewMouseWheel(e);
        double size = (double)GetValue(TextElement.FontSizeProperty);
        if(e.Delta > 0) SetValue(TextElement.FontSizeProperty, ++size);
        else if(size > 12) SetValue(TextElement.FontSizeProperty, --size);
    }
}
