﻿class LoadView : CardView
{
    public override string Header => "Directory";
    ActionButton openDirectory, updateDatabase, allRight;
    TextBlock statusBlock, totalPaymentBlock, updateStats, okCountBlock;
    EditText query;
    Grid queryGrid;
    ListBoxEx list;
    ProgressBar progress;
    MenuItem okMenu, removeMenu;
    Border updateStatus;
    LoadVM vm;
    DoubleAnimation anim;
    CubicEase easeIn, easeOut;
    public LoadView() {
        vm = new LoadVM();
        DataContext = vm;
        initialize();
        bind();
        anim = new DoubleAnimation() { Duration = TimeSpan.FromMilliseconds(500)};
        easeIn = new CubicEase() { EasingMode = EasingMode.EaseIn };
        easeOut = new CubicEase() { EasingMode = EasingMode.EaseOut };
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        okMenu.Click += onOkClick;
        removeMenu.Click += onRemoveClick;
        vm.PropertyChanged += onUpdateChanged;
        App.Current.MainWindow.LocationChanged += onRelocate;

        var border = (Border)VisualTreeHelper.GetChild(list, 0);
        var scroll = (ScrollViewer)VisualTreeHelper.GetChild(border, 0);
        ((Rectangle)scroll.Template.FindName("Corner", scroll)).Fill = Constants.Background;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        okMenu.Click -= onOkClick;
        removeMenu.Click -= onRemoveClick;
        vm.PropertyChanged -= onUpdateChanged;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void onUpdateChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(vm.IsInUpdate))) return;
        if (vm.IsInUpdate) {
            anim.To = 20;
            anim.EasingFunction = easeIn;
        }
        else {
            anim.To = 0;
            anim.EasingFunction = easeOut;
        }
        updateStatus.BeginAnimation(Border.HeightProperty, anim);
    }
    void onOkClick(object sender, RoutedEventArgs e) => vm.setOk();
    void onRemoveClick(object sender, RoutedEventArgs e) => vm.removeItem();
    void initialize() {
        openDirectory = new ActionButton() {
            Icon = Icons.OpenFolder,
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Select root directory",
            Command = vm.OnDirectorySelected
        };
        addActions(openDirectory);
        progress = new ProgressBar() {
            Margin = new Thickness(0, 2, 0, 5),
            BorderThickness = new Thickness(0),

            Height = 1,
            Minimum = 0,
            Maximum = 1
        };
        statusBlock = new TextBlock();
        query = new EditText() {
            Icon = Icons.Magnify,
            Hint = "Query"
        };
        okCountBlock = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
        var okIcon = Helper.GetIcon(Icons.Checked);
        okIcon.VerticalAlignment = VerticalAlignment.Center;
        okIcon.Width = okIcon.Height = 10;
        okIcon.Margin = new Thickness(5, 0, 5, 0);
        Grid.SetColumn(okCountBlock, 2);
        Grid.SetColumn(okIcon, 1);
        queryGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = {query, okCountBlock, okIcon }
        };
        var contextMenu = new ContextMenu();
        okMenu = new MenuItem() { Icon = Helper.GetIcon(Icons.Checked), Header = "Ok" };
        removeMenu = new MenuItem() { Icon = Helper.GetIcon(Icons.CloseCircle), Header = "Remove" };
        contextMenu.Items.Add(okMenu);
        contextMenu.Items.Add(removeMenu);
        list = new ListBoxEx() {
            Margin = new Thickness(0, 2, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, 1),
            BorderBrush = Brushes.LightGray,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemsSource = vm.Info,
            ItemTemplate = new LoadTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = { new Setter(GroupItem.TemplateProperty, new LoadGroupTemplate())}
                    }
                }
            },
            Resources = {
                {
                    typeof(ListBoxItem),
                    new Style(typeof(ListBoxItem)) {
                        Setters = {
                            new Setter(ListBoxItem.ContextMenuProperty, contextMenu)
                        }
                    }
                }
            }
        };

        var totalBlock = new TextBlock() { Text = "Total payment" };
        totalPaymentBlock = new TextBlock();
        allRight = new ActionButton() {
            Margin = new Thickness(10, 0, 10, 0),
            Icon = Icons.Checked,
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Mark all right",
            Command = vm.SetAllOk
        };
        updateDatabase = new ActionButton() {
            Icon = Icons.Add,
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Update databse",
            Command = vm.UpdateInfo
        };

        Grid.SetColumn(totalPaymentBlock, 1);
        Grid.SetColumn(allRight, 2);
        Grid.SetColumn(updateDatabase, 3);
        var bottomGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { totalBlock, totalPaymentBlock, allRight, updateDatabase }
        };
        
        updateStats = new TextBlock();
        updateStatus = new Border() {
            Margin = new Thickness(0, 5, 0, 0),
            Height = 0,
            BorderThickness = new Thickness(0, 1, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = updateStats
        };
        Grid.SetRow(progress, 1);
        Grid.SetRow(queryGrid, 2);
        Grid.SetRow(list, 3);
        Grid.SetRow(bottomGrid, 4);
        Grid.SetRow(updateStatus, 5);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { statusBlock, progress, queryGrid, list, bottomGrid, updateStatus }
        };
        setContent(grid);
    }
    void bind() {
        statusBlock.SetBinding(TextBlock.ToolTipProperty, new Binding(nameof(vm.Directory)));
        statusBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.ProcessingInfo)));
        progress.SetBinding(ProgressBar.ValueProperty, new Binding(nameof(vm.ProgressValue)));
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        okCountBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.OkCount)));
        queryGrid.SetBinding(EditText.VisibilityProperty, new Binding(nameof(vm.IsInProgress)) { Converter = new BooleanToVisibilityConverter() });
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedItem)) { Mode = BindingMode.OneWayToSource });
        totalPaymentBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPaid)) { StringFormat = "N2" });
        allRight.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(vm.IsInProgress)));
        //removeMenu.SetBinding(MenuItem.IsEnabledProperty, new Binding(nameof(vm.IsInProgress)) {
        //    Source = this
        //}); 
        updateDatabase.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(vm.CanUpdate)));
        updateStats.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.UpdatingInfo)));
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition(PointToScreen(new Point(0, 0)));
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition(PointToScreen(new Point(0, 0)));
    }
    void updatePosition(Point position) {
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin.Left;
        position.Y += Constants.CardMargin.Top;
        var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
        var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;
        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = width;
        vm.Height = height;
    }
}