﻿class DescoVM : SearchBaseVM
{
    public override int DeptId => AppData.departments.First(x => x.Name.Equals(BillProcessor.DESCO)).Id;
}
