package com.imagesender.viewModels;

import android.os.Handler;
import android.os.Looper;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.library.baseAdapters.BR;
import com.imagesender.models.FileInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public class TakeImageVM extends BaseObservable {
    AtomicBoolean isSending;
    ArrayList<FileInfo> files;

    Handler handler;
    @Bindable public double progressValue;
    @Bindable public int fileCount;
    @Bindable public String imageStatus;

    private TakeImageVM() {
        isSending = new AtomicBoolean(false);
        handler = new Handler(Looper.getMainLooper());
        files = new ArrayList<>();
    }
    public static TakeImageVM Instance() { return instance ;}
    static TakeImageVM instance = new TakeImageVM();

    public ArrayList<FileInfo> Files() {return files;}
    public void addToList(String path){
        var name = path.substring(path.lastIndexOf('/') + 1);
        files.add(new FileInfo(name,path));
        fileCount = files.size();
        notifyPropertyChanged(BR.fileCount);
    }
    public void Send(){
        if(isSending.get()) return;

        if(files.size() == 0){
            imageStatus = "No file to send";
            notifyPropertyChanged(BR.imageStatus);
            return;
        }
        isSending.set(true);
        new Thread(()->{
            try{
                var stream = MainVM.instance.socket.getOutputStream();
                for (int i = 0; i < files.size(); i++) {
                    final int count = i + 1;

                    var value = (double)count/ (double) files.size();
                    imageStatus = "Sending " + count + "/" + files.size() + " files";
                    progressValue = value;
                    handler.post(() ->{
                        notifyPropertyChanged(BR.imageStatus);
                        notifyPropertyChanged(BR.progressValue);
                    });

                    try{ Thread.sleep(1000);}
                    catch (InterruptedException x) { }
                    stream.write(files.get(i).getBytes());
                    stream.flush();
                }

                int count = files.size();
                files.clear();
                imageStatus = "Total " + count + " file(s) sent";
                fileCount = 0;
                progressValue = 0;
                handler.post(()->{
                    notifyPropertyChanged(BR.imageStatus);
                    notifyPropertyChanged(BR.progressValue);
                    notifyPropertyChanged(BR.fileCount);
                });
            }
            catch (IOException e){
                imageStatus = "Got disconnected!";
                handler.post(()-> notifyPropertyChanged(BR.imageStatus));

                try{Thread.sleep(3000);}
                catch (InterruptedException x){}

                progressValue = 0;
                imageStatus = "";

                handler.post(()->{
                    notifyPropertyChanged(BR.imageStatus);
                    notifyPropertyChanged(BR.progressValue);
                    MainVM.Instance().goToLogin();
                });
            }
            isSending.set(false);
        }).start();
    }
}
