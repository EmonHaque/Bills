package com.imagesender.viewModels;

import android.os.Handler;
import android.os.Looper;
import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.library.baseAdapters.BR;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.atomic.AtomicBoolean;

public class LoginVM extends BaseObservable {
    AtomicBoolean isConnecting;
    String ip;
    int port;
    @Bindable public String loginStatus;
    Handler handler;
    static LoginVM instance = new LoginVM();
    public static LoginVM Instance() { return instance; }
    private LoginVM() {
        isConnecting = new AtomicBoolean(false);
        port = 0;
        handler = new Handler(Looper.myLooper());
    }
    public void Connect(){
        if(isConnecting.get()) return;;
        if(ip == null){
            loginStatus = "IP cannot be empty";
            notifyPropertyChanged(BR.loginStatus);
            return;
        }
        else if(ip.trim().isEmpty()){
            loginStatus = "IP cannot be empty";
            notifyPropertyChanged(BR.loginStatus);
            return;
        }
        isConnecting.set(true);
        loginStatus = "Trying to connect ...";
        notifyPropertyChanged(BR.loginStatus);
        new Thread(() ->{
            try { Thread.sleep(3000); }
            catch (InterruptedException e) { }

            boolean isConnected;
            try {
                MainVM.Instance().socket = new Socket();
                MainVM.Instance().socket.connect(new InetSocketAddress(ip, port), 5000);
                loginStatus = "Connected ...";
                handler.post(() -> notifyPropertyChanged(BR.loginStatus));
                isConnected = true;
                try { Thread.sleep(2000); }
                catch (InterruptedException e) { }
            }
            catch (IOException e){
                loginStatus = "Couldn't connect!";
                handler.post(() -> notifyPropertyChanged(BR.loginStatus));
                isConnected = false;
            }
            if(isConnected){
                loginStatus = "";
                handler.post(() -> {
                    MainVM.Instance().goToTakeImage();
                    notifyPropertyChanged(BR.loginStatus);
                });
            }
            isConnecting.set(false);
        }).start();
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public int getPort() {
        return port;
    }
    public void setPort(int port) {
        this.port = port;
    }
}
