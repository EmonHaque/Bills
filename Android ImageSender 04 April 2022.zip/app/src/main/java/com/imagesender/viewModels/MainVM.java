package com.imagesender.viewModels;

import android.content.Context;

import androidx.fragment.app.FragmentManager;

import com.imagesender.enums.ViewType;
import com.imagesender.fragments.Login;
import com.imagesender.fragments.TakeImage;

import java.net.Socket;

public class MainVM {
    private MainVM(){ }
    static MainVM instance = new MainVM();
    public static MainVM Instance() { return instance; }

    ViewType viewType;
    FragmentManager manager;
    int container;
    Context context;
    Login login;
    TakeImage takeImage;
    public Socket socket;
    public boolean isInitialized;
    public boolean isPermissionGranted;
    public void setup(Context context, FragmentManager manager, int container){
        this.context = context;
        this.manager = manager;
        this.container = container;
        login = new Login(context);
        takeImage = new TakeImage(context);
        if(isInitialized){
            switch (viewType){
                case Login: goToLogin(); break;
                case TakeImage: goToTakeImage(); break;
            }
        }
        else{
            isInitialized = true;
            goToLogin();
        }
    }

    public void goToLogin(){
        manager.beginTransaction().replace(container, login).commitNow();
        viewType = ViewType.Login;
    }
    public void goToTakeImage(){
        manager.beginTransaction().replace(container, takeImage).commitNow();
        viewType = ViewType.TakeImage;
    }
}
