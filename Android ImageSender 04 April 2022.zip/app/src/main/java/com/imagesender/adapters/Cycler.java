package com.imagesender.adapters;

import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.imagesender.models.FileInfo;

import java.util.ArrayList;
//this throws OutOfMemory for large images
public class Cycler extends RecyclerView.Adapter<Cycler.Holder> {
    ArrayList<FileInfo> files;
    public Cycler(ArrayList<FileInfo> files) {
        this.files = files;
    }
    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new Holder(new ImageView(parent.getContext()));
    }
    @Override
    public void onBindViewHolder(Holder holder, int position) {
        holder.iv.setImageURI(Uri.parse(files.get(position).getPath()));
    }
    @Override
    public int getItemCount() {
        return files.size();
    }
    public static class Holder extends RecyclerView.ViewHolder{
        ImageView iv;
        public Holder(View itemView) {
            super(itemView);
            iv = (ImageView) itemView;
        }
    }
}
