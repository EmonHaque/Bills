package com.imagesender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import com.imagesender.viewModels.MainVM;

public class MainActivity extends AppCompatActivity {
    FrameLayout frame;
    MainVM vm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        super.onCreate(savedInstanceState);
        vm = MainVM.Instance();
        if(!vm.isPermissionGranted){
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.INTERNET,
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    }, 1
            );
        }
        frame = new FrameLayout(this);
        frame.setId(View.generateViewId());
        setContentView(frame);
        vm.setup(this, getSupportFragmentManager(), frame.getId());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if(requestCode == 1){
            boolean granted = true;
            for (int i = 0; i < grantResults.length; i++){
                if(grantResults[i] != 0){
                    granted = false;
                    break;
                }
            }
            if(granted) vm.isPermissionGranted = true;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}