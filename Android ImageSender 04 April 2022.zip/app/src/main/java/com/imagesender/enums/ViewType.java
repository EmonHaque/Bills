package com.imagesender.enums;

public enum ViewType {
    Login,
    TakeImage
}
