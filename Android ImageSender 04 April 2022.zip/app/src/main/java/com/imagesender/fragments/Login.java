package com.imagesender.fragments;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.databinding.Observable;
import androidx.fragment.app.Fragment;
import androidx.databinding.library.baseAdapters.BR;
import com.imagesender.customViews.ConnectButton;
import com.imagesender.viewModels.LoginVM;

public class Login extends Fragment {
    TextView text, statusText;
    EditText ipText, portText;
    ConnectButton connect;
    Context context;
    LinearLayout layout;
    LoginVM lvm;

    public Login(){}
    public Login(Context context) {
        this.context = context;
        lvm = LoginVM.Instance();
        text = new TextView(context);
        ipText = new EditText(context);
        portText = new EditText(context);
        connect = new ConnectButton(context);
        statusText = new TextView(context);
        layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setPadding(20,0,20,0);
        text.setGravity(Gravity.CENTER_HORIZONTAL);
        statusText.setGravity(Gravity.CENTER_HORIZONTAL);
        text.setTextSize(25);

        text.setText("Network");
        text.setPadding(0,0,0,10);
        ipText.setHint("Server name");
        InputFilter[] filters = new InputFilter[1];
        filters[0] = new InputFilter() {
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                if (end > start) {
                    String destTxt = dest.toString();
                    String resultingTxt = destTxt.substring(0, dstart) + source.subSequence(start, end) + destTxt.substring(dend);
                    if (!resultingTxt.matches ("^\\d{1,3}(\\.(\\d{1,3}(\\.(\\d{1,3}(\\.(\\d{1,3})?)?)?)?)?)?")) {
                        return "";
                    } else {
                        String[] splits = resultingTxt.split("\\.");
                        for (int i=0; i<splits.length; i++) {
                            if (Integer.valueOf(splits[i]) > 255) {
                                return "";
                            }
                        }
                    }
                }
                return null;
            }
        };

        ipText.setFilters(filters);
        portText.setHint("Port");
        portText.setInputType(InputType.TYPE_CLASS_NUMBER);
        var connectButtonPara = new LinearLayout.LayoutParams(152,152);
        connectButtonPara.gravity = Gravity.CENTER_HORIZONTAL;
        connectButtonPara.setMargins(0,50,0,50);

        layout.addView(text);
        layout.addView(ipText);
        layout.addView(portText);
        layout.addView(connect, connectButtonPara);
        layout.addView(statusText);

        var ip = lvm.getIp();
        var port = lvm.getPort();
        if(ip != null && !ip.trim().isEmpty()) ipText.setText(ip);
        if(port > 0) portText.setText(String.valueOf(port));

        lvm.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                if(propertyId == BR.loginStatus){
                    statusText.setText(lvm.loginStatus);
                }
            }
        });


        ipText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                lvm.setIp(editable.toString());
            }
        });
        portText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                lvm.setPort(Integer.parseInt(editable.toString()));
            }
        });
        connect.setAction(() -> lvm.Connect());

    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return layout;
    }
}
