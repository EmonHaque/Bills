package com.imagesender.fragments;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.databinding.Observable;
import androidx.databinding.library.baseAdapters.BR;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.imagesender.R;
import com.imagesender.adapters.Cycler;
import com.imagesender.customViews.ActionButton;
import com.imagesender.customViews.ProgressView;
import com.imagesender.models.FileInfo;
import com.imagesender.viewModels.MainVM;
import com.imagesender.viewModels.TakeImageVM;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class TakeImage extends Fragment {
    Handler handler;
    Context context;
    LinearLayout layout;
    ActionButton shot, pick, send;
    RecyclerView rView;
    TextView countText, statusText;
    ProgressView progressBar;
    ActivityResultLauncher<Intent> shotLauncher, pickLauncher;
    Uri capturedUri;
    Cycler adapter;
    ArrayList<FileInfo> files;
    TakeImageVM tvm;
    MainVM mvm;

    public TakeImage(){}
    public TakeImage(Context context) {
        this.context = context;
        tvm = TakeImageVM.Instance();
        mvm = MainVM.Instance();
        files = tvm.Files();
        layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setWeightSum(1);

        var topContainer = new LinearLayout(context);
        topContainer.setWeightSum(1);
        shot = new ActionButton(context);
        pick = new ActionButton(context);
        send = new ActionButton(context);
        shot.setIcon(R.drawable.capture);
        pick.setIcon(R.drawable.pick);
        send.setIcon(R.drawable.send);
        shot.setAction(this::onShot);
        pick.setAction(this::onPick);
        send.setAction(() -> tvm.Send());
        countText = new TextView(context);

        var countPara = new LinearLayout.LayoutParams(-2,-2, 1);
        countPara.gravity = Gravity.CENTER_VERTICAL;
        countPara.setMargins(10,0,0,0);
        var pickButtonPara = new LinearLayout.LayoutParams(72,72);
        var shotButtonPara = new LinearLayout.LayoutParams(72,72);
        var sendButtonPara = new LinearLayout.LayoutParams(72,72);
        sendButtonPara.gravity = Gravity.TOP | Gravity.END;

        topContainer.addView(shot, shotButtonPara);
        topContainer.addView(pick, pickButtonPara);
        topContainer.addView(countText, countPara);
        topContainer.addView(send, sendButtonPara);

        progressBar = new ProgressView(context);
        var progressPara = new LinearLayout.LayoutParams(-1, 30);

        rView = new RecyclerView(context);
        rView.setLayoutManager(new LinearLayoutManager(context));
        rView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 1));

        adapter = new Cycler(files);
        rView.setAdapter(adapter);

        statusText = new TextView(context);
        var statusPara = new LinearLayout.LayoutParams(-1,-2);
        statusPara.setMargins(10,10,0,10);

        var topLine = new View(context);
        var bottomLine = new View(context);
        topLine.setBackgroundColor(Color.GRAY);
        bottomLine.setBackgroundColor(Color.GRAY);
        var topLinePara = new LinearLayout.LayoutParams(-1,2);
        topLinePara.setMargins(0,10,0,0);
        var bottomLinePara = new LinearLayout.LayoutParams(-1,2);

        layout.addView(topContainer);
        layout.addView(topLine, topLinePara);
        layout.addView(progressBar, progressPara);
        layout.addView(rView);
        layout.addView(bottomLine, bottomLinePara);
        layout.addView(statusText, statusPara);

        shotLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::afterShot
        );
        pickLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::afterPick
        );
        handler = new Handler(Looper.getMainLooper());

        statusText.setText(tvm.imageStatus);
        countText.setText(tvm.fileCount + " files");
        progressBar.setProgress(tvm.progressValue);

        tvm.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                switch (propertyId){
                    case BR.imageStatus: statusText.setText(tvm.imageStatus); break;
                    case BR.fileCount: countText.setText(tvm.fileCount + " files"); break;
                    case BR.progressValue: progressBar.setProgress(tvm.progressValue); break;
                }
            }
        });
    }
    void onPick() {
        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");
        getIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        pickLauncher.launch(getIntent);
    }
    void onShot() {
        var values = new ContentValues();
        var name = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date()) + ".jpg";
        values.put(MediaStore.Images.Media.TITLE, name);
        capturedUri = context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        var picIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        picIntent.putExtra(MediaStore.EXTRA_OUTPUT, capturedUri);
        shotLauncher.launch(picIntent);
    }
    void afterShot(ActivityResult result){
        if (result.getResultCode() == Activity.RESULT_OK) {
            tvm.addToList(getFilePath(capturedUri));
            adapter.notifyItemInserted(files.size() - 1);
            countText.setText(files.size() + " files listed");
        }
    }
    void afterPick(ActivityResult result) {
        if (result.getResultCode() == Activity.RESULT_OK){
            Intent in = result.getData();
            if(in.getClipData() != null){
                int count = in.getClipData().getItemCount();
                for (int i = 0; i < count; i++){
                    tvm.addToList(getFilePath(in.getClipData().getItemAt(i).getUri()));
                    adapter.notifyItemInserted(files.size() - 1);
                }
            }
            else {
                tvm.addToList(getFilePath(in.getData()));
                adapter.notifyItemInserted(files.size() - 1);
            }
            countText.setText(files.size() + " files listed");
        }
    }
    String getFilePath(Uri uri){
        String[] filePathColumn = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver()
                .query(uri, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        var path = cursor.getString(columnIndex);
        cursor.close();
        return path;
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return layout;
    }
}
