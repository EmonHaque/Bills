package com.imagesender.customViews;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;

import com.imagesender.R;

public class ActionButton extends View {
    Context context;
    Paint innerCircle;
    VectorDrawableCompat icon;
    float radius;
    Runnable action;
    public ActionButton(Context context) {
        super(context);
        this.context = context;
        innerCircle = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerCircle.setStyle(Paint.Style.FILL);
        innerCircle.setColor(ContextCompat.getColor(context, R.color.cornFlowerBlue));
        radius = 35;
        setOnClickListener(this::onClick);
    }

    void onClick(View v) {
        if(action != null) action.run();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        canvas.drawCircle(w/2f,h/2f,radius, innerCircle);
        var l = (w - 48) / 2;
        var t = (h - 48) / 2;
        icon.setBounds(l, t, l + 48, t + 48);
        icon.draw(canvas);
    }
    public void setIcon(int resId){
        var theme = context.getTheme();
        icon = VectorDrawableCompat.create(getContext().getResources(), resId, theme);
        invalidate();
    }
    public void setAction(Runnable action){
        this.action = action;
    }
}
