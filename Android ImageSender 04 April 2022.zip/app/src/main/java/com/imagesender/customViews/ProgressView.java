package com.imagesender.customViews;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.imagesender.R;

public class ProgressView extends View {
    Paint rectPainter, textPainter;
    Rect textBound;
    double value;
    public ProgressView(Context context) {
        super(context);
        value = 0;
        rectPainter = new Paint(Paint.ANTI_ALIAS_FLAG);
        rectPainter.setStyle(Paint.Style.FILL);
        rectPainter.setColor(ContextCompat.getColor(context, R.color.cornFlowerBlue));

        textPainter = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPainter.setColor(Color.WHITE);
        textPainter.setTextSize(20);
        textBound = new Rect();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        float percent = (float) w * (float) value;
        canvas.drawRect(0,0, percent, h, rectPainter);
        if(value > 0){
            var text = String.format("%.2f",value * 100) + " %";
            textPainter.getTextBounds(text, 0, text.length(), textBound);
            var xPos = w/2f - textBound.width() / 2;
            var yPos = h - textBound.height() / 2;
            canvas.drawText(text, xPos, yPos, textPainter);
        }
    }
    public void setProgress(double value){
        this.value = value;
        invalidate();
    }
}
