package com.imagesender.customViews;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import androidx.core.content.ContextCompat;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;

import com.imagesender.R;

public class ConnectButton extends View {
    Paint innerCircle, outerCircle, textPainter;
    Path path;
    VectorDrawableCompat icon;
    float radius, angle, fraction;
    ValueAnimator animator;
    Runnable action;
    public ConnectButton(Context context) {
        super(context);
        innerCircle = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerCircle.setStyle(Paint.Style.FILL);
        innerCircle.setColor(ContextCompat.getColor(context, R.color.cornFlowerBlue));

        outerCircle = new Paint(Paint.ANTI_ALIAS_FLAG);
        outerCircle.setColor(Color.RED);
        outerCircle.setStyle(Paint.Style.STROKE);
        outerCircle.setStrokeWidth(5);

        textPainter = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPainter.setColor(Color.WHITE);
        textPainter.setTextAlign(Paint.Align.CENTER);
        textPainter.setTextSize(24);

        path = new Path();
        radius = 75;
        angle = 360;

        var theme = context.getTheme();
        icon = VectorDrawableCompat.create(getContext().getResources(), R.drawable.connect, theme);


        animator = new ValueAnimator();
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.setFloatValues(0, angle);
        animator.setDuration(2000);
        animator.addUpdateListener(this::onAnimate);
        setOnLongClickListener(this::onLongClick);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if(action != null) action.run();
            }
        });
    }

    boolean onLongClick(View v) {
        animator.start();
        return false;
    }

    void onAnimate(ValueAnimator a) {
        fraction = a.getAnimatedFraction();
        path.rewind();
        invalidate();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        int w = canvas.getWidth();
        int h = canvas.getHeight();
        canvas.drawCircle(w/2f,h/2f,radius, innerCircle);
        path.addArc(2,2,w - 4, h - 4,0,angle*fraction);
        canvas.drawPath(path, outerCircle);

        var l = (w - 96) / 2;
        var t = (h - 96) / 2;
        icon.setBounds(l, t, l + 96, t + 96);
        icon.draw(canvas);
    }

    public void setAction(Runnable action){
        this.action = action;
    }
}
