package com.imagesender.models;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class FileInfo {
    String name;
    String path;

    public FileInfo(String name, String path) {
        this.name = name;
        this.path = path;
    }
    public String getPath() {
        return path;
    }
    public byte[] getBytes(){
        var file = new File(path);
        int fileSize = (int) file.length();
        byte[] nameArray = name.getBytes(StandardCharsets.UTF_8);
        var fileArray = new byte[fileSize];
        try{
            var stream = new BufferedInputStream(new FileInputStream(file));
            stream.read(fileArray, 0, fileArray.length);
            stream.close();
        } catch (IOException e){ }
        var buffer = ByteBuffer.allocate( 8 + nameArray.length + fileSize);
        buffer.putInt(nameArray.length);
        buffer.putInt(fileArray.length);
        buffer.put(nameArray);
        buffer.put(fileArray);
        buffer.flip();
        return buffer.array();
    }
}
